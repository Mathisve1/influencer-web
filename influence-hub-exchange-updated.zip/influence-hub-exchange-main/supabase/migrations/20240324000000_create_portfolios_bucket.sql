
-- Create the portfolios storage bucket
insert into storage.buckets (id, name, public)
values ('portfolios', 'portfolios', true);

-- Create policy to allow public read access
create policy "Public Access"
on storage.objects for select
using ( bucket_id = 'portfolios' );

-- Create policy to allow authenticated users to upload files
create policy "Authenticated users can upload files"
on storage.objects for insert
with check (
  bucket_id = 'portfolios'
  and auth.role() = 'authenticated'
);

-- Create policy to allow users to delete their own files
create policy "Users can delete their own files"
on storage.objects for delete
using (
  bucket_id = 'portfolios'
  and auth.uid() = owner
);
