
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Globe } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StepIndicator from "@/components/StepIndicator";
import { useState } from "react";

const BusinessRegistration = () => {
  const navigate = useNavigate();
  const [selectedIndustry, setSelectedIndustry] = useState<string>("");
  const [otherIndustry, setOtherIndustry] = useState<string>("");

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 border-b border-neutral-800 bg-neutral-900 z-50">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigate("/")}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-xl tracking-wide">Business Registration</div>
            <div className="w-8" />
          </div>
        </div>
        <StepIndicator currentStep={1} totalSteps={3} title="Basic Information" />
      </header>

      <main className="pt-32 px-4 pb-24">
        <form className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Business Name*</label>
            <Input
              type="text"
              placeholder="Enter business name"
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Business Website</label>
            <div className="flex gap-2">
              <div className="flex-none">
                <Button
                  variant="outline"
                  className="px-4 py-3 h-[46px] bg-neutral-800 border border-neutral-700 rounded-lg flex items-center gap-2"
                >
                  <Globe className="w-4 h-4" />
                  <span>https://</span>
                </Button>
              </div>
              <Input
                type="text"
                placeholder="yourwebsite.com"
                className="flex-1 px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Business Description*</label>
            <Textarea
              placeholder="Tell us about your business..."
              className="min-h-[100px] w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Company Size*</label>
            <Select>
              <SelectTrigger className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg">
                <SelectValue placeholder="Select company size" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1-10">1-10 employees</SelectItem>
                <SelectItem value="11-50">11-50 employees</SelectItem>
                <SelectItem value="51-200">51-200 employees</SelectItem>
                <SelectItem value="201-500">201-500 employees</SelectItem>
                <SelectItem value="501+">501+ employees</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Industry/Business Type*</label>
            <Select onValueChange={(value) => setSelectedIndustry(value)}>
              <SelectTrigger className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg">
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tech">Technology</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="health">Healthcare</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            {selectedIndustry === "other" && (
              <Input
                type="text"
                placeholder="Please specify your business type"
                value={otherIndustry}
                onChange={(e) => setOtherIndustry(e.target.value)}
                className="mt-2 w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
              />
            )}
          </div>
        </form>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-neutral-900 border-t border-neutral-800">
        <Button
          onClick={() => navigate("/business-contact", { replace: true })}
          className="w-full py-4 bg-neutral-800 text-sm rounded-lg"
        >
          Next Step
        </Button>
      </footer>
    </div>
  );
};

export default BusinessRegistration;
