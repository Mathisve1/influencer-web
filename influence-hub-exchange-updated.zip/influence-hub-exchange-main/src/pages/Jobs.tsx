import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CountrySelector from "@/components/CountrySelector";
import { JobHeader } from "@/components/jobs/JobHeader";
import { JobFilters } from "@/components/jobs/JobFilters";
import { JobSorting } from "@/components/jobs/JobSorting";
import { JobCard } from "@/components/jobs/JobCard";
import { JobPagination } from "@/components/jobs/JobPagination";

type SortOption = {
  field: "price" | "deadline";
  direction: "asc" | "desc";
};

const Jobs = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 3;
  const [activeFilter, setActiveFilter] = useState<string>("all");
  const [allFiltersDialogOpen, setAllFiltersDialogOpen] = useState(false);
  const [priceDialogOpen, setPriceDialogOpen] = useState(false);
  const [deadlineDialogOpen, setDeadlineDialogOpen] = useState(false);
  const [locationDialogOpen, setLocationDialogOpen] = useState(false);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [selectedDeadline, setSelectedDeadline] = useState<string>("any");
  const [selectedLocation, setSelectedLocation] = useState("");
  const [sortOption, setSortOption] = useState<SortOption | null>(null);

  const jobsData = {
    1: [
      {
        id: 1,
        title: "Social Media Campaign",
        company: "Fashion Brand Co.",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1",
        tags: ["Instagram", "TikTok"],
        price: "$2000-3000",
        deadline: "7 days"
      },
      {
        id: 2,
        title: "Product Review",
        company: "Tech Gadgets Inc.",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=2",
        tags: ["YouTube", "Blog"],
        price: "$1500-2500",
        deadline: "14 days"
      }
    ],
    2: [
      {
        id: 3,
        title: "Content Creation",
        company: "Digital Media Co.",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=3",
        tags: ["Photography", "Video"],
        price: "$3000-4000",
        deadline: "10 days"
      },
      {
        id: 4,
        title: "Brand Ambassador",
        company: "Lifestyle Brand",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=4",
        tags: ["Instagram", "Events"],
        price: "$2500-3500",
        deadline: "21 days"
      }
    ],
    3: [
      {
        id: 5,
        title: "Video Campaign",
        company: "Sports Brand",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=5",
        tags: ["TikTok", "Reels"],
        price: "$4000-5000",
        deadline: "30 days"
      },
      {
        id: 6,
        title: "Social Media Management",
        company: "Food & Beverage Co.",
        image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=6",
        tags: ["Instagram", "Facebook"],
        price: "$2800-3800",
        deadline: "Ongoing"
      }
    ]
  };

  const handleFilterClick = (filter: string) => {
    setActiveFilter(filter);
    switch (filter) {
      case "all":
        setAllFiltersDialogOpen(true);
        break;
      case "price":
        setPriceDialogOpen(true);
        break;
      case "deadline":
        setDeadlineDialogOpen(true);
        break;
      case "location":
        setLocationDialogOpen(true);
        break;
      default:
        setMinPrice("");
        setMaxPrice("");
        setSelectedDeadline("any");
        setSelectedLocation("");
    }
  };

  const getFilterLabel = (filter: string) => {
    switch (filter) {
      case "price":
        return minPrice && maxPrice ? `$${minPrice}-${maxPrice}` : "Price Range";
      case "deadline":
        return selectedDeadline !== "any" ? selectedDeadline : "Deadline";
      case "location":
        return selectedLocation || "Location";
      default:
        return "All";
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(prev => prev + 1);
      window.scrollTo(0, 0);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prev => prev - 1);
      window.scrollTo(0, 0);
    }
  };

  const sortJobs = (jobs: typeof jobsData[1]) => {
    if (!sortOption) return jobs;

    return [...jobs].sort((a, b) => {
      if (sortOption.field === "price") {
        const priceA = parseInt(a.price.replace(/[^0-9]/g, ""));
        const priceB = parseInt(b.price.replace(/[^0-9]/g, ""));
        return sortOption.direction === "asc" ? priceA - priceB : priceB - priceA;
      } else if (sortOption.field === "deadline") {
        const daysA = a.deadline === "Ongoing" ? Infinity : parseInt(a.deadline);
        const daysB = b.deadline === "Ongoing" ? Infinity : parseInt(b.deadline);
        return sortOption.direction === "asc" ? daysA - daysB : daysB - daysA;
      }
      return 0;
    });
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <JobHeader />
      <main className="pb-20">
        <JobFilters 
          activeFilter={activeFilter}
          onFilterClick={handleFilterClick}
          getFilterLabel={getFilterLabel}
        />
        
        <JobSorting 
          sortOption={sortOption}
          onSortChange={setSortOption}
          resultsCount={24 - ((currentPage - 1) * 8)}
        />

        <div className="space-y-4 px-4">
          {sortJobs(jobsData[currentPage as keyof typeof jobsData]).map(job => (
            <JobCard key={job.id} {...job} />
          ))}
        </div>

        <JobPagination 
          currentPage={currentPage}
          totalPages={totalPages}
          onPreviousPage={handlePreviousPage}
          onNextPage={handleNextPage}
        />

        <Dialog open={allFiltersDialogOpen} onOpenChange={setAllFiltersDialogOpen}>
          <DialogContent className="bg-neutral-800 border-neutral-700 text-white">
            <DialogHeader>
              <DialogTitle>All Filters</DialogTitle>
            </DialogHeader>
            <div className="space-y-6 pt-4">
              <div>
                <h3 className="font-medium mb-3">Price Range</h3>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="text-sm text-neutral-400 mb-2 block">Min Price ($)</label>
                    <input
                      type="number"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value)}
                      className="w-full bg-neutral-700 border border-neutral-600 rounded-lg px-4 py-2 text-white"
                      placeholder="0"
                    />
                  </div>
                  <div className="flex-1">
                    <label className="text-sm text-neutral-400 mb-2 block">Max Price ($)</label>
                    <input
                      type="number"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value)}
                      className="w-full bg-neutral-700 border border-neutral-600 rounded-lg px-4 py-2 text-white"
                      placeholder="10000"
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-3">Deadline</h3>
                <div className="space-y-2">
                  {["Any", "Next 7 days", "Next 14 days", "Next 30 days", "More than 30 days"].map((deadline) => (
                    <button
                      key={deadline}
                      onClick={() => setSelectedDeadline(deadline.toLowerCase())}
                      className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                        selectedDeadline === deadline.toLowerCase()
                          ? "bg-brand-gradient-start text-white"
                          : "bg-neutral-700 hover:bg-neutral-600"
                      }`}
                    >
                      {deadline}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-3">Location</h3>
                <CountrySelector 
                  value={selectedLocation}
                  onChange={setSelectedLocation}
                />
              </div>

              <button
                onClick={() => setAllFiltersDialogOpen(false)}
                className="w-full bg-brand-gradient-start text-white rounded-lg py-2 hover:opacity-90 transition-opacity"
              >
                Apply Filters
              </button>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={priceDialogOpen} onOpenChange={setPriceDialogOpen}>
          <DialogContent className="bg-neutral-800 border-neutral-700 text-white">
            <DialogHeader>
              <DialogTitle>Set Price Range</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="text-sm text-neutral-400 mb-2 block">Min Price ($)</label>
                  <input
                    type="number"
                    value={minPrice}
                    onChange={(e) => setMinPrice(e.target.value)}
                    className="w-full bg-neutral-700 border border-neutral-600 rounded-lg px-4 py-2 text-white"
                    placeholder="0"
                  />
                </div>
                <div className="flex-1">
                  <label className="text-sm text-neutral-400 mb-2 block">Max Price ($)</label>
                  <input
                    type="number"
                    value={maxPrice}
                    onChange={(e) => setMaxPrice(e.target.value)}
                    className="w-full bg-neutral-700 border border-neutral-600 rounded-lg px-4 py-2 text-white"
                    placeholder="10000"
                  />
                </div>
              </div>
              <button
                onClick={() => setPriceDialogOpen(false)}
                className="w-full bg-brand-gradient-start text-white rounded-lg py-2 hover:opacity-90 transition-opacity"
              >
                Apply
              </button>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={deadlineDialogOpen} onOpenChange={setDeadlineDialogOpen}>
          <DialogContent className="bg-neutral-800 border-neutral-700 text-white">
            <DialogHeader>
              <DialogTitle>Select Deadline</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 pt-4">
              {["Any", "Next 7 days", "Next 14 days", "Next 30 days", "More than 30 days"].map((deadline) => (
                <button
                  key={deadline}
                  onClick={() => {
                    setSelectedDeadline(deadline.toLowerCase());
                    setDeadlineDialogOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                    selectedDeadline === deadline.toLowerCase()
                      ? "bg-brand-gradient-start text-white"
                      : "bg-neutral-700 hover:bg-neutral-600"
                  }`}
                >
                  {deadline}
                </button>
              ))}
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={locationDialogOpen} onOpenChange={setLocationDialogOpen}>
          <DialogContent className="bg-neutral-800 border-neutral-700 text-white">
            <DialogHeader>
              <DialogTitle>Select Location</DialogTitle>
            </DialogHeader>
            <div className="pt-4">
              <CountrySelector 
                value={selectedLocation}
                onChange={(value) => {
                  setSelectedLocation(value);
                  setLocationDialogOpen(false);
                }}
              />
            </div>
          </DialogContent>
        </Dialog>
      </main>
    </div>
  );
};

export default Jobs;
