
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface SocialMediaProfile {
  platform: string;
  url: string;
  icon: string;
}

const BusinessSocialMediaProfiles = () => {
  const navigate = useNavigate();
  const [profiles, setProfiles] = useState<SocialMediaProfile[]>([
    { platform: "TikTok", url: "", icon: "fa-tiktok" },
    { platform: "Instagram", url: "", icon: "fa-instagram" },
    { platform: "Facebook", url: "", icon: "fa-facebook" },
    { platform: "YouTube", url: "", icon: "fa-youtube" },
  ]);

  const handleUrlChange = (index: number, newUrl: string) => {
    const newProfiles = [...profiles];
    newProfiles[index].url = newUrl;
    setProfiles(newProfiles);
  };

  const handleSave = () => {
    // Here you would typically save to your backend
    toast.success("Social media profiles updated successfully");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 bg-neutral-900 p-4 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/business/edit-profile")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="text-lg">Social Media Profiles</div>
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleSave}
            className="text-sm text-brand-gradient-end hover:text-brand-gradient-start"
          >
            Save
          </motion.button>
        </div>
      </header>

      <main className="p-4 space-y-6">
        {profiles.map((profile, index) => (
          <div
            key={profile.platform}
            className="bg-neutral-800 rounded-xl p-4 border border-neutral-700"
          >
            <div className="flex items-center gap-3 mb-4">
              <i className={`fa-brands ${profile.icon} text-xl`}></i>
              <span>{profile.platform}</span>
            </div>
            <div className="space-y-2">
              <label className="text-sm text-neutral-400 block">
                Profile URL
              </label>
              <Input
                value={profile.url}
                onChange={(e) => handleUrlChange(index, e.target.value)}
                placeholder={`Enter your ${profile.platform} profile URL`}
                className="bg-neutral-700 border-neutral-600"
              />
            </div>
          </div>
        ))}
      </main>
    </div>
  );
};

export default BusinessSocialMediaProfiles;
