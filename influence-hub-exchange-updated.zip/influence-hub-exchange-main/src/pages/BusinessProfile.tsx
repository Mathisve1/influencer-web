
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { BusinessProfileHeader } from "@/components/business-profile/BusinessProfileHeader";
import { BusinessProfileAvatar } from "@/components/business-profile/BusinessProfileAvatar";
import { BusinessProfileMenuItems } from "@/components/business-profile/BusinessProfileMenuItems";
import { SavedTalents } from "@/components/business-profile/SavedTalents";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const BusinessProfile = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);

  const handleLogout = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      toast.success("Logged out successfully");
      navigate("/");
    } catch (error) {
      console.error("Error logging out:", error);
      toast.error("Error logging out");
    }
    setShowLogoutDialog(false);
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <BusinessProfileHeader />

      <main className="pt-24 pb-24 px-4 max-w-4xl mx-auto">
        <BusinessProfileAvatar />

        <Tabs defaultValue="profile" className="mt-6">
          <TabsList className="w-full bg-neutral-800">
            <TabsTrigger value="profile" className="flex-1">Profile</TabsTrigger>
            <TabsTrigger value="saved" className="flex-1">Saved Talents</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile" className="mt-6">
            <button 
              className="w-full bg-neutral-800/50 text-white rounded-xl p-4 flex items-center gap-3 mb-3"
              onClick={() => navigate("/business/edit-profile")}
            >
              <div className="w-10 h-10 rounded-full bg-neutral-700 flex items-center justify-center">
                <i className="fa-regular fa-user"></i>
              </div>
              <span className="text-left">Edit Business Profile</span>
            </button>

            <button 
              className="w-full bg-neutral-800/50 text-white rounded-xl p-4 flex items-center gap-3 mb-6"
              onClick={() => navigate("/business/company-info")}
            >
              <div className="w-10 h-10 rounded-full bg-neutral-700 flex items-center justify-center">
                <i className="fa-regular fa-building"></i>
              </div>
              <span className="text-left">Company Information</span>
            </button>

            <div className="space-y-8">
              <BusinessProfileMenuItems />

              <button 
                className="w-full p-4 border border-neutral-700 rounded-xl text-neutral-400 hover:bg-neutral-800 transition-colors"
                onClick={() => setShowLogoutDialog(true)}
              >
                {t('logOut')}
              </button>
            </div>
          </TabsContent>
          
          <TabsContent value="saved" className="mt-6">
            <SavedTalents />
          </TabsContent>
        </Tabs>
      </main>

      <BusinessNavigation />

      <Dialog open={showLogoutDialog} onOpenChange={setShowLogoutDialog}>
        <DialogContent className="bg-neutral-900 text-white border-neutral-800">
          <DialogHeader>
            <DialogTitle>Log Out</DialogTitle>
            <DialogDescription className="text-neutral-400">
              Are you sure you want to log out?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => setShowLogoutDialog(false)}
              className="flex-1 border-neutral-700 text-white hover:bg-neutral-800 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              onClick={handleLogout}
              className="flex-1 bg-red-600 hover:bg-red-700 text-white"
            >
              Log Out
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BusinessProfile;
