
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import PlatformCard from "@/components/social-media/PlatformCard";
import { loadSocialMediaData, getScreenshotUrl } from "@/utils/socialMediaUtils";
import { SocialMediaPlatform, SocialMediaFormState } from "@/types/socialMedia";

const SocialMediaProfiles = () => {
  const navigate = useNavigate();
  const [expandedPlatform, setExpandedPlatform] = useState<SocialMediaPlatform>("instagram");
  const [formData, setFormData] = useState<SocialMediaFormState>({
    instagram: { username: "", followerCount: "", engagementRate: "" },
    tiktok: { username: "", followerCount: "", engagementRate: "" },
    youtube: { username: "", followerCount: "", engagementRate: "" }
  });

  useEffect(() => {
    const initializeData = async () => {
      const data = await loadSocialMediaData();
      setFormData(data);

      Object.entries(data).forEach(async ([platform, accountData]) => {
        if (accountData.screenshotPath) {
          const url = await getScreenshotUrl(accountData.screenshotPath);
          if (url) {
            setFormData(prev => ({
              ...prev,
              [platform as SocialMediaPlatform]: {
                ...prev[platform as SocialMediaPlatform],
                screenshotUrl: url
              }
            }));
          }
        }
      });
    };

    initializeData();
  }, []);

  const handlePlatformClick = (platform: SocialMediaPlatform) => {
    setExpandedPlatform(platform);
  };

  const handleFormDataUpdate = (platform: SocialMediaPlatform, data: SocialMediaFormState[SocialMediaPlatform]) => {
    setFormData(prev => ({
      ...prev,
      [platform]: data
    }));
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 bg-neutral-900 p-4 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/edit-profile")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="text-lg">Social Media Profiles</div>
          <div className="w-8" />
        </div>
      </header>

      <main className="px-4 py-6 space-y-6">
        <section className="space-y-6">
          {(["instagram", "tiktok", "youtube"] as const).map((platform) => (
            <PlatformCard
              key={platform}
              platform={platform}
              expanded={expandedPlatform === platform}
              formData={formData[platform]}
              onClick={() => handlePlatformClick(platform)}
              onUpdate={handleFormDataUpdate}
            />
          ))}
        </section>
      </main>
    </div>
  );
};

export default SocialMediaProfiles;
