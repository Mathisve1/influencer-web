
import { useState } from "react";
import { Filter, Search, SlidersHorizontal } from "lucide-react";
import { Dialog } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { TalentCard } from "@/components/talents/TalentCard";
import { TalentFilters } from "@/components/talents/TalentFilters";
import { useNavigate } from "react-router-dom";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

export interface Talent {
  id: string;
  name: string;
  avatar: string;
  location: string;
  rate: number;
  specialties: string[];
  platforms: {
    name: string;
    followers: number;
    engagement: number;
  }[];
  languages: string[];
  rating: number;
  completedJobs: number;
}

const FindTalents = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>([]);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [rateRange, setRateRange] = useState({ min: 0, max: 10000 });
  const [followersRange, setFollowersRange] = useState({ min: 0, max: 1000000 });
  const [engagementRange, setEngagementRange] = useState({ min: 0, max: 100 });

  // Mock data for demonstration
  const talents: Talent[] = [
    {
      id: "1",
      name: "Sarah Johnson",
      avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=1",
      location: "New York, USA",
      rate: 500,
      specialties: ["Fashion", "Lifestyle", "Beauty"],
      platforms: [
        { name: "Instagram", followers: 150000, engagement: 4.5 },
        { name: "TikTok", followers: 200000, engagement: 6.2 }
      ],
      languages: ["English", "Spanish"],
      rating: 4.8,
      completedJobs: 24
    },
    {
      id: "2",
      name: "David Chen",
      avatar: "https://api.dicebear.com/7.x/notionists/svg?seed=2",
      location: "Singapore",
      rate: 400,
      specialties: ["Tech", "Gaming", "Education"],
      platforms: [
        { name: "YouTube", followers: 300000, engagement: 5.1 },
        { name: "Twitter", followers: 80000, engagement: 3.8 }
      ],
      languages: ["English", "Mandarin"],
      rating: 4.9,
      completedJobs: 31
    }
  ];

  const handleConnect = (talentId: string) => {
    navigate(`/business/messages/${talentId}`);
  };

  const filteredTalents = talents.filter(talent => {
    const matchesSearch = talent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      talent.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesSpecialties = selectedSpecialties.length === 0 ||
      talent.specialties.some(s => selectedSpecialties.includes(s));

    const matchesPlatforms = selectedPlatforms.length === 0 ||
      talent.platforms.some(p => selectedPlatforms.includes(p.name));

    const matchesLanguages = selectedLanguages.length === 0 ||
      talent.languages.some(l => selectedLanguages.includes(l));

    const matchesRate = talent.rate >= rateRange.min && talent.rate <= rateRange.max;

    const matchesFollowers = talent.platforms.some(p =>
      p.followers >= followersRange.min && p.followers <= followersRange.max
    );

    const matchesEngagement = talent.platforms.some(p =>
      p.engagement >= engagementRange.min && p.engagement <= engagementRange.max
    );

    return matchesSearch && matchesSpecialties && matchesPlatforms &&
      matchesLanguages && matchesRate && matchesFollowers && matchesEngagement;
  });

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">
            TRACE
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-regular fa-bell"></i>
            </button>
            <img 
              src="https://api.dicebear.com/7.x/notionists/svg?seed=123" 
              alt="Profile" 
              className="w-8 h-8 rounded-full"
            />
          </div>
        </div>
        <div className="p-4 flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search by name or specialty..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg pl-10 pr-4 py-2 text-sm"
            />
          </div>
          <Button
            variant="outline"
            className="flex items-center gap-2 border-neutral-700 hover:bg-neutral-800"
            onClick={() => setShowFilters(true)}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
          </Button>
        </div>
      </header>

      <main className="pt-32 px-4 pb-24">
        <div className="space-y-4">
          {filteredTalents.map(talent => (
            <TalentCard 
              key={talent.id}
              talent={talent}
              onConnect={() => handleConnect(talent.id)}
            />
          ))}
        </div>
      </main>

      <Dialog open={showFilters} onOpenChange={setShowFilters}>
        <TalentFilters
          specialties={selectedSpecialties}
          onSpecialtiesChange={setSelectedSpecialties}
          platforms={selectedPlatforms}
          onPlatformsChange={setSelectedPlatforms}
          languages={selectedLanguages}
          onLanguagesChange={setSelectedLanguages}
          rateRange={rateRange}
          onRateRangeChange={setRateRange}
          followersRange={followersRange}
          onFollowersRangeChange={setFollowersRange}
          engagementRange={engagementRange}
          onEngagementRangeChange={setEngagementRange}
        />
      </Dialog>

      <BusinessNavigation />
    </div>
  );
};

export default FindTalents;
