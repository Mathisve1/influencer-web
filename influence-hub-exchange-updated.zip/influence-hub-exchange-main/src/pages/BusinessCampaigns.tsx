import { BusinessNavigation } from "@/components/business/BusinessNavigation";
import { CampaignCard } from "@/components/campaign/CampaignCard";
import { CampaignHeader } from "@/components/campaign/CampaignHeader";
import jsPDF from "jspdf";
import { toast } from "sonner";

const BusinessCampaigns = () => {
  const campaigns = [
    {
      id: "1",
      title: "Summer Collection Launch",
      budget: {
        used: 8500,
        total: 10000,
      },
      engagementRate: 4.8,
      creators: [
        { id: "1", avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1" },
        { id: "2", avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=2" },
        { id: "3", avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=3" },
      ],
    },
    {
      id: "2",
      title: "Brand Awareness",
      budget: {
        used: 5200,
        total: 8000,
      },
      engagementRate: 3.2,
      creators: [
        { id: "4", avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=4" },
        { id: "5", avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=5" },
      ],
    },
  ];

  const generateInvoice = (campaign: typeof campaigns[0]) => {
    try {
      const doc = new jsPDF();
      const lineHeight = 10;
      let yPosition = 20;

      // Add company logo/header
      doc.setFontSize(20);
      doc.text("TRACE", 20, yPosition);
      
      // Add invoice title
      doc.setFontSize(16);
      yPosition += lineHeight * 2;
      doc.text("Campaign Invoice", 20, yPosition);

      // Add campaign details
      doc.setFontSize(12);
      yPosition += lineHeight * 2;
      doc.text(`Campaign: ${campaign.title}`, 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Campaign ID: ${campaign.id}`, 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, yPosition);

      // Add budget details
      yPosition += lineHeight * 2;
      doc.text("Budget Details", 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Total Budget: $${campaign.budget.total.toLocaleString()}`, 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Amount Used: $${campaign.budget.used.toLocaleString()}`, 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Remaining: $${(campaign.budget.total - campaign.budget.used).toLocaleString()}`, 20, yPosition);

      // Add performance metrics
      yPosition += lineHeight * 2;
      doc.text(`Engagement Rate: ${campaign.engagementRate}%`, 20, yPosition);
      
      yPosition += lineHeight;
      doc.text(`Number of Creators: ${campaign.creators.length}`, 20, yPosition);

      // Save the PDF
      doc.save(`campaign-invoice-${campaign.id}.pdf`);
      toast.success("Invoice downloaded successfully");
    } catch (error) {
      console.error("Error generating invoice:", error);
      toast.error("Failed to generate invoice");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">TRACE</div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-regular fa-bell"></i>
            </button>
            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" alt="Profile" className="w-8 h-8 rounded-full"/>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-24">
        <CampaignHeader activeCampaigns={4} activeTab="running" />
        
        <div className="space-y-4">
          {campaigns.map(campaign => (
            <div key={campaign.id} className="space-y-2">
              <CampaignCard
                id={campaign.id}
                title={campaign.title}
                budget={campaign.budget}
                creators={campaign.creators}
              />
              <button
                onClick={() => generateInvoice(campaign)}
                className="w-full px-4 py-2 bg-neutral-800 rounded-lg text-sm hover:bg-neutral-700 transition-colors flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-file-invoice"></i>
                Download Invoice
              </button>
            </div>
          ))}
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default BusinessCampaigns;
