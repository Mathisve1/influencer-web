
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";
import { useToast } from "@/components/ui/use-toast";

type PaymentStatus = 'all' | 'paid' | 'pending' | 'issues';

interface Payment {
  id: string;
  invoiceNumber: string;
  date: string;
  amount: number;
  status: PaymentStatus;
}

const PaymentHistory = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState<PaymentStatus>("all");

  const payments: Payment[] = [
    { id: "1", invoiceNumber: "1234", date: "Jan 15, 2025", amount: 1299.00, status: "paid" },
    { id: "2", invoiceNumber: "1235", date: "Jan 20, 2025", amount: 899.00, status: "pending" },
    { id: "3", invoiceNumber: "1236", date: "Jan 25, 2025", amount: 2499.00, status: "issues" },
    { id: "4", invoiceNumber: "1237", date: "Jan 30, 2025", amount: 1599.00, status: "paid" },
  ];

  const filteredPayments = payments.filter(payment => {
    if (activeFilter === 'all') return true;
    return payment.status === activeFilter;
  }).filter(payment => 
    payment.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    payment.date.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleViewInvoice = (payment: Payment) => {
    if (payment.status === 'issues') {
      // Navigate to chat with admin for issues
      navigate('/messages/admin');
      return;
    }
    
    // For other statuses, show the regular toast
    toast({
      title: `Invoice #${payment.invoiceNumber}`,
      description: `Viewing details for payment of $${payment.amount.toFixed(2)} from ${payment.date}`,
    });
  };

  const getStatusStyle = (status: PaymentStatus) => {
    const baseStyle = "px-3 py-1 bg-neutral-700 text-neutral-400 rounded-full text-xs";
    switch (status) {
      case 'paid':
        return `${baseStyle} bg-green-900/50 text-green-400`;
      case 'pending':
        return `${baseStyle} bg-yellow-900/50 text-yellow-400`;
      case 'issues':
        return `${baseStyle} bg-red-900/50 text-red-400`;
      default:
        return baseStyle;
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 border-b border-neutral-800">
        <div className="px-4 py-3 flex items-center justify-between">
          <button 
            className="p-2"
            onClick={() => navigate("/business/dashboard")}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg">Payment History</div>
          <button className="p-2">
            <i className="fa-solid fa-ellipsis-vertical"></i>
          </button>
        </div>
      </header>

      <main className="pb-20">
        <div className="p-4 sticky top-14 bg-neutral-900 z-40">
          <div className="relative mb-4">
            <i className="fa-solid fa-search absolute left-3 top-3 text-neutral-400"></i>
            <input 
              type="search" 
              placeholder="Search transactions..." 
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg pl-10 pr-4 py-2 text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2 overflow-x-auto py-2">
            {(['all', 'paid', 'pending', 'issues'] as const).map((filter) => (
              <button
                key={filter}
                className={`px-4 py-2 rounded-full text-sm whitespace-nowrap border transition-colors ${
                  activeFilter === filter
                    ? 'bg-white/10 border-white text-white'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-400'
                }`}
                onClick={() => setActiveFilter(filter)}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 space-y-4">
          {filteredPayments.map((payment) => (
            <div key={payment.id} className="bg-neutral-800 rounded-lg p-4 border border-neutral-700">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="text-sm">Invoice #{payment.invoiceNumber}</h3>
                  <p className="text-xs text-neutral-400">{payment.date}</p>
                </div>
                <span className={getStatusStyle(payment.status)}>
                  {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-lg">${payment.amount.toFixed(2)}</span>
                <button 
                  className="text-sm text-neutral-400 hover:text-white transition-colors"
                  onClick={() => handleViewInvoice(payment)}
                >
                  <i className="fa-solid fa-file-invoice mr-1"></i>
                  View
                </button>
              </div>
            </div>
          ))}

          {filteredPayments.length === 0 && (
            <div className="text-center py-8 text-neutral-400">
              No payments found
            </div>
          )}
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default PaymentHistory;
