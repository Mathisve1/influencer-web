
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const InfluencerLogin = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-black p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md"
      >
        <Button
          variant="ghost"
          onClick={() => navigate("/")}
          className="mb-4 text-white hover:text-brand-blue"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        
        <Card className="bg-brand-gray-dark border-brand-gray-light">
          <CardHeader>
            <h2 className="text-2xl font-medium tracking-wide text-center gradient-text">Influencer Login</h2>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-white">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                className="bg-brand-gray-light border-brand-gray-light text-white"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-white">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                className="bg-brand-gray-light border-brand-gray-light text-white"
              />
            </div>
            <Button className="btn-primary w-full touch-target py-6">
              Sign In
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Button 
                variant="link" 
                className="p-0 text-brand-blue hover:text-brand-gradient-end" 
                onClick={() => navigate("/influencer-signup")}
              >
                Sign up
              </Button>
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default InfluencerLogin;
