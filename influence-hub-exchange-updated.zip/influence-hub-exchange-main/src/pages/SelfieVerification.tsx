import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Camera, Upload, Check, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import StepIndicator from "@/components/StepIndicator";

interface UploadState {
  uploading: boolean;
  path: string | null;
  url: string | null;
}

const SelfieVerification = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [uploadState, setUploadState] = useState<UploadState>({
    uploading: false,
    path: null,
    url: null,
  });

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "user" } // Using front camera for selfie
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Camera error",
        description: "Unable to access camera. Please check permissions.",
      });
      console.error('Error accessing camera:', error);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
  };

  const handleCameraCapture = async () => {
    if (!videoRef.current) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0);
    
    canvas.toBlob(async (blob) => {
      if (!blob) return;
      
      const file = new File([blob], `selfie-${Date.now()}.jpg`, { type: 'image/jpeg' });
      await handleFileUpload(file);
      stopCamera();
    }, 'image/jpeg', 0.8);
  };

  const handleFileUpload = async (file: File) => {
    try {
      if (!file.type.match(/^image\/(jpeg|png)$/)) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Please upload a JPEG or PNG file",
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Maximum file size is 5MB",
        });
        return;
      }

      setUploadState(prev => ({
        ...prev,
        uploading: true
      }));

      const tempId = `temp-${Date.now()}`;
      const fileName = `${tempId}/selfie-${Date.now()}.${file.name.split('.').pop()}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('selfies')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: urlData } = await supabase.storage
        .from('selfies')
        .createSignedUrl(fileName, 3600);

      if (!urlData?.signedUrl) throw new Error('Failed to generate signed URL');

      setUploadState({
        uploading: false,
        path: fileName,
        url: urlData.signedUrl
      });

      toast({
        title: "Upload successful",
        description: "Selfie uploaded successfully",
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error.message,
      });
      setUploadState(prev => ({
        ...prev,
        uploading: false
      }));
    }
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const openCamera = () => {
    setShowCamera(true);
    startCamera();
  };

  const handleSubmit = async () => {
    try {
      if (!uploadState.path) {
        toast({
          variant: "destructive",
          title: "Missing selfie",
          description: "Please upload a selfie photo",
        });
        return;
      }

      localStorage.setItem('selfie_verification', uploadState.path);
      navigate("/content-type");
    } catch (error: any) {
      console.error('Submission error:', error);
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: error.message,
      });
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 w-full bg-neutral-900/90 backdrop-blur-lg border-b border-neutral-800 px-4 py-3 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/id-verification")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex-1 text-center">
            <h1 className="text-lg font-medium">Selfie Verification</h1>
            <StepIndicator currentStep={3} totalSteps={6} title="Selfie Check" />
          </div>
          <div className="w-8" />
        </div>
      </header>

      <main className="pt-28 px-4 pb-24">
        <section className="mb-8">
          <h2 className="text-xl mb-2">Upload Your Selfie</h2>
          <p className="text-neutral-400 text-sm">
            Please take a clear photo of your face
          </p>
        </section>

        <section className="space-y-6">
          <div className="border-2 border-dashed border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg p-4">
            <div className="text-center space-y-4">
              <div className="h-12 flex items-center justify-center">
                {uploadState.path ? (
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Check className="h-6 w-6 text-green-500" />
                  </div>
                ) : (
                  <Camera className="h-8 w-8 text-neutral-500" />
                )}
              </div>
              <div>
                <h3 className="mb-1">Selfie Photo</h3>
                <p className="text-neutral-400 text-sm mb-4">
                  Take or upload a photo of your face
                </p>
                <div className="flex gap-2">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={openCamera}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.uploading}
                  >
                    <Camera className="h-4 w-4" />
                    Take Photo
                  </motion.button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={handleFileInputChange}
                    className="hidden"
                    disabled={uploadState.uploading}
                  />
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={triggerFileInput}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.uploading}
                  >
                    <Upload className="h-4 w-4" />
                    Upload
                  </motion.button>
                </div>
                {uploadState.url && (
                  <div className="mt-4">
                    <img
                      src={uploadState.url}
                      alt="Selfie"
                      className="max-h-48 mx-auto rounded-lg border border-neutral-700"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="bg-neutral-800 rounded-lg p-4">
            <h4 className="text-sm mb-2">Photo Requirements:</h4>
            <ul className="text-xs text-neutral-400 space-y-1">
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                Clear, well-lit photo
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                Face centered and visible
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                Neutral expression
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                No sunglasses or hats
              </li>
            </ul>
          </div>
        </section>
      </main>

      <footer className="fixed bottom-0 w-full bg-neutral-900/90 backdrop-blur-lg border-t border-neutral-800 p-4">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          disabled={!uploadState.path}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white py-4 rounded-lg disabled:opacity-50"
        >
          Next
        </motion.button>
      </footer>

      <Dialog open={showCamera} onOpenChange={(open) => !open && stopCamera()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Take Selfie</DialogTitle>
          </DialogHeader>
          <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex justify-center gap-4 mt-4">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={stopCamera}
              className="bg-neutral-800 text-white px-6 py-2 rounded-lg flex items-center gap-2"
            >
              <X className="h-4 w-4" />
              Cancel
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleCameraCapture}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg flex items-center gap-2"
            >
              <Camera className="h-4 w-4" />
              Capture
            </motion.button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SelfieVerification;
