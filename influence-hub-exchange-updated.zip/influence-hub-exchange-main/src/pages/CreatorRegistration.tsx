import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import CountrySelector from "@/components/CountrySelector";
import StepIndicator from "@/components/StepIndicator";

interface RegistrationData {
  firstName: string;
  lastName: string;
  age: string;
  country: string;
  street: string;
  houseNumber: string;
  city: string;
  postalCode: string;
  phone: string;
  email: string;
  password: string;
}

const CreatorRegistration = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState<RegistrationData>(() => {
    const saved = localStorage.getItem('creator_registration');
    return saved ? JSON.parse(saved) : {
      firstName: "",
      lastName: "",
      age: "",
      country: "",
      street: "",
      houseNumber: "",
      city: "",
      postalCode: "",
      phone: "",
      email: "",
      password: "",
    };
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      if (parseInt(formData.age) < 18) {
        toast({
          variant: "destructive",
          title: "Invalid age",
          description: "You must be at least 18 years old to register",
        });
        return;
      }

      // Store the form data in localStorage
      localStorage.setItem('creator_registration', JSON.stringify(formData));
      
      // Navigate to ID verification (step 2)
      navigate("/id-verification");
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white px-4 py-6">
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex-1 text-center">
            <h1 className="text-xl tracking-wide">Registration</h1>
            <StepIndicator currentStep={1} totalSteps={6} title="Personal Information" />
          </div>
          <div className="w-8" />
        </div>
      </header>

      <main className="max-w-md mx-auto">
        <form onSubmit={handleNextStep} className="space-y-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">First Name</label>
              <input
                type="text"
                name="firstName"
                value={formData.firstName}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                placeholder="Enter your first name"
                required
              />
            </div>
            <div>
              <label className="block text-sm mb-2">Last Name</label>
              <input
                type="text"
                name="lastName"
                value={formData.lastName}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                placeholder="Enter your last name"
                required
              />
            </div>
            <div>
              <label className="block text-sm mb-2">Age</label>
              <input
                type="number"
                name="age"
                value={formData.age}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                placeholder="Enter your age"
                required
                min="18"
              />
            </div>
            <div className="flex flex-col space-y-2">
              <label className="text-sm">Country</label>
              <CountrySelector
                value={formData.country}
                onChange={(value) => 
                  setFormData(prev => ({ ...prev, country: value }))
                }
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-2">Street</label>
                <input
                  type="text"
                  name="street"
                  value={formData.street}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                  placeholder="Street name"
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-2">House Number</label>
                <input
                  type="text"
                  name="houseNumber"
                  value={formData.houseNumber}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                  placeholder="House number"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm mb-2">City</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                  placeholder="City"
                  required
                />
              </div>
              <div>
                <label className="block text-sm mb-2">Postal Code</label>
                <input
                  type="text"
                  name="postalCode"
                  value={formData.postalCode}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                  placeholder="Postal code"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-sm mb-2">Phone Number</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg"
                placeholder="Enter your phone number"
                required
              />
            </div>
          </div>

          <motion.button
            type="submit"
            whileTap={{ scale: 0.98 }}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white py-4 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isLoading ? (
              "Processing..."
            ) : (
              <>
                Next
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </motion.button>
        </form>
      </main>
    </div>
  );
};

export default CreatorRegistration;
