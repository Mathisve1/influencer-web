
import { useNavigate, useLocation } from "react-router-dom";

const Notifications = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isBusinessRoute = location.pathname.startsWith('/business');

  const handleBack = () => {
    if (isBusinessRoute) {
      navigate("/business/profile");
    } else {
      navigate("/profile");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center">
          <button 
            className="mr-4 hover:bg-neutral-800 p-2 rounded-full transition-colors"
            onClick={handleBack}
          >
            <i className="fa-solid fa-arrow-left text-xl"></i>
          </button>
          <h1 className="text-lg tracking-wide">Notification Settings</h1>
        </div>
      </header>

      <main className="px-4 py-6">
        <section className="mb-8">
          <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg mb-6">
            <div className="flex items-center gap-3">
              <i className="fa-solid fa-bell text-xl"></i>
              <span className="text-sm">All Notifications</span>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
            </label>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-sm text-neutral-400 mb-4 uppercase tracking-wider">Channels</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-mobile-screen text-xl"></i>
                <span className="text-sm">Push Notifications</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-envelope text-xl"></i>
                <span className="text-sm">Email Notifications</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-sm text-neutral-400 mb-4 uppercase tracking-wider">Messages</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-message text-xl"></i>
                <span className="text-sm">Message Notifications</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-bell text-xl"></i>
                <span className="text-sm">Sound Notifications</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-sm text-neutral-400 mb-4 uppercase tracking-wider">Task Notifications</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-list-check text-xl"></i>
                <span className="text-sm">New Task Assignments</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-clock text-xl"></i>
                <span className="text-sm">Task Deadlines</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
            <div className="flex items-center justify-between p-4 bg-neutral-800 rounded-lg">
              <div className="flex items-center gap-3">
                <i className="fa-solid fa-comments text-xl"></i>
                <span className="text-sm">Task Comments</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:ring-2 peer-focus:ring-neutral-600 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-neutral-600"></div>
              </label>
            </div>
          </div>
        </section>
      </main>

      <footer className="p-4 text-center text-neutral-500 text-xs border-t border-neutral-800">
        <p>Last updated: Jan 15, 2025</p>
      </footer>
    </div>
  );
};

export default Notifications;
