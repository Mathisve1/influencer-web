
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { JobCard } from "@/components/jobs/JobCard";
import { useState } from "react";
import { toast } from "sonner";

const SavedJobs = () => {
  const navigate = useNavigate();
  const [savedJobs, setSavedJobs] = useState([
    {
      id: 1,
      title: "YouTube Product Review",
      company: "Tech & Gaming Co.",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1",
      tags: ["YouTube", "Tech", "Gaming"],
      price: "$1000",
      deadline: "Apr 20, 2025"
    },
    {
      id: 2,
      title: "Instagram Story Campaign",
      company: "Fashion & Beauty Inc.",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=2",
      tags: ["Instagram", "Fashion", "Beauty"],
      price: "$500",
      deadline: "Mar 15, 2025"
    },
    {
      id: 3,
      title: "TikTok Dance Challenge",
      company: "Entertainment Studios",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=3",
      tags: ["TikTok", "Dance", "Entertainment"],
      price: "$750",
      deadline: "Feb 28, 2025"
    }
  ]);

  const handleUnsave = (jobId: number) => {
    setSavedJobs(prev => prev.filter(job => job.id !== jobId));
    toast.success("Job removed from saved jobs");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
            <button 
              className="p-2"
              onClick={() => navigate('/tasks')}
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-lg tracking-wide">Saved Jobs</h1>
          </div>
          <div className="text-sm text-neutral-400">{savedJobs.length} jobs</div>
        </div>
      </header>

      <main className="pt-20 px-4">
        <div className="space-y-4">
          {savedJobs.map((job) => (
            <div key={job.id} className="relative">
              <JobCard {...job} />
              <button
                className="absolute top-4 right-4 z-10 text-purple-400 hover:text-purple-300 transition-colors"
                onClick={() => handleUnsave(job.id)}
              >
                <i className="fa-solid fa-bookmark text-lg"></i>
              </button>
            </div>
          ))}
          {savedJobs.length === 0 && (
            <div className="text-center text-neutral-400 py-8">
              No saved jobs yet
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default SavedJobs;
