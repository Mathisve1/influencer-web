
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Upload, Image as ImageIcon, Loader2, ChevronRight } from "lucide-react";

interface PortfolioImage {
  url: string;
  path: string;
}

const EditProfile = () => {
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);
  const [portfolioImages, setPortfolioImages] = useState<PortfolioImage[]>([]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload only image files');
      return;
    }

    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size should be less than 5MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${crypto.randomUUID()}.${fileExt}`;

      const { error: uploadError, data } = await supabase.storage
        .from('portfolios')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      if (data) {
        const { data: urlData } = await supabase.storage
          .from('portfolios')
          .getPublicUrl(filePath);

        setPortfolioImages(prev => [...prev, {
          url: urlData.publicUrl,
          path: filePath
        }]);
        toast.success('Image uploaded successfully');
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error('Error uploading file');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteImage = async (path: string) => {
    try {
      const { error } = await supabase.storage
        .from('portfolios')
        .remove([path]);

      if (error) throw error;

      setPortfolioImages(prev => prev.filter(img => img.path !== path));
      toast.success('Image deleted successfully');
    } catch (error) {
      console.error('Error deleting file:', error);
      toast.error('Error deleting file');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 bg-neutral-900 p-4 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between">
          <button 
            className="p-2.5 text-white hover:bg-neutral-800 rounded-full transition-colors"
            onClick={() => navigate("/profile")}
          >
            <i className="fa-solid fa-arrow-left text-xl text-white"></i>
          </button>
          <div className="text-lg">Edit Profile</div>
          <button className="p-2 text-neutral-300">
            <i className="fa-solid fa-check"></i>
          </button>
        </div>
      </header>
      
      <main className="px-4 py-6 space-y-6">
        <section className="flex flex-col items-center space-y-4">
          <div className="relative">
            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" className="w-24 h-24 rounded-full bg-neutral-800" alt="Profile" />
            <button className="absolute bottom-0 right-0 p-2 bg-neutral-800 rounded-full border border-neutral-700">
              <i className="fa-solid fa-camera"></i>
            </button>
          </div>
        </section>
        <section className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Full Name</label>
            <input type="text" className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700" placeholder="Enter your full name" />
          </div>
          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Bio</label>
            <textarea className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 h-24" placeholder="Tell us about yourself"></textarea>
          </div>
        </section>
        <section className="space-y-4">
          <h2 className="text-lg">Contact Information</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-3 p-3 bg-neutral-800 rounded-lg border border-neutral-700">
              <i className="fa-solid fa-envelope w-6"></i>
              <input type="email" className="flex-1 bg-transparent" placeholder="Email address" />
            </div>
            <div className="flex items-center space-x-3 p-3 bg-neutral-800 rounded-lg border border-neutral-700">
              <i className="fa-solid fa-phone w-6"></i>
              <input type="tel" className="flex-1 bg-transparent" placeholder="Phone number" />
            </div>
          </div>
        </section>
        <section className="space-y-4">
          <h2 className="text-lg">Portfolio</h2>
          <div className="grid grid-cols-2 gap-4">
            {portfolioImages.map((image, index) => (
              <div key={index} className="relative aspect-square">
                <img
                  src={image.url}
                  alt={`Portfolio ${index + 1}`}
                  className="w-full h-full object-cover rounded-lg"
                />
                <button
                  className="absolute top-2 right-2 p-2 bg-neutral-800/80 rounded-full hover:bg-neutral-700/80 transition-colors"
                  onClick={() => handleDeleteImage(image.path)}
                >
                  <i className="fa-solid fa-trash-can text-sm"></i>
                </button>
              </div>
            ))}
            {portfolioImages.length < 6 && (
              <label className="aspect-square bg-neutral-800 rounded-lg flex flex-col items-center justify-center text-neutral-400 cursor-pointer hover:bg-neutral-700/80 transition-colors">
                <input
                  type="file"
                  className="hidden"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                />
                <ImageIcon className="w-8 h-8 mb-2" />
                <span className="text-sm">Add Image</span>
              </label>
            )}
          </div>
        </section>
        <section className="space-y-4">
          <h2 className="text-lg">Social Media</h2>
          <button
            onClick={() => navigate("/social-media-profiles")}
            className="w-full flex items-center justify-between p-3 bg-neutral-800 rounded-lg border border-neutral-700 text-left hover:bg-neutral-700/80 transition-colors"
          >
            <span>Social Media Profiles</span>
            <ChevronRight className="w-5 h-5 text-neutral-400" />
          </button>
        </section>
      </main>

      <footer className="p-4 border-t border-neutral-800">
        <button className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 text-center">
          Save Changes
        </button>
      </footer>
    </div>
  );
};

export default EditProfile;
