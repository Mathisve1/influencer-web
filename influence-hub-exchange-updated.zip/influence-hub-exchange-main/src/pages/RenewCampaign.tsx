
import { useNavigate, useParams } from "react-router-dom";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

const RenewCampaign = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const handleRenew = () => {
    // Here you would typically handle the campaign renewal
    // For now, we'll just navigate back
    navigate("/business/campaigns");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate("/business/campaigns/expired")}
              className="p-2 hover:text-neutral-300"
            >
              <i className="fa-solid fa-arrow-left"></i>
            </button>
            <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">
              Renew Campaign
            </div>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-24">
        <div className="space-y-6">
          <div className="bg-neutral-800 rounded-lg p-4">
            <h2 className="text-lg mb-4">Campaign Details</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-neutral-400 mb-2">New Duration</label>
                <select className="w-full bg-neutral-700 border border-neutral-600 rounded-lg p-3 text-sm">
                  <option value="30">30 Days</option>
                  <option value="60">60 Days</option>
                  <option value="90">90 Days</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-neutral-400 mb-2">Budget</label>
                <input 
                  type="number" 
                  placeholder="Enter budget" 
                  className="w-full bg-neutral-700 border border-neutral-600 rounded-lg p-3 text-sm"
                  defaultValue="5000"
                />
              </div>
            </div>
          </div>

          <div className="bg-neutral-800 rounded-lg p-4">
            <h2 className="text-lg mb-4">Previous Performance</h2>
            <div className="text-sm text-neutral-400 space-y-2">
              <div className="flex justify-between">
                <span>Previous Duration</span>
                <span>60 days</span>
              </div>
              <div className="flex justify-between">
                <span>Previous Budget</span>
                <span>$5,000</span>
              </div>
            </div>
          </div>

          <button 
            onClick={handleRenew}
            className="w-full bg-[#9b87f5] hover:bg-[#7E69AB] transition-colors text-white rounded-lg py-3 text-sm font-medium"
          >
            Confirm Renewal
          </button>
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default RenewCampaign;
