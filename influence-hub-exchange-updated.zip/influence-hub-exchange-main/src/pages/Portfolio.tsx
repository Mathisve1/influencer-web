
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2, Plus, ChevronLeft } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { SkillsList } from "@/components/profile/SkillsList";
import { PortfolioGrid } from "@/components/profile/PortfolioGrid";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

interface Skill {
  id: string;
  name: string;
  endorsement_count: number;
}

interface PortfolioItem {
  id: string;
  title: string;
  description?: string;
  image_url?: string;
  project_url?: string;
}

const Portfolio = () => {
  const navigate = useNavigate();
  const [skills, setSkills] = useState<Skill[]>([]);
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("portfolio");

  const fetchData = async () => {
    try {
      const [skillsResponse, portfolioResponse] = await Promise.all([
        supabase.from('skills').select('*').order('name', { ascending: true }),
        supabase.from('portfolio_items').select('*').order('created_at', { ascending: false })
      ]);

      if (skillsResponse.error) throw skillsResponse.error;
      if (portfolioResponse.error) throw portfolioResponse.error;

      setSkills(skillsResponse.data || []);
      setPortfolioItems(portfolioResponse.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-white" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 p-4 bg-neutral-900/80 backdrop-blur-lg border-b border-neutral-800 z-10">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => navigate(-1)}
              className="w-10 h-10 rounded-full bg-neutral-800 hover:bg-neutral-700 transition-colors flex items-center justify-center"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-semibold">Portfolio & Skills</h1>
          </div>
        </div>
      </header>

      <main className="pt-24 pb-24 px-4">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <Tabs 
              defaultValue="portfolio" 
              className="space-y-6"
              onValueChange={(value) => setActiveTab(value)}
            >
              <TabsList className="w-full grid grid-cols-2 bg-neutral-800 rounded-xl p-1">
                <TabsTrigger 
                  value="portfolio" 
                  className="rounded-lg data-[state=active]:bg-neutral-700"
                >
                  Portfolio
                </TabsTrigger>
                <TabsTrigger 
                  value="skills" 
                  className="rounded-lg data-[state=active]:bg-neutral-700"
                >
                  Skills
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="portfolio" className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-lg font-medium">Portfolio Items</h2>
                    <p className="text-sm text-neutral-400 mt-1">
                      Showcase your best work and projects
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate("/portfolio/add")}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add Item
                  </Button>
                </div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <PortfolioGrid 
                    items={portfolioItems}
                    onItemAdded={fetchData}
                  />
                </motion.div>
              </TabsContent>
              
              <TabsContent value="skills" className="space-y-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-lg font-medium">Skills</h2>
                    <p className="text-sm text-neutral-400 mt-1">
                      Highlight your expertise and technologies
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => navigate("/portfolio/add-skill")}
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add Skill
                  </Button>
                </div>
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  <SkillsList 
                    skills={skills}
                    onSkillAdded={fetchData}
                  />
                </motion.div>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default Portfolio;
