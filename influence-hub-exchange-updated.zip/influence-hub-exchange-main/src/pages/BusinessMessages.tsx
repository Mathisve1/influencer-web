import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PenSquare, Search } from "lucide-react";
import { Command, CommandInput, CommandList, CommandEmpty } from "@/components/ui/command";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

interface Chat {
  id: string;
  creator: string;
  avatar: string;
  lastMessage: string;
  time: string;
  status: "online" | "offline" | "away";
  unread?: boolean;
  folder?: string;
}

const BusinessMessages = () => {
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const chats: Chat[] = [
    {
      id: "john-doe",
      creator: "John Doe",
      avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=John",
      lastMessage: "Regarding your latest campaign...",
      time: "2m ago",
      status: "online",
      unread: true,
      folder: "Active Creators"
    },
    {
      id: "sarah-smith",
      creator: "Sarah Smith",
      avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=Sarah",
      lastMessage: "Portfolio review completed",
      time: "1h ago",
      status: "away",
      folder: "Potential Creators"
    },
    {
      id: "mike-brown",
      creator: "Mike Brown",
      avatar: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=Mike",
      lastMessage: "Content delivery status",
      time: "5h ago",
      status: "offline",
      folder: "Active Creators"
    }
  ];

  const folders = Array.from(
    new Set(
      chats
        .filter(chat => chat.folder)
        .map(chat => chat.folder)
    )
  ) as string[];
  
  const filteredChats = chats.filter(chat => 
    chat.creator.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chat.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusColor = (status: Chat["status"]) => {
    switch (status) {
      case "online":
        return "bg-green-500";
      case "away":
        return "bg-yellow-500";
      case "offline":
        return "bg-neutral-500";
    }
  };

  const truncateMessage = (message: string, length: number = 45) => {
    return message.length > length ? `${message.substring(0, length)}...` : message;
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-neutral-900 to-neutral-900/95 backdrop-blur-sm border-b border-neutral-800">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=144" 
                 className="w-8 h-8 rounded-full ring-2 ring-neutral-700/50" />
            <div className="text-lg tracking-wide gradient-text font-semibold">Creator Messages</div>
          </div>
          <div className="flex items-center gap-2">
            <button 
              className="p-2 text-neutral-400 hover:text-white transition-colors hover:bg-neutral-800/50 rounded-full"
              onClick={() => setSearchOpen(!searchOpen)}
            >
              <Search className="w-5 h-5" />
            </button>
            <button className="p-2 text-neutral-400 hover:text-white transition-colors hover:bg-neutral-800/50 rounded-full">
              <PenSquare className="w-5 h-5" />
            </button>
          </div>
        </div>
        {searchOpen && (
          <div className="px-4 pb-4 animate-fade-in">
            <Command className="rounded-lg border border-neutral-700">
              <CommandInput 
                placeholder="Search creators..." 
                value={searchQuery}
                onValueChange={setSearchQuery}
                className="h-9"
              />
              <CommandList>
                <CommandEmpty>No results found.</CommandEmpty>
              </CommandList>
            </Command>
          </div>
        )}
      </header>

      <main className="mt-16 pb-20">
        {folders.length > 0 ? (
          folders.map(folder => (
            <div key={folder} className="mb-6 animate-fade-in">
              <div className="px-4 py-2 text-sm font-medium text-neutral-400">{folder}</div>
              <div className="space-y-2 px-4">
                {filteredChats
                  .filter(chat => chat.folder === folder)
                  .map(chat => (
                    <div 
                      key={chat.id}
                      className="p-4 bg-neutral-800/50 backdrop-blur-sm rounded-lg cursor-pointer 
                               hover:bg-neutral-700/50 transition-all duration-300 hover:scale-[1.02]
                               border border-neutral-700/50 hover:border-neutral-600"
                      onClick={() => navigate(`/business/messages/${chat.id}`)}
                    >
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img src={chat.avatar} className="w-12 h-12 rounded-full ring-2 ring-neutral-700/50" />
                          <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 
                                        border-neutral-800 ${getStatusColor(chat.status)} 
                                        ${chat.status === 'online' ? 'animate-pulse' : ''}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center mb-1">
                            <h3 className="flex items-center gap-2 font-medium">
                              {chat.creator}
                              {chat.unread && (
                                <span className="w-2 h-2 rounded-full bg-brand-gradient-start animate-pulse" />
                              )}
                            </h3>
                            <span className="text-xs text-neutral-400 shrink-0">{chat.time}</span>
                          </div>
                          <p className="text-sm text-neutral-400 truncate">
                            {truncateMessage(chat.lastMessage)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          ))
        ) : (
          <div className="p-4 text-center text-neutral-400">No messages found</div>
        )}
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default BusinessMessages;
