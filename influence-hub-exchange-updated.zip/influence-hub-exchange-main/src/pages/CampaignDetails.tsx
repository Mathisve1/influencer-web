
import { useNavigate } from "react-router-dom";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

const CampaignDetails = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="p-4 flex items-center justify-between">
          <button 
            className="p-2"
            onClick={() => navigate("/business/campaigns")}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg tracking-wide">Campaign Details</div>
          <button className="p-2">
            <i className="fa-solid fa-ellipsis-vertical"></i>
          </button>
        </div>
      </header>
      <main className="pt-20 pb-24">
        <div className="px-4 mb-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-xl tracking-wide mb-1">Summer Collection 2025</h1>
              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs bg-neutral-700">
                <span className="w-2 h-2 bg-neutral-400 rounded-full mr-2"></span>
                Ongoing
              </span>
            </div>
            <button className="px-4 py-2 border border-neutral-700 rounded-lg text-sm hover:bg-neutral-800 transition-colors">
              Pause Campaign
            </button>
          </div>
        </div>
        
        <div className="px-4 mb-6">
          <div className="bg-neutral-800 rounded-xl p-4">
            <h2 className="text-sm text-neutral-400 mb-3">Budget Overview</h2>
            <div className="flex justify-between mb-2">
              <span className="text-sm">Used: $15,750</span>
              <span className="text-sm">Remaining: $4,250</span>
            </div>
            <div className="w-full bg-neutral-700 rounded-full h-2">
              <div className="bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] h-2 rounded-full w-3/4"></div>
            </div>
          </div>
        </div>

        <div className="px-4 mb-6">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-neutral-800 p-3 rounded-xl text-center">
              <i className="fa-solid fa-users mb-2 text-lg"></i>
              <div className="text-lg mb-1">45.2K</div>
              <div className="text-xs text-neutral-400">Reach</div>
            </div>
            <div className="bg-neutral-800 p-3 rounded-xl text-center">
              <i className="fa-solid fa-heart mb-2 text-lg"></i>
              <div className="text-lg mb-1">8.7%</div>
              <div className="text-xs text-neutral-400">Engagement</div>
            </div>
            <div className="bg-neutral-800 p-3 rounded-xl text-center">
              <i className="fa-solid fa-chart-simple mb-2 text-lg"></i>
              <div className="text-lg mb-1">1.2K</div>
              <div className="text-xs text-neutral-400">Conversions</div>
            </div>
          </div>
        </div>

        <div className="px-4 mb-6">
          <h2 className="text-lg mb-4">Recent Updates</h2>
          <div className="space-y-4">
            <div className="bg-neutral-800 p-4 rounded-xl">
              <div className="flex items-center mb-3">
                <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1" alt="Avatar" className="w-10 h-10 rounded-full mr-3" />
                <div>
                  <div className="text-sm">Sarah Johnson</div>
                  <div className="text-xs text-neutral-400">2 hours ago</div>
                </div>
              </div>
              <p className="text-sm text-neutral-300">Content shot and ready for review. Will upload by EOD.</p>
            </div>
            <div className="bg-neutral-800 p-4 rounded-xl">
              <div className="flex items-center mb-3">
                <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=2" alt="Avatar" className="w-10 h-10 rounded-full mr-3" />
                <div>
                  <div className="text-sm">Mike Chen</div>
                  <div className="text-xs text-neutral-400">5 hours ago</div>
                </div>
              </div>
              <p className="text-sm text-neutral-300">Post scheduled for tomorrow at 2 PM EST.</p>
            </div>
          </div>
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default CampaignDetails;
