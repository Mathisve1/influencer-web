
import { useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import StepIndicator from "@/components/StepIndicator";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";

const EmailPasswordPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      toast({
        variant: "destructive",
        title: "Required fields",
        description: "Please fill in all fields",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      // Create the user account in Supabase
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/influencer/tasks`
        }
      });

      if (error) throw error;

      if (data.user) {
        // Show success message
        toast({
          title: "Account created successfully!",
          description: "Welcome to TRACE",
        });

        // Get registration data from localStorage
        const registrationData = localStorage.getItem('creator_registration');
        if (registrationData) {
          const parsedData = JSON.parse(registrationData);
          
          // Update the profile with registration data
          const { error: profileError } = await supabase
            .from('profiles')
            .update({
              first_name: parsedData.firstName,
              last_name: parsedData.lastName,
              age: parseInt(parsedData.age),
              country: parsedData.country,
              address: `${parsedData.street} ${parsedData.houseNumber}, ${parsedData.city} ${parsedData.postalCode}`,
              phone: parsedData.phone,
            })
            .eq('id', data.user.id);

          if (profileError) {
            console.error('Error updating profile:', profileError);
          }

          // Clear the registration data from localStorage
          localStorage.removeItem('creator_registration');
        }

        // Redirect to the influencer tasks page
        navigate("/influencer/tasks");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create account. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white px-4 py-6">
      <header className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/social-media-connect")}
            className="p-2"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-neutral-800 flex items-center justify-center">
              <i className="fa-regular fa-user text-neutral-400"></i>
            </div>
          </div>
        </div>
        <StepIndicator currentStep={6} totalSteps={6} title="Create Account" />
        <h1 className="text-2xl font-medium tracking-wide mb-2">Create Account</h1>
        <p className="text-neutral-400">
          Enter your email and create a password to complete your registration.
        </p>
      </header>

      <main>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="text-sm text-neutral-400 block mb-2">
              Email Address
            </label>
            <input
              type="email"
              className="w-full bg-neutral-700 rounded-lg p-3"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="text-sm text-neutral-400 block mb-2">
              Password
            </label>
            <input
              type="password"
              className="w-full bg-neutral-700 rounded-lg p-3"
              placeholder="Create a password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
        </form>
      </main>

      <footer className="mt-8">
        <button 
          onClick={handleSubmit}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white rounded-lg py-4 mb-4 hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {isLoading ? "Creating Account..." : "Create Account"}
        </button>
        <p className="text-center text-sm text-neutral-400">
          By creating an account, you agree to our Terms and Conditions.
        </p>
      </footer>
    </div>
  );
};

export default EmailPasswordPage;
