import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Camera, Upload, Check, X } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import StepIndicator from "@/components/StepIndicator";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface UploadState {
  front: { uploading: boolean; path: string | null; url: string | null };
  back: { uploading: boolean; path: string | null; url: string | null };
}

const IdVerification = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const videoRef = useRef<HTMLVideoElement>(null);
  const frontFileInputRef = useRef<HTMLInputElement>(null);
  const backFileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [activeUploadSide, setActiveUploadSide] = useState<'front' | 'back' | null>(null);
  const [uploadState, setUploadState] = useState<UploadState>({
    front: { uploading: false, path: null, url: null },
    back: { uploading: false, path: null, url: null },
  });

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: "environment" } 
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Camera error",
        description: "Unable to access camera. Please check permissions.",
      });
      console.error('Error accessing camera:', error);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setShowCamera(false);
    setActiveUploadSide(null);
  };

  const handleCameraCapture = async () => {
    if (!videoRef.current || !activeUploadSide) return;

    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(videoRef.current, 0, 0);
    
    canvas.toBlob(async (blob) => {
      if (!blob || !activeUploadSide) return;
      
      const file = new File([blob], `camera-capture-${Date.now()}.jpg`, { type: 'image/jpeg' });
      await handleFileUpload(file, activeUploadSide);
      stopCamera();
    }, 'image/jpeg', 0.8);
  };

  const getImageUrl = async (path: string) => {
    try {
      const { data } = await supabase.storage
        .from('id-documents')
        .createSignedUrl(path, 3600);
      
      return data?.signedUrl || null;
    } catch (error) {
      console.error('Error getting signed URL:', error);
      return null;
    }
  };

  const handleFileUpload = async (file: File, side: 'front' | 'back') => {
    try {
      if (!file.type.match(/^image\/(jpeg|png)$/)) {
        toast({
          variant: "destructive",
          title: "Invalid file type",
          description: "Please upload a JPEG or PNG file",
        });
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Maximum file size is 5MB",
        });
        return;
      }

      setUploadState(prev => ({
        ...prev,
        [side]: { ...prev[side], uploading: true }
      }));

      const tempId = `temp-${Date.now()}`;
      const fileName = `${tempId}/${side}-${Date.now()}.${file.name.split('.').pop()}`;
      
      const { error: uploadError } = await supabase.storage
        .from('id-documents')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const url = await getImageUrl(fileName);

      setUploadState(prev => ({
        ...prev,
        [side]: { uploading: false, path: fileName, url }
      }));

      toast({
        title: "Upload successful",
        description: `${side.charAt(0).toUpperCase() + side.slice(1)} side uploaded successfully`,
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error.message,
      });
      setUploadState(prev => ({
        ...prev,
        [side]: { ...prev[side], uploading: false }
      }));
    }
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>, side: 'front' | 'back') => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileUpload(file, side);
    }
  };

  const triggerFileInput = (side: 'front' | 'back') => {
    if (side === 'front' && frontFileInputRef.current) {
      frontFileInputRef.current.click();
    } else if (side === 'back' && backFileInputRef.current) {
      backFileInputRef.current.click();
    }
  };

  const openUploadDialog = (side: 'front' | 'back') => {
    setActiveUploadSide(side);
    setShowCamera(true);
    startCamera();
  };

  const handleSubmit = async () => {
    try {
      if (!uploadState.front.path || !uploadState.back.path) {
        toast({
          variant: "destructive",
          title: "Missing files",
          description: "Please upload both sides of your ID",
        });
        return;
      }

      localStorage.setItem('id_verification_front', uploadState.front.path);
      localStorage.setItem('id_verification_back', uploadState.back.path);

      navigate("/selfie-verification");
    } catch (error: any) {
      console.error('Submission error:', error);
      toast({
        variant: "destructive",
        title: "Submission failed",
        description: error.message,
      });
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white px-4 py-6">
      <header className="fixed top-0 w-full bg-neutral-900/90 backdrop-blur-lg border-b border-neutral-800 px-4 py-3 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/creator-registration")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex-1 text-center">
            <h1 className="text-lg font-medium">ID Verification</h1>
            <StepIndicator currentStep={2} totalSteps={6} title="Identity Check" />
          </div>
          <div className="w-8" />
        </div>
      </header>

      <main className="pt-28 px-4 pb-24">
        <section className="mb-8">
          <h2 className="text-xl mb-2">Upload Your ID</h2>
          <p className="text-neutral-400 text-sm">
            Please upload clear photos of both sides of your ID or passport
          </p>
        </section>

        <section className="space-y-6">
          <div className="border-2 border-dashed border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg p-4">
            <div className="text-center space-y-4">
              <div className="h-12 flex items-center justify-center">
                {uploadState.front.path ? (
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Check className="h-6 w-6 text-green-500" />
                  </div>
                ) : (
                  <Camera className="h-8 w-8 text-neutral-500" />
                )}
              </div>
              <div>
                <h3 className="mb-1">Front Side</h3>
                <p className="text-neutral-400 text-sm mb-4">
                  Upload the front of your ID
                </p>
                <div className="flex gap-2">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => openUploadDialog('front')}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.front.uploading}
                  >
                    <Camera className="h-4 w-4" />
                    Take Photo
                  </motion.button>
                  <input
                    ref={frontFileInputRef}
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={(e) => handleFileInputChange(e, 'front')}
                    className="hidden"
                    disabled={uploadState.front.uploading}
                  />
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => triggerFileInput('front')}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.front.uploading}
                  >
                    <Upload className="h-4 w-4" />
                    Upload
                  </motion.button>
                </div>
                {uploadState.front.url && (
                  <div className="mt-4">
                    <img
                      src={uploadState.front.url}
                      alt="Front of ID"
                      className="max-h-48 mx-auto rounded-lg border border-neutral-700"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="border-2 border-dashed border-neutral-700 hover:border-brand-gradient-end/50 transition-colors rounded-lg p-4">
            <div className="text-center space-y-4">
              <div className="h-12 flex items-center justify-center">
                {uploadState.back.path ? (
                  <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <Check className="h-6 w-6 text-green-500" />
                  </div>
                ) : (
                  <Camera className="h-8 w-8 text-neutral-500" />
                )}
              </div>
              <div>
                <h3 className="mb-1">Back Side</h3>
                <p className="text-neutral-400 text-sm mb-4">
                  Upload the back of your ID
                </p>
                <div className="flex gap-2">
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => openUploadDialog('back')}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.back.uploading}
                  >
                    <Camera className="h-4 w-4" />
                    Take Photo
                  </motion.button>
                  <input
                    ref={backFileInputRef}
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={(e) => handleFileInputChange(e, 'back')}
                    className="hidden"
                    disabled={uploadState.back.uploading}
                  />
                  <motion.button
                    whileTap={{ scale: 0.98 }}
                    onClick={() => triggerFileInput('back')}
                    className="flex-1 bg-neutral-800 text-white px-4 py-3 rounded-lg flex items-center justify-center gap-2"
                    disabled={uploadState.back.uploading}
                  >
                    <Upload className="h-4 w-4" />
                    Upload
                  </motion.button>
                </div>
                {uploadState.back.url && (
                  <div className="mt-4">
                    <img
                      src={uploadState.back.url}
                      alt="Back of ID"
                      className="max-h-48 mx-auto rounded-lg border border-neutral-700"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="bg-neutral-800 rounded-lg p-4">
            <h4 className="text-sm mb-2">File Requirements:</h4>
            <ul className="text-xs text-neutral-400 space-y-1">
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                JPEG or PNG format only
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                Maximum file size: 5MB
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                Clear, well-lit photo
              </li>
              <li className="flex items-center gap-2">
                <Check className="h-3 w-3" />
                All corners visible
              </li>
            </ul>
          </div>
        </section>
      </main>

      <footer className="fixed bottom-0 w-full bg-neutral-900/90 backdrop-blur-lg border-t border-neutral-800 p-4">
        <motion.button
          whileTap={{ scale: 0.98 }}
          onClick={handleSubmit}
          disabled={!uploadState.front.path || !uploadState.back.path}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white py-4 rounded-lg disabled:opacity-50"
        >
          Next
        </motion.button>
      </footer>

      <Dialog open={showCamera} onOpenChange={(open) => !open && stopCamera()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Take Photo</DialogTitle>
          </DialogHeader>
          <div className="relative aspect-video bg-black rounded-lg overflow-hidden">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex justify-center gap-4 mt-4">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={stopCamera}
              className="bg-neutral-800 text-white px-6 py-2 rounded-lg flex items-center gap-2"
            >
              <X className="h-4 w-4" />
              Cancel
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={handleCameraCapture}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg flex items-center gap-2"
            >
              <Camera className="h-4 w-4" />
              Capture
            </motion.button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default IdVerification;
