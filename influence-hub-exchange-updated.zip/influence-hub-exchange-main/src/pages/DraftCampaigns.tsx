
import { BusinessNavigation } from "@/components/business/BusinessNavigation";
import { CampaignHeader } from "@/components/campaign/CampaignHeader";
import { useNavigate } from "react-router-dom";

const DraftCampaigns = () => {
  const navigate = useNavigate();
  const draftCampaigns = [
    {
      id: "1",
      title: "Summer Collection Launch",
      status: "In Progress",
      lastEdited: "Jan 15, 2025",
      budget: 5000,
    },
    {
      id: "2",
      title: "Influencer Partnership Q1",
      status: "Almost Ready",
      lastEdited: "Jan 10, 2025",
      budget: 10000,
    },
  ];

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">TRACE</div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-regular fa-bell"></i>
            </button>
            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" alt="Profile" className="w-8 h-8 rounded-full"/>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-24">
        <CampaignHeader activeCampaigns={4} activeTab="draft" />
        
        <div className="space-y-4">
          {draftCampaigns.map((campaign) => (
            <div key={campaign.id} className="p-4 bg-neutral-800 rounded-lg border border-neutral-700">
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-lg">{campaign.title}</h3>
                <span className="px-2 py-1 bg-neutral-700 rounded text-xs">{campaign.status}</span>
              </div>
              <div className="text-neutral-400 text-sm space-y-2 mb-4">
                <p>Last edited: {campaign.lastEdited}</p>
                <p>Budget: ${campaign.budget.toLocaleString()}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button 
                  className="px-3 py-1.5 bg-neutral-700 rounded text-xs hover:bg-neutral-600 transition-colors"
                  onClick={() => navigate(`/business/campaigns/edit/${campaign.id}`)}
                >
                  <i className="fa-solid fa-pen-to-square mr-1"></i>Edit
                </button>
                <button className="px-3 py-1.5 bg-neutral-700 rounded text-xs hover:bg-neutral-600 transition-colors">
                  <i className="fa-solid fa-trash mr-1"></i>Delete
                </button>
                <button className="px-3 py-1.5 border border-neutral-600 rounded text-xs hover:bg-neutral-700 transition-colors">
                  Submit
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default DraftCampaigns;
