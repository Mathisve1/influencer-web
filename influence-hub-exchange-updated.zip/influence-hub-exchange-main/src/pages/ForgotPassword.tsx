
import { motion } from "framer-motion";
import { ArrowLeft, Mail, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: error.message,
        });
      } else {
        setIsSuccess(true);
        toast({
          title: "Reset link sent",
          description: "Check your email for the password reset link",
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "An unexpected error occurred",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-brand-black text-white px-4 py-8">
      {/* Back Button */}
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={() => navigate("/login")}
        className="mb-8 p-2 text-neutral-400 hover:text-white"
      >
        <ArrowLeft className="h-5 w-5" />
      </motion.button>

      {/* Header */}
      <div className="mb-12">
        <div className="text-center">
          <div className="bg-neutral-800 w-16 h-16 mx-auto rounded-xl flex items-center justify-center mb-4">
            <Zap className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-white text-2xl tracking-wide mb-2">Reset Password</h1>
          <p className="text-neutral-400 text-sm">
            Enter your email address and we'll send you a link to reset your password.
          </p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleResetPassword} className="max-w-[320px] mx-auto space-y-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm text-neutral-400 mb-2">Email</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-neutral-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded-lg pl-10 pr-4 py-3 text-white"
                placeholder="name@company.com"
                required
              />
            </div>
          </div>
        </div>

        {isSuccess && (
          <div className="bg-neutral-800 border border-neutral-700 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-neutral-400" />
              <p className="text-sm text-neutral-300">
                We have sent you a reset link. Please check your email.
              </p>
            </div>
          </div>
        )}

        <motion.button
          type="submit"
          disabled={isLoading}
          whileTap={{ scale: 0.98 }}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white py-4 rounded-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "Sending..." : "Send Reset Link"}
        </motion.button>

        <div className="text-center">
          <button
            type="button"
            onClick={() => navigate("/login")}
            className="text-sm text-neutral-400 hover:text-white flex items-center justify-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to login
          </button>
        </div>
      </form>

      {/* Footer */}
      <div className="mt-12 text-center">
        <p className="text-neutral-500 text-xs">
          &copy; 2025 Trace. All rights reserved.
        </p>
      </div>
    </div>
  );
};

export default ForgotPassword;
