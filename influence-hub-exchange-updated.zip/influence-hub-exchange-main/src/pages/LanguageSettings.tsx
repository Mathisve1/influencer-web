
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import { Language } from "@/contexts/translations/types";

const LanguageSettings = () => {
  const navigate = useNavigate();
  const { language, setLanguage, t } = useLanguage();

  const handleLanguageChange = async (newLanguage: Language) => {
    await setLanguage(newLanguage);
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center">
          <button 
            className="mr-4"
            onClick={() => navigate("/profile")}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg tracking-wide">{t('languageSettings')}</div>
        </div>
      </header>

      <main className="px-4 py-8">
        <div className="mb-8">
          <h1 className="text-2xl tracking-wide mb-3">{t('selectLanguage')}</h1>
          <p className="text-neutral-400 text-sm">{t('chooseLanguage')}</p>
        </div>

        <div className="space-y-3">
          <div className="group">
            <button 
              onClick={() => handleLanguageChange('en')}
              className={`w-full p-4 bg-neutral-800 rounded-lg border ${language === 'en' ? 'border-brand-gradient-end' : 'border-neutral-700'} flex items-center justify-between`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center">
                  <span className="text-lg">🇬🇧</span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-base">{t('english')}</span>
                  <span className="text-xs text-neutral-400">{t('englishUS')}</span>
                </div>
              </div>
              {language === 'en' && <i className="fa-solid fa-check text-brand-gradient-end"></i>}
            </button>
          </div>

          <div className="group">
            <button 
              onClick={() => handleLanguageChange('fr')}
              className={`w-full p-4 bg-neutral-800 rounded-lg border ${language === 'fr' ? 'border-brand-gradient-end' : 'border-neutral-700'} flex items-center justify-between`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center">
                  <span className="text-lg">🇫🇷</span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-base">{t('français')}</span>
                  <span className="text-xs text-neutral-400">{t('french')}</span>
                </div>
              </div>
              {language === 'fr' && <i className="fa-solid fa-check text-brand-gradient-end"></i>}
            </button>
          </div>

          <div className="group">
            <button 
              onClick={() => handleLanguageChange('nl')}
              className={`w-full p-4 bg-neutral-800 rounded-lg border ${language === 'nl' ? 'border-brand-gradient-end' : 'border-neutral-700'} flex items-center justify-between`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center">
                  <span className="text-lg">🇳🇱</span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-base">{t('nederlands')}</span>
                  <span className="text-xs text-neutral-400">{t('dutch')}</span>
                </div>
              </div>
              {language === 'nl' && <i className="fa-solid fa-check text-brand-gradient-end"></i>}
            </button>
          </div>

          <div className="group">
            <button 
              onClick={() => handleLanguageChange('de')}
              className={`w-full p-4 bg-neutral-800 rounded-lg border ${language === 'de' ? 'border-brand-gradient-end' : 'border-neutral-700'} flex items-center justify-between`}
            >
              <div className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center">
                  <span className="text-lg">🇩🇪</span>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-base">{t('deutsch')}</span>
                  <span className="text-xs text-neutral-400">{t('german')}</span>
                </div>
              </div>
              {language === 'de' && <i className="fa-solid fa-check text-brand-gradient-end"></i>}
            </button>
          </div>
        </div>

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-neutral-900 border-t border-neutral-800">
          <button 
            onClick={() => navigate("/profile")}
            className="w-full py-4 bg-neutral-800 rounded-lg border border-neutral-700 text-sm tracking-wide"
          >
            {t('applyChanges')}
          </button>
        </div>
      </main>
    </div>
  );
};

export default LanguageSettings;
