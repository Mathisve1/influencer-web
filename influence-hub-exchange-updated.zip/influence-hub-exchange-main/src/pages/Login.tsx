
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Login = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        variant: "destructive",
        title: "Required fields",
        description: "Please fill in all fields",
      });
      return;
    }

    try {
      setIsLoading(true);
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      if (data.user) {
        toast({
          title: "Login successful",
          description: "Welcome back!",
        });
        navigate("/tasks");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to login. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white px-4 py-6">
      <header className="mb-6">
        <h1 className="text-2xl font-medium tracking-wide mb-2">Welcome Back</h1>
        <p className="text-neutral-400">
          Sign in to your account to continue
        </p>
      </header>

      <main>
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="text-sm text-neutral-400 block mb-2">
              Email Address
            </label>
            <input
              type="email"
              className="w-full bg-neutral-700 rounded-lg p-3"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="text-sm text-neutral-400 block mb-2">
              Password
            </label>
            <input
              type="password"
              className="w-full bg-neutral-700 rounded-lg p-3"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Link 
            to="/forgot-password"
            className="block text-sm text-neutral-400 hover:text-white transition-colors mt-2"
          >
            Forgot password?
          </Link>
        </form>
      </main>

      <footer className="mt-8">
        <button 
          onClick={handleLogin}
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white rounded-lg py-4 mb-4 hover:opacity-90 transition-opacity disabled:opacity-50"
        >
          {isLoading ? "Signing in..." : "Sign In"}
        </button>
        <p className="text-center text-sm text-neutral-400">
          Don't have an account?{" "}
          <Link to="/" className="text-white hover:opacity-90">
            Sign up
          </Link>
        </p>
      </footer>
    </div>
  );
};

export default Login;
