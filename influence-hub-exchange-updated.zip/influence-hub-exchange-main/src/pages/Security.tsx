import { useNavigate, useLocation } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const Security = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [isDeactivateOpen, setIsDeactivateOpen] = useState(false);
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [isLogoutOpen, setIsLogoutOpen] = useState(false);
  const [staySignedIn, setStaySignedIn] = useState(false);
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const isBusinessRoute = location.pathname.startsWith('/business');

  const handleBack = () => {
    if (isBusinessRoute) {
      navigate("/business/profile");
    } else {
      navigate("/profile");
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast.error("New passwords don't match");
      return;
    }

    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) throw error;

      toast.success("Password updated successfully");
      setIsChangePasswordOpen(false);
      setOldPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (error: any) {
      toast.error(error.message || "Failed to update password");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOutAllDevices = async () => {
    try {
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      if (error) throw error;
      toast.success("Signed out from all devices");
      setIsLogoutOpen(false);
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Failed to sign out from all devices");
    }
  };

  const handleTemporaryDeactivate = async () => {
    try {
      setIsDeactivateOpen(false);
      toast.success("Account temporarily deactivated");
      await supabase.auth.signOut();
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Failed to deactivate account");
    }
  };

  const handleDeleteAccount = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("No user found");

      const { error: deleteError } = await supabase
        .from('profiles')
        .delete()
        .eq('id', user.id);

      if (deleteError) throw deleteError;

      const { error } = await supabase.auth.admin.deleteUser(user.id);
      if (error) throw error;

      setIsDeleteOpen(false);
      toast.success("Account deleted successfully");
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Failed to delete account");
    }
  };

  return (
    <div className="min-h-screen bg-brand-black text-white">
      <header className="sticky top-0 z-50 bg-brand-black p-4 border-b border-brand-gray-light">
        <div className="flex items-center justify-between">
          <button 
            className="p-2.5 text-white hover:bg-brand-gray-light rounded-full transition-colors"
            onClick={handleBack}
          >
            <i className="fa-solid fa-arrow-left text-xl"></i>
          </button>
          <div className="text-lg tracking-wide font-medium">Security Settings</div>
          <div className="w-8"></div>
        </div>
      </header>

      <main className="px-4 py-6">
        <section className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl tracking-wide font-medium">Password</h2>
            <button 
              onClick={() => setIsChangePasswordOpen(true)}
              className="px-4 py-2 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors gradient-border"
            >
              Change
            </button>
          </div>
          <div className="bg-brand-gray-light rounded-lg p-4">
            <div className="flex items-center gap-3 mb-2">
              <i className="fa-solid fa-lock text-brand-blue"></i>
              <span className="text-sm">Last changed 30 days ago</span>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl tracking-wide font-medium">Two-Factor Auth</h2>
            <label className="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" className="sr-only peer" />
              <div className="w-11 h-6 bg-brand-gray-light peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-gradient-start"></div>
            </label>
          </div>
          <div className="bg-brand-gray-light rounded-lg p-4">
            <div className="flex items-center gap-3 mb-2">
              <i className="fa-solid fa-shield-halved text-brand-blue"></i>
              <span className="text-sm">Protect your account with 2FA</span>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-xl tracking-wide mb-6 font-medium">Account Status</h2>
          <div className="bg-brand-gray-light rounded-lg">
            <button 
              onClick={() => setIsDeactivateOpen(true)}
              className="w-full p-4 flex items-center justify-between hover:bg-brand-gray-dark transition-colors"
            >
              <div className="flex items-center gap-3">
                <i className="fa-regular fa-clock text-brand-blue"></i>
                <span>Temporarily Deactivate</span>
              </div>
              <i className="fa-solid fa-chevron-right text-neutral-500"></i>
            </button>
            <div className="border-t border-neutral-700">
              <button 
                onClick={() => setIsDeleteOpen(true)}
                className="w-full p-4 flex items-center justify-between text-red-400 hover:bg-brand-gray-dark transition-colors"
              >
                <div className="flex items-center gap-3">
                  <i className="fa-regular fa-trash-can"></i>
                  <span>Delete Account</span>
                </div>
                <i className="fa-solid fa-chevron-right text-neutral-500"></i>
              </button>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-xl tracking-wide mb-6 font-medium">Active Sessions</h2>
          <div className="space-y-4">
            <div className="bg-brand-gray-light rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <i className="fa-solid fa-mobile-screen text-brand-blue"></i>
                  <div>
                    <p className="text-sm">iPhone 14 Pro</p>
                    <p className="text-xs text-neutral-400">New York, US • Now</p>
                  </div>
                </div>
                <div className="bg-brand-gradient-start/20 text-brand-gradient-start px-2 py-1 rounded text-xs">Current</div>
              </div>
            </div>
            <div className="bg-brand-gray-light rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <i className="fa-solid fa-laptop text-brand-blue"></i>
                  <div>
                    <p className="text-sm">MacBook Pro</p>
                    <p className="text-xs text-neutral-400">New York, US • 2h ago</p>
                  </div>
                </div>
              </div>
            </div>
            <button 
              onClick={() => setIsLogoutOpen(true)}
              className="w-full mt-4 px-4 py-3 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors gradient-border"
            >
              Sign Out All Devices
            </button>
          </div>
        </section>
      </main>

      <Dialog open={isChangePasswordOpen} onOpenChange={setIsChangePasswordOpen}>
        <DialogContent className="bg-brand-black border border-brand-gray-light">
          <DialogHeader>
            <DialogTitle className="text-white">Change Password</DialogTitle>
          </DialogHeader>
          <form onSubmit={handlePasswordChange} className="space-y-4 mt-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Current Password</label>
              <input
                type="password"
                value={oldPassword}
                onChange={(e) => setOldPassword(e.target.value)}
                className="w-full bg-brand-gray-light rounded-lg p-3 text-white"
                placeholder="Enter current password"
                required
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">New Password</label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-brand-gray-light rounded-lg p-3 text-white"
                placeholder="Enter new password"
                required
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Confirm New Password</label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-brand-gray-light rounded-lg p-3 text-white"
                placeholder="Confirm new password"
                required
              />
            </div>
            <div className="flex justify-end space-x-3 mt-6">
              <button
                type="button"
                onClick={() => setIsChangePasswordOpen(false)}
                className="px-4 py-2 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-4 py-2 bg-brand-gradient-start text-white rounded-lg text-sm hover:opacity-90 transition-opacity disabled:opacity-50"
              >
                {isLoading ? "Updating..." : "Update Password"}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeactivateOpen} onOpenChange={setIsDeactivateOpen}>
        <DialogContent className="bg-brand-black border border-brand-gray-light">
          <DialogHeader>
            <DialogTitle className="text-white">Temporarily Deactivate Account</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <p className="text-neutral-400 mb-6">Your account will be deactivated and hidden from other users. You can reactivate it at any time by logging in again.</p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setIsDeactivateOpen(false)}
                className="px-4 py-2 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleTemporaryDeactivate}
                className="px-4 py-2 bg-brand-gradient-start text-white rounded-lg text-sm hover:opacity-90 transition-opacity"
              >
                Deactivate
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <DialogContent className="bg-brand-black border border-brand-gray-light">
          <DialogHeader>
            <DialogTitle className="text-white text-red-400">Delete Account</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <p className="text-neutral-400 mb-2">This action cannot be undone. This will:</p>
            <ul className="list-disc list-inside text-neutral-400 mb-6 space-y-1">
              <li>Permanently delete your account</li>
              <li>Delete all your data and content</li>
              <li>Log you out of all devices</li>
            </ul>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setIsDeleteOpen(false)}
                className="px-4 py-2 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition-colors"
              >
                Delete Account
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={isLogoutOpen} onOpenChange={setIsLogoutOpen}>
        <DialogContent className="bg-brand-black border border-brand-gray-light max-w-xs mx-auto">
          <div className="text-center">
            <div className="w-12 h-12 bg-brand-gray-light rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fa-solid fa-arrow-right-from-bracket text-xl"></i>
            </div>
            <h2 className="text-lg font-medium mb-2">Logout Confirmation</h2>
            <p className="text-neutral-400 text-sm mb-6">Are you sure you want to log out?</p>
            
            <div className="space-y-3">
              <button
                onClick={handleSignOutAllDevices}
                className="w-full py-3 bg-brand-gradient-start text-white rounded-lg text-sm hover:opacity-90 transition-opacity"
              >
                Yes, Log Out
              </button>
              <button
                onClick={() => setIsLogoutOpen(false)}
                className="w-full py-3 border border-brand-gray-light rounded-lg text-sm hover:bg-brand-gray-light transition-colors"
              >
                Cancel
              </button>
              <label className="flex items-center justify-center gap-2 text-sm text-neutral-400 cursor-pointer">
                <input
                  type="checkbox"
                  checked={staySignedIn}
                  onChange={(e) => setStaySignedIn(e.target.checked)}
                  className="rounded border-neutral-600 bg-transparent text-brand-gradient-start focus:ring-brand-gradient-start"
                />
                Stay signed in
              </label>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <footer className="p-4 text-center text-neutral-500 text-xs">
        <p className="mb-1">Need help? Contact Support</p>
        <p>&copy; 2025 Trace. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Security;
