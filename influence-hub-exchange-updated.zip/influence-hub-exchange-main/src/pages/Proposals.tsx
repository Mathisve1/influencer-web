
import { TaskNavigation } from "@/components/tasks/TaskNavigation";

const Proposals = () => {
  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800">
        <div className="p-4">
          <h1 className="text-xl font-semibold">Proposals</h1>
        </div>
      </header>

      <main className="pt-16 pb-24">
        <div className="p-4">
          <p className="text-neutral-400">No active proposals</p>
        </div>
      </main>

      <TaskNavigation />
    </div>
  );
};

export default Proposals;
