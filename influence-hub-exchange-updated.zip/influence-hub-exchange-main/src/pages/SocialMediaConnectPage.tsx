
import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import StepIndicator from "@/components/StepIndicator";
import PlatformCard from "@/components/social-media/PlatformCard";
import { loadSocialMediaData, getScreenshotUrl } from "@/utils/socialMediaUtils";
import { SocialMediaPlatform, SocialMediaFormState } from "@/types/socialMedia";

const SocialMediaConnectPage = () => {
  const navigate = useNavigate();
  const [expandedPlatform, setExpandedPlatform] = useState<SocialMediaPlatform>("instagram");
  const [formData, setFormData] = useState<SocialMediaFormState>({
    instagram: { username: "", followerCount: "", engagementRate: "" },
    tiktok: { username: "", followerCount: "", engagementRate: "" },
    youtube: { username: "", followerCount: "", engagementRate: "" }
  });

  useEffect(() => {
    const initializeData = async () => {
      const data = await loadSocialMediaData();
      setFormData(data);

      // Load screenshot URLs for existing data
      Object.entries(data).forEach(async ([platform, accountData]) => {
        if (accountData.screenshotPath) {
          const url = await getScreenshotUrl(accountData.screenshotPath);
          if (url) {
            setFormData(prev => ({
              ...prev,
              [platform]: {
                ...prev[platform as SocialMediaPlatform],
                screenshotUrl: url
              }
            }));
          }
        }
      });
    };

    initializeData();
  }, []);

  const handlePlatformClick = (platform: SocialMediaPlatform) => {
    setExpandedPlatform(platform);
  };

  const handleFormDataUpdate = (platform: SocialMediaPlatform, data: SocialMediaFormState[SocialMediaPlatform]) => {
    setFormData(prev => ({
      ...prev,
      [platform]: data
    }));
  };

  const handleNext = () => {
    navigate("/email-password");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 w-full bg-neutral-900/90 backdrop-blur-lg border-b border-neutral-800 px-4 py-3 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/content-type")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex-1 text-center">
            <h1 className="text-lg font-medium">Connect Accounts</h1>
            <StepIndicator currentStep={5} totalSteps={6} title="Social Media" />
          </div>
          <div className="w-8" />
        </div>
      </header>

      <main className="pt-28 px-4 pb-24">
        <section className="space-y-6">
          {(["instagram", "tiktok", "youtube"] as const).map((platform) => (
            <PlatformCard
              key={platform}
              platform={platform}
              expanded={expandedPlatform === platform}
              formData={formData[platform]}
              onClick={() => handlePlatformClick(platform)}
              onUpdate={handleFormDataUpdate}
            />
          ))}
        </section>
      </main>

      <footer className="fixed bottom-0 w-full bg-neutral-900/90 backdrop-blur-lg border-t border-neutral-800 p-4">
        <button 
          onClick={handleNext}
          className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white py-4 rounded-lg hover:opacity-90 transition-opacity"
        >
          Next
        </button>
      </footer>
    </div>
  );
};

export default SocialMediaConnectPage;
