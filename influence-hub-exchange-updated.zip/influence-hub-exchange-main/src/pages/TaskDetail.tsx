
import { useNavigate } from "react-router-dom";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { Star, ArrowLeft } from "lucide-react";

interface CategoryRating {
  name: string;
  rating: number;
}

const TaskDetail = () => {
  const navigate = useNavigate();
  const [categoryRatings, setCategoryRatings] = useState<CategoryRating[]>([
    { name: "Communication", rating: 0 },
    { name: "Product Quality", rating: 0 },
    { name: "Collaboration & Support", rating: 0 },
    { name: "Professionalism", rating: 0 },
    { name: "Project Clarity", rating: 0 }
  ]);
  const [feedback, setFeedback] = useState("");
  const [recommendation, setRecommendation] = useState<"yes" | "no" | null>(null);

  const averageRating = useMemo(() => {
    const total = categoryRatings.reduce((sum, category) => sum + category.rating, 0);
    return (total / categoryRatings.length).toFixed(1);
  }, [categoryRatings]);

  const handleRatingChange = (categoryIndex: number, newRating: number) => {
    setCategoryRatings(prev => 
      prev.map((category, index) => 
        index === categoryIndex ? { ...category, rating: newRating } : category
      )
    );
  };

  const handleSubmitFeedback = () => {
    const hasAllRatings = categoryRatings.every(category => category.rating > 0);
    if (!hasAllRatings) {
      toast.error("Please provide ratings for all categories");
      return;
    }

    toast.success("Feedback submitted successfully");
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <button 
            className="p-2 hover:bg-neutral-800 rounded-lg transition-colors" 
            onClick={() => navigate("/dashboard")}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="text-xl tracking-wide">Company Feedback</div>
          <div className="w-8"></div>
        </div>
      </header>
      <main className="px-4 py-6">
        <div className="flex items-center mb-4">
          <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" alt="Company Logo" className="w-16 h-16 rounded-full" />
          <div className="ml-4">
            <h2 className="text-lg">TechCorp</h2>
            <p className="text-neutral-400 text-sm">Campaign Partner</p>
          </div>
        </div>
        <div className="mb-4 p-4 bg-neutral-800 rounded-xl">
          <h3 className="text-sm text-neutral-400 mb-2">Project Details</h3>
          <p className="text-base mb-2">Instagram Promotion Campaign</p>
          <div className="flex items-center text-sm text-neutral-400">
            <i className="fa-regular fa-calendar mr-2"></i>
            <span>Completed on Jan 15, 2025</span>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h3 className="text-lg">Rating Categories</h3>
            <div className="text-xl font-medium text-purple-500">
              {averageRating} / 5.0
            </div>
          </div>
          <div className="space-y-1">
            {categoryRatings.map((category, index) => (
              <div key={category.name} className="flex items-center justify-between py-1">
                <div className="flex-1">
                  <label className="text-sm text-neutral-400">{category.name}</label>
                  <div className="flex space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button 
                        key={star} 
                        className="hover:scale-110 transition-transform"
                        onClick={() => handleRatingChange(index, star)}
                      >
                        <Star 
                          size={18}
                          className={star <= category.rating ? 'fill-yellow-400 text-yellow-400' : 'text-neutral-600'}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <span className="text-sm text-neutral-400 ml-4">{category.rating}/5</span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm">Written Feedback</label>
            <textarea 
              className="w-full h-32 bg-neutral-800 rounded-xl p-4 text-white border border-neutral-700 focus:outline-none focus:border-neutral-600" 
              placeholder="Share your experience working with this company..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <label className="block text-sm">Would you recommend this company?</label>
            <div className="flex space-x-4">
              <button 
                className={`flex-1 py-3 rounded-lg border transition-colors ${
                  recommendation === 'yes' 
                    ? 'bg-green-500/20 border-green-500 text-green-400' 
                    : 'bg-neutral-800 border-neutral-700'
                }`}
                onClick={() => setRecommendation('yes')}
              >
                <i className="fa-solid fa-thumbs-up mr-2"></i>Yes
              </button>
              <button 
                className={`flex-1 py-3 rounded-lg border transition-colors ${
                  recommendation === 'no' 
                    ? 'bg-red-500/20 border-red-500 text-red-400' 
                    : 'bg-neutral-800 border-neutral-700'
                }`}
                onClick={() => setRecommendation('no')}
              >
                <i className="fa-solid fa-thumbs-down mr-2"></i>No
              </button>
            </div>
          </div>
        </div>
        <button 
          className="w-full mt-8 py-4 bg-neutral-800 rounded-xl border border-neutral-700 hover:bg-neutral-700 transition-colors"
          onClick={handleSubmitFeedback}
        >
          Submit Feedback
        </button>
      </main>
      <footer className="p-4 text-center text-neutral-500 text-xs border-t border-neutral-800">
        <p>&copy; 2025 Trace. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default TaskDetail;
