
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Lock, ShieldCheck } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import StepIndicator from "@/components/StepIndicator";

const BusinessDetails = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 border-b border-neutral-800 bg-neutral-900 z-50">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigate("/business-contact", { replace: true })}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-xl tracking-wide">Business Registration</div>
            <div className="w-10" />
          </div>
        </div>
        <StepIndicator currentStep={3} totalSteps={3} title="Final Details" />
      </header>

      <main className="pt-32 px-4 pb-24">
        <section className="mb-8">
          <h2 className="text-lg mb-4">Business Verification</h2>
          <Select>
            <SelectTrigger className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700 text-white mb-2">
              <SelectValue placeholder="Select Verification Method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="license">Upload Business License</SelectItem>
              <SelectItem value="email">Verify via Business Email</SelectItem>
            </SelectContent>
          </Select>
        </section>

        <section className="mb-8">
          <h2 className="text-lg mb-4">Payment Method</h2>
          <div className="space-y-3">
            <Button 
              variant="outline"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700 flex items-center justify-start font-normal"
            >
              <svg className="w-6 h-6 mr-3" viewBox="0 0 24 24">
                <path fill="currentColor" d="M20.067 8.478c.492.88.433 2.015.433 3.222v1.7c0 2.015.053 4.015-.433 5.96-.433 1.77-1.373 2.4-2.97 2.44h-10.2c-1.593 0-2.393-.67-2.97-2.44-.488-1.95-.433-3.945-.433-5.96v-1.7c0-1.207-.059-2.342.433-3.222.577-1.77 1.373-2.4 2.97-2.44h10.2c1.593 0 2.393.67 2.97 2.44zm-7.133 5.122h-1.9c-.509 0-.933.42-.933.93 0 .51.424.93.933.93h1.9c.509 0 .933-.42.933-.93 0-.51-.424-.93-.933-.93z"/>
              </svg>
              <span>PayPal</span>
            </Button>
            <Button 
              variant="outline"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700 flex items-center justify-start font-normal"
            >
              <svg className="w-6 h-6 mr-3" viewBox="0 0 24 24">
                <path fill="currentColor" d="M11.5 1L2 6v2h19V6m-5 4v2h-3v-2M8 10v2H5v-2m-3 3v8h19v-8m-3 3v2h-3v-2"/>
              </svg>
              <span>SEPA Direct Debit</span>
            </Button>
            <Button 
              variant="outline"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700 flex items-center justify-start font-normal"
            >
              <svg className="w-6 h-6 mr-3" viewBox="0 0 24 24">
                <path fill="currentColor" d="M20 4H4c-1.11 0-1.99.89-1.99 2L2 18c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/>
              </svg>
              <span>Credit Card</span>
            </Button>
          </div>
        </section>

        <section className="mb-8">
          <h2 className="text-lg mb-4">Billing Details</h2>
          <div className="space-y-4">
            <Input
              type="text"
              placeholder="Business Name"
              defaultValue="Acme Corp"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700"
            />
            <Input
              type="text"
              placeholder="VAT Number (Optional)"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700"
            />
            <Input
              type="text"
              placeholder="Address"
              className="w-full p-4 bg-neutral-800 rounded-lg border border-neutral-700"
            />
          </div>
        </section>

        <div className="mb-8 p-4 bg-neutral-800 rounded-lg">
          <div className="flex items-center mb-2">
            <ShieldCheck className="w-5 h-5 mr-2" />
            <span className="text-sm">Your data is encrypted and secure</span>
          </div>
          <div className="flex items-center">
            <Lock className="w-5 h-5 mr-2" />
            <span className="text-sm">Secure Payment Processing</span>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-neutral-900 border-t border-neutral-800">
        <Button
          onClick={() => navigate("/success-registration", { replace: true })}
          className="w-full py-4 bg-neutral-800 rounded-lg text-white"
        >
          Complete Registration
        </Button>
      </footer>
    </div>
  );
};

export default BusinessDetails;
