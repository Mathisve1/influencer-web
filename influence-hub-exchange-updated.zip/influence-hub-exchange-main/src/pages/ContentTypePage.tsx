import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import StepIndicator from "@/components/StepIndicator";

type ContentType = "content_creation" | "influencer_marketing" | "both";

const ContentTypePage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [selectedType, setSelectedType] = useState<ContentType | null>(null);
  
  const handleTypeSelection = (type: ContentType) => {
    setSelectedType(type);
  };

  const handleNext = async () => {
    if (!selectedType) {
      toast({
        variant: "destructive",
        title: "Selection required",
        description: "Please choose your path before continuing.",
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        // If user is authenticated, save to Supabase
        const { error } = await supabase
          .from('creator_preferences')
          .insert({
            content_type: selectedType,
            user_id: session.user.id,
          });

        if (error) throw error;
      }

      // Store in localStorage regardless of authentication
      localStorage.setItem('content_type', selectedType);
      
      // Navigate to social media connect page
      navigate("/social-media-connect");
    } catch (error: any) {
      console.error('Error saving content type:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save your selection. Please try again.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 w-full bg-neutral-900/90 backdrop-blur-lg border-b border-neutral-800 px-4 py-3 z-50">
        <div className="flex items-center justify-between">
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/selfie-verification")}
            className="p-2 text-neutral-400 hover:text-white"
          >
            <ArrowLeft className="h-5 w-5" />
          </motion.button>
          <div className="flex-1 text-center">
            <h1 className="text-lg font-medium">Choose Your Path</h1>
            <StepIndicator currentStep={4} totalSteps={6} title="Choose Path" />
          </div>
          <div className="w-8" />
        </div>
      </header>

      <main className="pt-28 px-4 pb-24">
        <section className="space-y-4">
          {["content_creation", "influencer_marketing", "both"].map((type) => (
            <motion.div
              key={type}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleTypeSelection(type as ContentType)}
              className={`p-6 border rounded-lg transition-all cursor-pointer ${
                selectedType === type
                  ? "border-brand-gradient-end bg-neutral-800"
                  : "border-neutral-700 bg-neutral-800/50 hover:border-brand-gradient-end/50"
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="text-lg">
                  {type === "content_creation"
                    ? "Content Creation"
                    : type === "influencer_marketing"
                    ? "Influencer Marketing"
                    : "Both Worlds"}
                </div>
                {type === "content_creation" ? (
                  <i className="fa-regular fa-pen-to-square text-xl"></i>
                ) : type === "influencer_marketing" ? (
                  <i className="fa-solid fa-users text-xl"></i>
                ) : (
                  <div className="flex items-center space-x-2">
                    <i className="fa-solid fa-crown text-xl"></i>
                    <span className="text-xs px-2 py-1 bg-neutral-700 rounded-full">
                      Popular
                    </span>
                  </div>
                )}
              </div>
              <p className="text-sm text-neutral-400">
                {type === "content_creation"
                  ? "Produce high-quality content for brands that they can use across their marketing channels"
                  : type === "influencer_marketing"
                  ? "Collaborate with brands by creating and sharing engaging content with your audience"
                  : "Get the best of both worlds: Create content for brands and share campaigns on your own social media"}
              </p>
              {type === "both" && (
                <div className="flex items-center justify-between mt-4">
                  <div className="flex items-center space-x-2">
                    <i className="fa-solid fa-check-circle text-sm"></i>
                    <span className="text-xs">Both features included</span>
                  </div>
                  <i className="fa-solid fa-chevron-right text-neutral-400"></i>
                </div>
              )}
            </motion.div>
          ))}
        </section>

        <div className="fixed bottom-0 left-0 right-0 p-4 bg-neutral-900/90 backdrop-blur-lg border-t border-neutral-800">
          <Button
            onClick={handleNext}
            className="w-full bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end text-white hover:opacity-90 transition-opacity"
            disabled={!selectedType || isLoading}
          >
            {isLoading ? "Saving..." : "Next"}
          </Button>
        </div>
      </main>

      {isLoading && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-white">Processing...</div>
        </div>
      )}
    </div>
  );
};

export default ContentTypePage;
