
import { useNavigate, useLocation } from "react-router-dom";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

const PaymentSettings = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const isBusinessRoute = location.pathname.startsWith('/business');

  const handleBack = () => {
    if (isBusinessRoute) {
      navigate("/business/profile");
    } else {
      navigate("/profile");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <button 
            className="p-2"
            onClick={handleBack}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg tracking-wide">Payment Settings</div>
          <button className="p-2">
            <i className="fa-solid fa-gear"></i>
          </button>
        </div>
      </header>

      <main className="px-4 py-6">
        <section className="mb-8">
          <div className="bg-neutral-800 p-6 rounded-xl">
            <h2 className="text-sm text-neutral-400 mb-2">Available Balance</h2>
            <div className="text-3xl mb-4">$2,458.32</div>
            <button className="w-full bg-neutral-700 py-3 rounded-lg text-sm hover:bg-neutral-600 transition-colors">
              Withdraw Funds
            </button>
          </div>
        </section>

        <section className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg">Payment Methods</h2>
            <button className="text-sm bg-neutral-800 px-4 py-2 rounded-lg hover:bg-neutral-700 transition-colors">
              <i className="fa-solid fa-plus mr-2"></i>Add New
            </button>
          </div>
          <div className="space-y-4">
            <div className="bg-neutral-800 p-4 rounded-lg flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-neutral-700 rounded-lg flex items-center justify-center mr-3">
                  <i className="fa-brands fa-paypal text-xl"></i>
                </div>
                <div>
                  <div className="text-sm">PayPal</div>
                  <div className="text-xs text-neutral-400">Connected</div>
                </div>
              </div>
              <i className="fa-solid fa-chevron-right text-neutral-500"></i>
            </div>
            <div className="bg-neutral-800 p-4 rounded-lg flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-10 h-10 bg-neutral-700 rounded-lg flex items-center justify-center mr-3">
                  <i className="fa-solid fa-building-columns text-xl"></i>
                </div>
                <div>
                  <div className="text-sm">Bank Account</div>
                  <div className="text-xs text-neutral-400">****4589</div>
                </div>
              </div>
              <i className="fa-solid fa-chevron-right text-neutral-500"></i>
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-lg mb-4">Payment History</h2>
          <div className="space-y-4">
            <div className="bg-neutral-800 p-4 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="text-sm">Payout to PayPal</div>
                  <div className="text-xs text-neutral-400">Jan 15, 2025</div>
                </div>
                <div className="text-sm">$850.00</div>
              </div>
              <div className="flex items-center">
                <div className="px-2 py-1 bg-neutral-700 rounded text-xs">Completed</div>
              </div>
            </div>
            <div className="bg-neutral-800 p-4 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <div>
                  <div className="text-sm">Payout to Bank</div>
                  <div className="text-xs text-neutral-400">Jan 1, 2025</div>
                </div>
                <div className="text-sm">$1,200.00</div>
              </div>
              <div className="flex items-center">
                <div className="px-2 py-1 bg-neutral-700 rounded text-xs">Completed</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default PaymentSettings;
