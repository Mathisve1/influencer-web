
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ChevronDown, Globe, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import StepIndicator from "@/components/StepIndicator";

const BusinessContact = () => {
  const navigate = useNavigate();
  const [operatingHours, setOperatingHours] = useState("24-7");
  const daysOfWeek = [
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday"
  ];

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 border-b border-neutral-800 bg-neutral-900 z-50">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => navigate("/business-registration", { replace: true })}
              className="p-2"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-xl tracking-wide">Contact Information</div>
            <div className="w-8" />
          </div>
        </div>
        <StepIndicator currentStep={2} totalSteps={3} title="Contact & Location" />
      </header>

      <main className="pt-32 px-4 pb-24">
        <form className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Business Email*</label>
            <Input
              type="email"
              placeholder="contact@business.com"
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Phone Number*</label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                className="px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg flex items-center gap-2"
              >
                <Globe className="w-4 h-4" />
                <span>+1</span>
                <ChevronDown className="w-4 h-4" />
              </Button>
              <Input
                type="tel"
                placeholder="(555) 000-0000"
                className="flex-1 px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-sm text-neutral-400">Business Address*</label>
            <Input
              type="text"
              placeholder="Street Address"
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
            />
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="text"
                placeholder="City"
                className="px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
              />
              <Input
                type="text"
                placeholder="Postal Code"
                className="px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
              />
            </div>
          </div>

          <div className="space-y-4">
            <label className="text-sm text-neutral-400">Operating Hours*</label>
            <RadioGroup 
              value={operatingHours} 
              onValueChange={setOperatingHours}
              className="space-y-2"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="24-7" id="24-7" />
                <Label htmlFor="24-7">24/7</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="weekdays" id="weekdays" />
                <Label htmlFor="weekdays">Weekdays (9AM-5PM)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="custom" id="custom" />
                <Label htmlFor="custom">Custom Hours</Label>
              </div>
            </RadioGroup>

            {operatingHours === "custom" && (
              <div className="space-y-4 pt-4">
                {daysOfWeek.map((day) => (
                  <div key={day} className="flex items-center gap-4">
                    <span className="w-24 text-sm text-neutral-400">{day}</span>
                    <div className="flex-1 grid grid-cols-2 gap-2">
                      <Input
                        type="time"
                        defaultValue="09:00"
                        className="px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
                      />
                      <Input
                        type="time"
                        defaultValue="17:00"
                        className="px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm text-neutral-400">Service Areas</label>
            <Select>
              <SelectTrigger className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg">
                <SelectValue placeholder="Select service areas" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="local">Local Only</SelectItem>
                <SelectItem value="regional">Regional</SelectItem>
                <SelectItem value="national">National</SelectItem>
                <SelectItem value="international">International</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </form>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 p-4 bg-neutral-900 border-t border-neutral-800">
        <Button
          onClick={() => navigate("/business-details", { replace: true })}
          className="w-full py-4 bg-neutral-800 text-sm rounded-lg"
        >
          Next Step
        </Button>
      </footer>
    </div>
  );
};

export default BusinessContact;
