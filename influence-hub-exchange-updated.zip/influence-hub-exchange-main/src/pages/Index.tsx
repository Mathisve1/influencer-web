
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Building, Star } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <div className="text-xl tracking-wide">TRACE</div>
          <button className="p-2">
            <i className="fa-solid fa-ellipsis-vertical"></i>
          </button>
        </div>
      </header>

      <main className="px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-2xl tracking-wide mb-2">Choose Your Role</h1>
          <p className="text-neutral-400">Select how you want to use Trace</p>
        </div>

        <div className="space-y-6">
          <div className="group">
            <Link 
              to="/business-registration" 
              className="block w-full p-6 bg-neutral-800 rounded-xl border border-neutral-700 hover:border-brand-gradient-end/50 transition-all"
            >
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-neutral-700 rounded-full flex items-center justify-center mb-4">
                  <Building className="h-8 w-8" />
                </div>
                <h2 className="text-xl mb-2">Business</h2>
                <p className="text-sm text-neutral-400 text-center">
                  Find and collaborate with content creators to promote your brand
                </p>
              </div>
            </Link>
          </div>

          <div className="group">
            <Link 
              to="/creator-registration"
              className="block w-full p-6 bg-neutral-800 rounded-xl border border-neutral-700 hover:border-brand-gradient-end/50 transition-all"
            >
              <div className="flex flex-col items-center">
                <div className="w-16 h-16 bg-neutral-700 rounded-full flex items-center justify-center mb-4">
                  <Star className="h-8 w-8" />
                </div>
                <h2 className="text-xl mb-2">Content Creator</h2>
                <p className="text-sm text-neutral-400 text-center">
                  Connect with brands and monetize your influence
                </p>
              </div>
            </Link>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-neutral-400 text-sm">Already have an account?</p>
          <Link 
            to="/login"
            className="inline-block mt-2 px-4 py-2 border border-neutral-700 rounded-lg text-sm hover:border-brand-gradient-end/50 transition-colors"
          >
            Sign In
          </Link>
        </div>
      </main>

      <footer className="p-4 text-center text-neutral-500 text-xs">
        <p>&copy; 2025 Trace. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default Index;
