
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Camera, Mail, Phone } from "lucide-react";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const BusinessEditProfile = () => {
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);

  const handleSave = () => {
    toast.success("Profile updated successfully");
    navigate("/business/profile");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 border-b border-neutral-800">
        <div className="px-4 py-3 flex items-center justify-between">
          <button 
            className="p-2"
            onClick={() => navigate("/business/profile")}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg">Edit Business Profile</div>
          <button 
            className="text-sm text-brand-gradient-end hover:text-brand-gradient-start transition-colors"
            onClick={handleSave}
          >
            Save
          </button>
        </div>
      </header>

      <main className="p-4 pb-20 space-y-6">
        {/* Profile Image Section */}
        <section className="flex flex-col items-center space-y-4">
          <div className="relative">
            <img 
              src="https://api.dicebear.com/7.x/shapes/svg?seed=business" 
              alt="Business Logo" 
              className="w-24 h-24 rounded-full bg-neutral-800 object-cover"
            />
            <button className="absolute bottom-0 right-0 p-2 bg-neutral-800 rounded-full border border-neutral-700 text-brand-gradient-end hover:text-brand-gradient-start transition-colors">
              <Camera className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* Basic Information */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium">Basic Information</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Business Name</label>
              <Input 
                placeholder="Enter business name"
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
          </div>
        </section>

        {/* Contact Information */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium">Contact Information</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  type="email"
                  placeholder="business@example.com"
                  className="bg-neutral-800 border-neutral-700 pl-10"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  type="tel"
                  placeholder="+1 (555) 000-0000"
                  className="bg-neutral-800 border-neutral-700 pl-10"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Company Information Link */}
        <section 
          className="space-y-4 cursor-pointer"
          onClick={() => navigate("/business/company-info")}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium">Company Information</h2>
            <i className="fa-solid fa-chevron-right text-neutral-400"></i>
          </div>
          <p className="text-sm text-neutral-400">
            Manage your company details, location, and registration information
          </p>
        </section>

        {/* Social Media Links */}
        <section 
          className="space-y-4 cursor-pointer"
          onClick={() => navigate("/business/social-media-profiles")}
        >
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium">Social Media</h2>
            <i className="fa-solid fa-chevron-right text-neutral-400"></i>
          </div>
          <p className="text-sm text-neutral-400">
            Manage your social media profile links
          </p>
        </section>
      </main>
    </div>
  );
};

export default BusinessEditProfile;
