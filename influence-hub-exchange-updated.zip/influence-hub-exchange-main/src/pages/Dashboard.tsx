import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import * as XLSX from 'xlsx';
import { supabase } from "@/integrations/supabase/client";
import { TaskNavigation } from "@/components/tasks/TaskNavigation";

const Dashboard = () => {
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined;
    to: Date | undefined;
  }>({
    from: undefined,
    to: undefined,
  });

  const downloadIncomeReport = async () => {
    try {
      let query = supabase
        .from('earnings')
        .select('*')
        .order('date', { ascending: false });

      if (dateRange.from && dateRange.to) {
        query = query
          .gte('date', dateRange.from.toISOString())
          .lte('date', dateRange.to.toISOString());
      }

      const { data: earnings, error } = await query;

      if (error) throw error;

      if (!earnings || earnings.length === 0) {
        alert('No income data found for the selected period');
        return;
      }

      const excelData = earnings.map(earning => ({
        Date: format(new Date(earning.date), 'MM/dd/yyyy'),
        Company: earning.company,
        'Job Title': earning.job_title,
        Amount: `$${earning.amount}`,
        Status: earning.status
      }));

      const ws = XLSX.utils.json_to_sheet(excelData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Income Report');

      const filename = dateRange.from && dateRange.to
        ? `income_report_${format(dateRange.from, 'MM-dd-yyyy')}_to_${format(dateRange.to, 'MM-dd-yyyy')}.xlsx`
        : 'income_report_all.xlsx';

      XLSX.writeFile(wb, filename);
    } catch (error) {
      console.error('Error downloading report:', error);
      alert('Failed to download income report');
    }
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-3">
            <img 
              src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1234" 
              alt="Profile" 
              className="w-8 h-8 rounded-full"
            />
            <span className="text-lg">@johndoe</span>
          </div>
          <button className="p-2 text-neutral-400 hover:text-white transition-colors">
            <i className="fa-solid fa-bell"></i>
          </button>
        </div>
      </header>

      <main className="pt-20 pb-20">
        <div className="px-4 mb-6">
          <h1 className="text-2xl mb-4">Earnings Dashboard</h1>
          <div className="grid grid-cols-3 gap-3">
            <Card className="bg-neutral-800 p-4">
              <p className="text-neutral-400 text-sm mb-1">Total</p>
              <p className="text-xl">$12,450</p>
            </Card>
            <Card className="bg-neutral-800 p-4">
              <p className="text-neutral-400 text-sm mb-1">Ongoing</p>
              <p className="text-xl">$2,800</p>
            </Card>
            <Card className="bg-neutral-800 p-4">
              <p className="text-neutral-400 text-sm mb-1">Pending</p>
              <p className="text-xl">$1,200</p>
            </Card>
          </div>
        </div>

        <div className="px-4 mb-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg">Income Overview</h2>
            <select className="bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-1 text-sm">
              <option>Weekly</option>
              <option>Monthly</option>
              <option>Yearly</option>
            </select>
          </div>
          <Card className="bg-neutral-800 p-4 h-[200px] flex items-center justify-center">
            <span className="text-neutral-400">Graph Placeholder</span>
          </Card>
        </div>

        <div className="px-4 mb-6">
          <h2 className="text-lg mb-4">Recent Transactions</h2>
          <div className="space-y-3">
            <Card className="bg-neutral-800 p-4 flex justify-between items-center">
              <div>
                <p>Nike Campaign</p>
                <p className="text-sm text-neutral-400">Mar 15, 2025</p>
              </div>
              <p className="text-lg">$850</p>
            </Card>
            <Card className="bg-neutral-800 p-4 flex justify-between items-center">
              <div>
                <p>Adidas Promo</p>
                <p className="text-sm text-neutral-400">Mar 12, 2025</p>
              </div>
              <p className="text-lg">$1,200</p>
            </Card>
          </div>
        </div>

        <div className="px-4">
          <div className="mb-4">
            <div className="flex flex-col gap-2">
              <label className="text-sm text-neutral-400">Select Date Range</label>
              <div className="flex gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-[240px] justify-start text-left font-normal bg-neutral-800 border-neutral-700",
                        !dateRange.from && "text-neutral-400"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.from ? (
                        format(dateRange.from, "MM/dd/yyyy")
                      ) : (
                        <span>Start date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-neutral-800" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.from}
                      onSelect={(date) =>
                        setDateRange(prev => ({ ...prev, from: date }))
                      }
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-[240px] justify-start text-left font-normal bg-neutral-800 border-neutral-700",
                        !dateRange.to && "text-neutral-400"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange.to ? (
                        format(dateRange.to, "MM/dd/yyyy")
                      ) : (
                        <span>End date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-neutral-800" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange.to}
                      onSelect={(date) =>
                        setDateRange(prev => ({ ...prev, to: date }))
                      }
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </div>

          <Button 
            onClick={downloadIncomeReport} 
            className="w-full bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 transition-colors"
          >
            <i className="fa-solid fa-download mr-2"></i>
            Download Income Report
          </Button>
        </div>
      </main>

      <TaskNavigation />
    </div>
  );
};

export default Dashboard;
