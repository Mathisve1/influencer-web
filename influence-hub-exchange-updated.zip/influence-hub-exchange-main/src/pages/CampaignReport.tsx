
import { useNavigate, useParams } from "react-router-dom";
import { BusinessNavigation } from "@/components/business/BusinessNavigation";

const CampaignReport = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const collaborators = [
    {
      id: 1,
      name: "Sarah Johnson",
      image: "https://api.dicebear.com/7.x/notionists/svg?seed=sarah",
      platform: "Instagram",
      cost: 1200,
      deliverables: "2 Posts, 3 Stories"
    },
    {
      id: 2,
      name: "Mike Chen",
      image: "https://api.dicebear.com/7.x/notionists/svg?seed=mike",
      platform: "TikTok",
      cost: 2000,
      deliverables: "4 Videos"
    },
    {
      id: 3,
      name: "Emma Davis",
      image: "https://api.dicebear.com/7.x/notionists/svg?seed=emma",
      platform: "YouTube",
      cost: 1800,
      deliverables: "1 Video Review"
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => navigate("/business/campaigns/expired")}
              className="p-2 hover:text-neutral-300"
            >
              <i className="fa-solid fa-arrow-left"></i>
            </button>
            <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">
              Campaign Report
            </div>
          </div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-solid fa-download"></i>
            </button>
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-solid fa-share"></i>
            </button>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-24">
        <div className="space-y-6">
          <div className="bg-neutral-800 rounded-lg p-4">
            <h2 className="text-lg mb-4">Campaign Overview</h2>
            <div className="space-y-2 text-sm text-neutral-400">
              <div className="flex justify-between">
                <span>Duration</span>
                <span>Jan 1 - Mar 1, 2025</span>
              </div>
              <div className="flex justify-between">
                <span>Total Budget</span>
                <span>$5,000</span>
              </div>
              <div className="flex justify-between">
                <span>Status</span>
                <span className="text-neutral-300">Expired</span>
              </div>
            </div>
          </div>

          <div className="bg-neutral-800 rounded-lg p-4">
            <h2 className="text-lg mb-4">Campaign Collaborators</h2>
            <div className="space-y-4">
              {collaborators.map((collaborator) => (
                <div 
                  key={collaborator.id} 
                  className="p-4 border border-neutral-700 rounded-lg"
                >
                  <div className="flex items-start gap-3">
                    <img 
                      src={collaborator.image} 
                      alt={collaborator.name}
                      className="w-12 h-12 rounded-full"
                    />
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-medium">{collaborator.name}</h3>
                          <p className="text-sm text-neutral-400">{collaborator.platform}</p>
                        </div>
                        <span className="text-[#9b87f5] font-medium">
                          ${collaborator.cost.toLocaleString()}
                        </span>
                      </div>
                      <div className="mt-2 text-sm text-neutral-400">
                        <span>Deliverables:</span>
                        <span className="ml-2">{collaborator.deliverables}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default CampaignReport;
