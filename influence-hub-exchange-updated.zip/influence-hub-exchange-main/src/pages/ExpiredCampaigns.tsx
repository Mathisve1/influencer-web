
import { BusinessNavigation } from "@/components/business/BusinessNavigation";
import { CampaignHeader } from "@/components/campaign/CampaignHeader";
import { useNavigate } from "react-router-dom";

interface ExpiredCampaign {
  id: string;
  title: string;
  duration: {
    start: string;
    end: string;
  };
  budgetSpent: number;
}

const ExpiredCampaigns = () => {
  const navigate = useNavigate();
  const campaigns: ExpiredCampaign[] = [
    {
      id: "1",
      title: "Summer Collection Launch",
      duration: {
        start: "Jan 1",
        end: "Mar 1, 2025",
      },
      budgetSpent: 5000,
    },
    {
      id: "2",
      title: "Holiday Special",
      duration: {
        start: "Nov 15",
        end: "Dec 31, 2024",
      },
      budgetSpent: 8500,
    },
  ];

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">TRACE</div>
          <div className="flex items-center gap-4">
            <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
              <i className="fa-regular fa-bell"></i>
            </button>
            <img src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" alt="Profile" className="w-8 h-8 rounded-full"/>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-24">
        <CampaignHeader activeCampaigns={4} activeTab="expired" />
        
        <div className="space-y-4">
          {campaigns.map((campaign) => (
            <div key={campaign.id} className="bg-neutral-800 rounded-lg p-4">
              <div className="flex justify-between items-start mb-3">
                <h3 className="text-lg">{campaign.title}</h3>
                <span className="text-xs bg-neutral-700 px-2 py-1 rounded">Expired</span>
              </div>
              <div className="text-sm text-neutral-400 space-y-2">
                <div className="flex justify-between">
                  <span>Duration</span>
                  <span>{campaign.duration.start} - {campaign.duration.end}</span>
                </div>
                <div className="flex justify-between">
                  <span>Budget Spent</span>
                  <span>${campaign.budgetSpent.toLocaleString()}</span>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                <button 
                  onClick={() => navigate(`/business/campaigns/${campaign.id}/report`)}
                  className="px-4 py-2 bg-neutral-700 rounded-lg text-sm hover:bg-neutral-600 transition-colors"
                >
                  View Report
                </button>
                <button 
                  onClick={() => navigate(`/business/campaigns/${campaign.id}/renew`)}
                  className="px-4 py-2 border border-neutral-600 rounded-lg text-sm hover:bg-neutral-700 transition-colors"
                >
                  Renew
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      <BusinessNavigation />
    </div>
  );
};

export default ExpiredCampaigns;
