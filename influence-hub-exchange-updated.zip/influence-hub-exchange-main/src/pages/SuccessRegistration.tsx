import { useNavigate } from "react-router-dom";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const SuccessRegistration = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-[#1A1F2C] text-white">
      <header className="p-4 border-b border-[#403E43]">
        <div className="flex items-center justify-between">
          <div className="text-xl tracking-wide bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">
            TRACE
          </div>
          <button className="p-2 text-[#8E9196] hover:text-white transition-colors">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M12 12h.01M12 6h.01M12 18h.01" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>
      </header>

      <main className="px-4 py-12">
        <div className="flex flex-col items-center justify-center">
          <div className="w-24 h-24 bg-gradient-to-br from-[#6E59A5] to-[#9b87f5]/20 rounded-full flex items-center justify-center mb-8 border border-[#7E69AB]/30 shadow-lg">
            <Check className="w-10 h-10 text-[#D6BCFA]" />
          </div>
          <div className="text-center mb-8">
            <h1 className="text-2xl tracking-wide mb-4 bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] bg-clip-text text-transparent font-semibold">
              Your registration was successful!
            </h1>
            <p className="text-[#8E9196] text-sm px-4 leading-relaxed">
              If verification is required, our team will review your details within 24 hours. You will receive an email update shortly.
            </p>
          </div>
          <div className="w-full space-y-4">
            <Button 
              onClick={() => {
                // Redirect to the appropriate dashboard based on user type
                const isBusinessUser = true; // This should be determined by your auth logic
                const dashboardPath = isBusinessUser ? "/business/dashboard" : "/creator/dashboard";
                navigate(dashboardPath);
              }}
              className="w-full py-4 bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] hover:from-[#7E69AB] hover:to-[#6E59A5] rounded-xl text-white tracking-wide transition-all duration-300 shadow-lg shadow-[#6E59A5]/20"
            >
              Go to Dashboard <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
            <Button
              onClick={() => navigate("/campaign/new")}
              className="w-full py-4 bg-[#1A1F2C] rounded-xl border border-[#7E69AB]/30 text-white tracking-wide hover:bg-[#7E69AB]/10 transition-all duration-300"
            >
              Set Up First Campaign
            </Button>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 w-full p-4 text-center text-[#8E9196] text-xs border-t border-[#403E43] bg-[#1A1F2C]/80 backdrop-blur-sm">
        <p>&copy; 2025 Trace. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default SuccessRegistration;
