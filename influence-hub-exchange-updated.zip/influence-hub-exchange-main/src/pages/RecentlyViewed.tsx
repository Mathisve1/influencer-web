
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { ArrowLeft, Trash2 } from "lucide-react";

const RecentlyViewed = () => {
  const navigate = useNavigate();
  const [recentJobs, setRecentJobs] = useState([
    {
      id: 1,
      title: "Instagram Story Campaign",
      company: "Fashion Brand Co.",
      platforms: ["Instagram", "TikTok"],
      price: "$2000-3000",
      deadline: "7 days",
      timeAgo: "2 hours ago",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=1"
    },
    {
      id: 2,
      title: "TikTok Dance Challenge",
      company: "Entertainment Co.",
      platforms: ["TikTok"],
      price: "$1500-2000",
      deadline: "14 days",
      timeAgo: "5 hours ago",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=2"
    },
    {
      id: 3,
      title: "YouTube Content Creation",
      company: "Media Production",
      platforms: ["YouTube"],
      price: "$3000-4000",
      deadline: "30 days",
      timeAgo: "1 day ago",
      avatar: "https://api.dicebear.com/7.x/personas/svg?seed=3"
    }
  ]);

  const deleteJob = (jobId: number, event: React.MouseEvent) => {
    event.stopPropagation();
    setRecentJobs(prevJobs => prevJobs.filter(job => job.id !== jobId));
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
            <button 
              className="p-2"
              onClick={() => navigate('/tasks')}
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-lg tracking-wide">Recently Viewed</h1>
          </div>
          <button 
            className="p-2 text-neutral-400"
            onClick={() => navigate('/jobs')}
          >
            See all
          </button>
        </div>
      </header>

      <main className="pt-20 px-4">
        <div className="space-y-4">
          {recentJobs.map((job) => (
            <div 
              key={job.id} 
              className="relative p-4 bg-neutral-800 rounded-xl border border-neutral-700 hover:border-neutral-600 transition-colors cursor-pointer"
              onClick={() => navigate('/jobs')}
            >
              <button 
                className="absolute top-4 right-4 p-2 text-neutral-400 hover:text-neutral-300 transition-colors z-10"
                onClick={(e) => deleteJob(job.id, e)}
              >
                <Trash2 className="w-5 h-5" />
              </button>
              <div className="flex items-start gap-4">
                <img 
                  src={job.avatar} 
                  alt={job.company}
                  className="w-12 h-12 rounded-full"
                />
                <div className="flex-1">
                  <h2 className="text-lg font-medium mb-1">{job.title}</h2>
                  <p className="text-neutral-400 text-sm mb-3">{job.company}</p>
                  <div className="flex gap-2 mb-4">
                    {job.platforms.map((platform, index) => (
                      <span 
                        key={index} 
                        className="px-3 py-1 bg-neutral-700 rounded-full text-xs font-medium"
                      >
                        {platform}
                      </span>
                    ))}
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-neutral-400">
                      Deadline: {job.deadline}
                    </span>
                    <span className="text-lg font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                      {job.price}
                    </span>
                  </div>
                  <p className="text-neutral-500 text-xs mt-2">Viewed {job.timeAgo}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
};

export default RecentlyViewed;
