
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Building2, MapPin, Globe, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const BusinessCompanyInfo = () => {
  const navigate = useNavigate();

  const handleSave = () => {
    toast.success("Company information updated successfully");
    navigate("/business/profile");
  };

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 border-b border-neutral-800">
        <div className="px-4 py-3 flex items-center justify-between">
          <button 
            className="p-2"
            onClick={() => navigate("/business/profile")}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg">Company Information</div>
          <button 
            className="text-sm text-brand-gradient-end hover:text-brand-gradient-start transition-colors"
            onClick={handleSave}
          >
            Save
          </button>
        </div>
      </header>

      <main className="p-4 pb-20 space-y-6">
        {/* Company Details */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium">Company Details</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Industry</label>
              <Input 
                placeholder="e.g. Technology, Retail, Services"
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Company Description</label>
              <Textarea 
                placeholder="Tell us about your company..."
                className="bg-neutral-800 border-neutral-700 min-h-[100px]"
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Website</label>
              <div className="relative">
                <Globe className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  type="url"
                  placeholder="https://www.example.com"
                  className="bg-neutral-800 border-neutral-700 pl-10"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Opening Hours */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Opening Hours
          </h2>
          <div className="space-y-4">
            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => (
              <div key={day} className="flex items-center gap-4">
                <div className="w-28">
                  <label className="text-sm text-neutral-400">{day}</label>
                </div>
                <div className="flex items-center gap-2 flex-1">
                  <Input 
                    type="time"
                    className="bg-neutral-800 border-neutral-700"
                    defaultValue="09:00"
                  />
                  <span className="text-neutral-400">to</span>
                  <Input 
                    type="time"
                    className="bg-neutral-800 border-neutral-700"
                    defaultValue="17:00"
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Registration Details */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium">Registration Details</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Registration Number</label>
              <div className="relative">
                <Building2 className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  placeholder="Business registration number"
                  className="bg-neutral-800 border-neutral-700 pl-10"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Tax ID</label>
              <Input 
                placeholder="Tax identification number"
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Year Founded</label>
              <Input 
                type="number"
                placeholder="e.g. 2020"
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
          </div>
        </section>

        {/* Location */}
        <section className="space-y-4">
          <h2 className="text-lg font-medium">Company Location</h2>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Address</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-neutral-400" />
                <Input 
                  placeholder="Street address"
                  className="bg-neutral-800 border-neutral-700 pl-10"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-neutral-400 block mb-2">City</label>
                <Input 
                  placeholder="City"
                  className="bg-neutral-800 border-neutral-700"
                />
              </div>
              <div>
                <label className="text-sm text-neutral-400 block mb-2">State</label>
                <Input 
                  placeholder="State"
                  className="bg-neutral-800 border-neutral-700"
                />
              </div>
            </div>
            <div>
              <label className="text-sm text-neutral-400 block mb-2">Country</label>
              <Input 
                placeholder="Country"
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default BusinessCompanyInfo;
