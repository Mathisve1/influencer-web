
import { useState } from "react";
import { TaskHeader } from "@/components/tasks/TaskHeader";
import { TaskSearch } from "@/components/tasks/TaskSearch";
import { JobSection } from "@/components/tasks/JobSection";
import { TaskNavigation } from "@/components/tasks/TaskNavigation";
import { TaskAnalytics } from "@/components/jobs/TaskAnalytics";

const Tasks = () => {
  const [showFilters, setShowFilters] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const relevantJobs = [
    {
      id: 1,
      title: "Instagram Story Campaign",
      company: "Fashion & Beauty Co.",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=1",
      tags: ["Instagram", "Fashion", "Beauty"],
      price: "$500",
      deadline: "Mar 15, 2025"
    }
  ];

  const recentlyViewed = [
    {
      id: 2,
      title: "TikTok Dance Challenge",
      company: "Entertainment Co.",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=2",
      tags: ["TikTok", "Dance", "Entertainment"],
      price: "$750",
      deadline: "Feb 28, 2025"
    }
  ];

  const savedJobs = [
    {
      id: 3,
      title: "YouTube Product Review",
      company: "Tech & Gaming Co.",
      image: "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=3",
      tags: ["YouTube", "Tech", "Gaming"],
      price: "$1000",
      deadline: "Apr 20, 2025"
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <TaskHeader />

      <main className="pt-[60px] pb-20">
        <div className="p-4">
          <div className="space-y-6">
            <TaskSearch showFilters={showFilters} setShowFilters={setShowFilters} />

            <JobSection 
              title="Relevant Jobs"
              jobs={relevantJobs}
              seeAllLink="/influencer/jobs"
            />

            <JobSection 
              title="Recently Viewed"
              jobs={recentlyViewed}
              seeAllLink="/influencer/recently-viewed"
            />

            <JobSection 
              title="Saved Jobs"
              jobs={savedJobs}
              seeAllLink="/influencer/saved-jobs"
            />

            <TaskAnalytics />
          </div>
        </div>

        <TaskNavigation />
      </main>
    </div>
  );
};

export default Tasks;
