
import { useNavigate, useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { ArrowLeft, MoreVertical, Plus, Send, Image, Mic, Smile, Paperclip } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Message {
  id: string;
  content: string;
  user_id: string;
  created_at: string;
  attachment_url?: string;
  attachment_type?: string;
  attachment_name?: string;
}

const ChatDetail = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [jobApplication, setJobApplication] = useState<any>(null);

  useEffect(() => {
    // Get current user
    supabase.auth.getUser().then(({ data: { user }}) => {
      if (user) {
        setCurrentUserId(user.id);
      }
    });

    // Fetch job application for this company
    const fetchJobApplication = async () => {
      const { data: applications, error } = await supabase
        .from('job_applications')
        .select('*')
        .eq('company', id?.replace(/([A-Z])/g, ' $1').trim()) // Convert route param back to company name
        .single();

      if (error) {
        console.error('Error fetching job application:', error);
        return;
      }

      if (applications) {
        setJobApplication(applications);
        // Now fetch messages for this job application
        fetchMessages(applications.id);
      }
    };

    fetchJobApplication();

    // Subscribe to new messages
    const channel = supabase
      .channel('messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
        },
        (payload) => {
          setMessages(current => [...current, payload.new as Message]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id]);

  const fetchMessages = async (jobApplicationId: string) => {
    try {
      const { data, error } = await supabase
        .from('messages')
        .select('*')
        .eq('job_application_id', jobApplicationId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setMessages(data || []);
      setIsLoading(false);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast.error("Failed to load messages");
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !jobApplication) return;

    try {
      const { error } = await supabase
        .from('messages')
        .insert({
          content: message,
          user_id: currentUserId,
          job_application_id: jobApplication.id
        });

      if (error) throw error;

      setMessage("");
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error("Failed to send message");
    }
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-neutral-900 text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="fixed top-0 left-0 right-0 z-50 bg-neutral-900 border-b border-neutral-800">
        <div className="flex items-center justify-between p-4">
          <button 
            className="p-2 text-neutral-400 hover:text-white transition-colors"
            onClick={() => navigate('/messages')}
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="flex items-center">
            <img 
              src={`https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=${id}`}
              alt={jobApplication?.company} 
              className="w-8 h-8 rounded-full"
            />
            <div className="ml-3">
              <div className="text-sm font-medium">{jobApplication?.company}</div>
              <div className="text-xs text-neutral-400">Active now</div>
            </div>
          </div>
          <button className="p-2 text-neutral-400 hover:text-white transition-colors">
            <MoreVertical className="w-6 h-6" />
          </button>
        </div>
      </header>

      <main className="pt-20 pb-36">
        <div className="px-4 space-y-4">
          <div className="text-center">
            <span className="text-xs text-neutral-500">Today</span>
          </div>
          
          {messages.map((msg) => (
            <div 
              key={msg.id} 
              className={`flex items-start gap-2 ${msg.user_id === currentUserId ? 'justify-end' : ''}`}
            >
              {msg.user_id !== currentUserId && (
                <img 
                  src={`https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=${id}`}
                  alt={jobApplication?.company} 
                  className="w-6 h-6 rounded-full"
                />
              )}
              <div 
                className={`p-3 max-w-[80%] rounded-2xl ${
                  msg.user_id === currentUserId
                    ? 'bg-gradient-to-r from-purple-500 to-pink-500 rounded-tr-sm' 
                    : 'bg-neutral-800 rounded-tl-sm'
                }`}
              >
                <p className="text-sm">{msg.content}</p>
                {msg.attachment_url && (
                  <div className="mt-2 bg-neutral-700/50 rounded-lg p-2 flex items-center gap-2">
                    <Image className="w-4 h-4" />
                    <span className="text-xs">{msg.attachment_name}</span>
                  </div>
                )}
                <span className="text-xs text-neutral-400 mt-1 block">
                  {formatTime(msg.created_at)}
                </span>
              </div>
            </div>
          ))}
        </div>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800">
        <div className="p-4">
          <div className="flex items-center gap-2">
            <button className="p-3 bg-neutral-800 hover:bg-neutral-700 rounded-full text-neutral-400 hover:text-white transition-colors">
              <Plus className="w-5 h-5" />
            </button>
            <div className="flex-1 bg-neutral-800 rounded-full px-4 py-2">
              <input 
                type="text" 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type a message..." 
                className="w-full bg-transparent outline-none text-sm"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    handleSendMessage();
                  }
                }}
              />
            </div>
            <button 
              className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full text-white hover:opacity-90 transition-opacity"
              onClick={handleSendMessage}
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="flex justify-between mt-2 px-2">
            <button className="p-2 text-neutral-400 hover:text-white transition-colors">
              <Image className="w-5 h-5" />
            </button>
            <button className="p-2 text-neutral-400 hover:text-white transition-colors">
              <Mic className="w-5 h-5" />
            </button>
            <button className="p-2 text-neutral-400 hover:text-white transition-colors">
              <Smile className="w-5 h-5" />
            </button>
            <button className="p-2 text-neutral-400 hover:text-white transition-colors">
              <Paperclip className="w-5 h-5" />
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default ChatDetail;
