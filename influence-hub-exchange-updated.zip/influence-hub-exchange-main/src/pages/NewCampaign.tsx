
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { CampaignDetailsForm } from "@/components/campaign/CampaignDetailsForm";
import { BudgetForm } from "@/components/campaign/BudgetForm";
import { CampaignSummary } from "@/components/campaign/CampaignSummary";

interface CampaignDetails {
  name: string;
  objective: string;
  ageRange: string;
  location: string;
  interests: string;
  platforms: string[];
}

interface BudgetDetails {
  minBudget: string;
  maxBudget: string;
  duration: string;
}

const NewCampaign = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<number>(0); // Starting with campaign type selection
  const [campaignType, setCampaignType] = useState<"influencer" | "content" | "">("");
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [selectedObjective, setSelectedObjective] = useState<string>("");
  const [campaignDetails, setCampaignDetails] = useState<CampaignDetails>({
    name: "",
    objective: "",
    ageRange: "",
    location: "",
    interests: "",
    platforms: [],
  });
  const [budgetDetails, setBudgetDetails] = useState<BudgetDetails>({
    minBudget: "",
    maxBudget: "",
    duration: "30",
  });

  const togglePlatform = (platformId: string) => {
    setSelectedPlatforms(prev => 
      prev.includes(platformId) 
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };

  const handleContinue = () => {
    if (step < 3) {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setStep(step - 1);
    } else {
      navigate("/business/campaigns");
    }
  };

  const renderCampaignTypeSelection = () => (
    <div className="p-4 space-y-4">
      <h2 className="text-lg mb-4">Select Campaign Type</h2>
      <div className="grid grid-cols-1 gap-4">
        <button
          onClick={() => {
            setCampaignType("influencer");
            setStep(1);
          }}
          className={`p-6 rounded-lg border text-left transition-colors hover:bg-neutral-700 ${
            campaignType === "influencer" ? "border-[#9b87f5] bg-neutral-700" : "border-neutral-700 bg-neutral-800"
          }`}
        >
          <div className="flex items-center gap-3">
            <i className="fa-solid fa-users text-2xl"></i>
            <div>
              <h3 className="font-medium">Influencer Marketing</h3>
              <p className="text-sm text-neutral-400 mt-1">Partner with influencers to promote your brand</p>
            </div>
          </div>
        </button>
        <button
          onClick={() => {
            setCampaignType("content");
            setStep(1);
          }}
          className={`p-6 rounded-lg border text-left transition-colors hover:bg-neutral-700 ${
            campaignType === "content" ? "border-[#9b87f5] bg-neutral-700" : "border-neutral-700 bg-neutral-800"
          }`}
        >
          <div className="flex items-center gap-3">
            <i className="fa-solid fa-photo-film text-2xl"></i>
            <div>
              <h3 className="font-medium">Content Creation</h3>
              <p className="text-sm text-neutral-400 mt-1">Get custom content created for your brand</p>
            </div>
          </div>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-neutral-900 text-white">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <button 
            className="p-2"
            onClick={handleBack}
          >
            <i className="fa-solid fa-arrow-left"></i>
          </button>
          <div className="text-lg tracking-wide">New Campaign</div>
          <button className="p-2">
            <i className="fa-regular fa-circle-question"></i>
          </button>
        </div>
      </header>

      <main className="pb-24">
        <div className="px-4 py-6 bg-neutral-800/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-neutral-400">Step {step} of 3</span>
            <span className="text-sm text-neutral-400">
              {step === 0 ? "Campaign Type" : 
               step === 1 ? "Campaign Details" : 
               step === 2 ? "Budget & Duration" : 
               "Review & Launch"}
            </span>
          </div>
          <div className="w-full bg-neutral-700 h-1 rounded-full">
            <div 
              className="h-full bg-gradient-to-r from-[#9b87f5] to-[#7E69AB] rounded-full transition-all duration-300"
              style={{ width: `${(step / 3) * 100}%` }}
            ></div>
          </div>
        </div>

        {step === 0 && renderCampaignTypeSelection()}
        {step === 1 && (
          <CampaignDetailsForm
            campaignDetails={campaignDetails}
            selectedObjective={selectedObjective}
            selectedPlatforms={selectedPlatforms}
            onDetailsChange={setCampaignDetails}
            onObjectiveSelect={setSelectedObjective}
            onPlatformToggle={togglePlatform}
            campaignType={campaignType}
          />
        )}
        {step === 2 && (
          <BudgetForm
            budgetDetails={budgetDetails}
            onBudgetChange={setBudgetDetails}
            campaignType={campaignType}
          />
        )}
        {step === 3 && (
          <CampaignSummary
            campaignDetails={campaignDetails}
            budgetDetails={budgetDetails}
            selectedPlatforms={selectedPlatforms}
          />
        )}
      </main>

      <footer className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 p-4">
        <div className="flex gap-3">
          <button 
            className="flex-1 px-4 py-3 bg-neutral-800 rounded-lg text-sm hover:bg-neutral-700 transition-colors"
            onClick={() => navigate("/business/campaigns")}
          >
            Save as Draft
          </button>
          <button 
            className="flex-1 px-4 py-3 bg-neutral-700 rounded-lg text-sm hover:bg-neutral-600 transition-colors"
            onClick={handleContinue}
          >
            {step === 3 ? "Launch Campaign" : "Continue"}
          </button>
        </div>
      </footer>
    </div>
  );
};

export default NewCampaign;
