
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import Dashboard from "./pages/Dashboard";
import BusinessLogin from "./pages/BusinessLogin";
import BusinessRegistration from "./pages/BusinessRegistration";
import BusinessCampaigns from "./pages/BusinessCampaigns";
import BusinessMessages from "./pages/BusinessMessages";
import BusinessProfile from "./pages/BusinessProfile";
import FindTalents from "./pages/FindTalents";
import Messages from "./pages/Messages";
import Tasks from "./pages/Tasks";
import Portfolio from "./pages/Portfolio";
import Profile from "./pages/Profile";
import SavedJobs from "./pages/SavedJobs";
import SocialMediaProfiles from "./pages/SocialMediaProfiles";
import EditProfile from "./pages/EditProfile";
import Proposals from "./pages/Proposals";
import Jobs from "./pages/Jobs";
import InfluencerLogin from "./pages/InfluencerLogin";
import CreatorRegistration from "./pages/CreatorRegistration";
import IdVerification from "./pages/IdVerification";
import SelfieVerification from "./pages/SelfieVerification";
import ContentTypePage from "./pages/ContentTypePage";
import SocialMediaConnectPage from "./pages/SocialMediaConnectPage";
import EmailPasswordPage from "./pages/EmailPasswordPage";
import SuccessRegistration from "./pages/SuccessRegistration";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Common Routes */}
        <Route path="/" element={<Index />} />
        <Route path="/login" element={<Login />} />
        <Route path="*" element={<NotFound />} />

        {/* Creator Registration Flow */}
        <Route path="/creator-registration" element={<CreatorRegistration />} />
        <Route path="/id-verification" element={<IdVerification />} />
        <Route path="/selfie-verification" element={<SelfieVerification />} />
        <Route path="/content-type" element={<ContentTypePage />} />
        <Route path="/social-media-connect" element={<SocialMediaConnectPage />} />
        <Route path="/email-password" element={<EmailPasswordPage />} />
        <Route path="/success-registration" element={<SuccessRegistration />} />

        {/* Business Routes */}
        <Route path="/business/login" element={<BusinessLogin />} />
        <Route path="/business/register" element={<BusinessRegistration />} />
        <Route path="/business/dashboard" element={<Dashboard />} />
        <Route path="/business/talents" element={<FindTalents />} />
        <Route path="/business/campaigns" element={<BusinessCampaigns />} />
        <Route path="/business/messages" element={<BusinessMessages />} />
        <Route path="/business/profile" element={<BusinessProfile />} />

        {/* Influencer Routes */}
        <Route path="/influencer/login" element={<InfluencerLogin />} />
        <Route path="/influencer/register" element={<CreatorRegistration />} />
        <Route path="/influencer/dashboard" element={<Dashboard />} />
        <Route path="/influencer/messages" element={<Messages />} />
        <Route path="/influencer/tasks" element={<Tasks />} />
        <Route path="/influencer/jobs" element={<Jobs />} />
        <Route path="/influencer/proposals" element={<Proposals />} />
        <Route path="/influencer/portfolio" element={<Portfolio />} />
        <Route path="/influencer/profile" element={<Profile />} />
        <Route path="/influencer/saved-jobs" element={<SavedJobs />} />
        <Route path="/influencer/social-media" element={<SocialMediaProfiles />} />
        <Route path="/influencer/edit-profile" element={<EditProfile />} />
        <Route path="/influencer/recently-viewed" element={<SavedJobs />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
