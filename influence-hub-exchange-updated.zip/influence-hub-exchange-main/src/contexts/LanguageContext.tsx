
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, LanguageContextType } from './translations/types';
import { languageService } from './translations/languageService';
import { toast } from "sonner";
import { translations } from './translations';

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const loadLanguage = async () => {
      const savedLanguage = await languageService.loadUserLanguagePreference();
      if (savedLanguage) {
        setLanguage(savedLanguage);
      }
    };
    loadLanguage();
  }, []);

  const updateLanguage = async (newLanguage: Language) => {
    const success = await languageService.updateLanguage(newLanguage);
    if (success) {
      setLanguage(newLanguage);
    } else {
      toast.error(translations[language].errorUpdatingLanguage);
    }
  };

  const t = (key: string): string => {
    return languageService.translate(key, language);
  };

  return (
    <LanguageContext.Provider value={{ 
      language, 
      setLanguage: updateLanguage, 
      t 
    }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
