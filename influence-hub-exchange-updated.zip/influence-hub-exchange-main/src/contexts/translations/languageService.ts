
import { supabase } from "@/integrations/supabase/client";
import { Language } from "./types";
import { translations } from "./index";
import { toast } from "sonner";

export const languageService = {
  async loadUserLanguagePreference(): Promise<Language | null> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('user_language_preferences')
        .select('language')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;
      
      if (data) {
        return data.language as Language;
      } else {
        await supabase
          .from('user_language_preferences')
          .insert([{ user_id: user.id, language: 'en' }]);
        return 'en';
      }
    } catch (error) {
      console.error('Error loading language preference:', error);
      return null;
    }
  },

  async updateLanguage(newLanguage: Language): Promise<boolean> {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return false;

      const { error } = await supabase
        .from('user_language_preferences')
        .upsert({ 
          user_id: user.id, 
          language: newLanguage 
        });

      if (error) throw error;
      
      toast.success(translations[newLanguage].languageUpdated);
      return true;
    } catch (error) {
      console.error('Error updating language:', error);
      return false;
    }
  },

  translate(key: string, language: Language): string {
    return translations[language][key] || key;
  }
};
