
import { supabase } from "@/integrations/supabase/client";
import { SocialMediaPlatform, SocialMediaFormData, SocialMediaFormState } from "@/types/socialMedia";

export const loadSocialMediaData = async (): Promise<SocialMediaFormState> => {
  const initialState: SocialMediaFormState = {
    instagram: { username: "", followerCount: "", engagementRate: "" },
    tiktok: { username: "", followerCount: "", engagementRate: "" },
    youtube: { username: "", followerCount: "", engagementRate: "" }
  };

  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No authenticated user');

    const { data: accounts, error } = await supabase
      .from('social_media_accounts')
      .select('*')
      .eq('user_id', user.id);

    if (error) throw error;

    if (accounts) {
      accounts.forEach((account) => {
        const platform = account.platform.toLowerCase() as SocialMediaPlatform;
        initialState[platform] = {
          username: account.username,
          followerCount: account.follower_count?.toString() || "",
          engagementRate: account.engagement_rate?.toString() || "",
          screenshotPath: account.screenshot_path,
        };
      });
    }
    return initialState;
  } catch (error) {
    console.error('Error loading social media data:', error);
    return initialState;
  }
};

export const getScreenshotUrl = async (path: string) => {
  try {
    const { data } = await supabase.storage
      .from('social-media-screenshots')
      .createSignedUrl(path, 3600);

    return data?.signedUrl;
  } catch (error) {
    console.error('Error getting screenshot URL:', error);
    return null;
  }
};

export const updateSocialMediaAccount = async (
  platform: SocialMediaPlatform,
  formData: SocialMediaFormData
) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No authenticated user');

    const { error } = await supabase
      .from('social_media_accounts')
      .upsert({
        user_id: user.id,
        platform: platform.toUpperCase(),
        username: formData.username,
        follower_count: parseInt(formData.followerCount) || null,
        engagement_rate: parseFloat(formData.engagementRate) || null,
        screenshot_path: formData.screenshotPath,
      }, {
        onConflict: 'platform',
      });

    if (error) throw error;
  } catch (error) {
    console.error('Error saving social media data:', error);
    throw error;
  }
};

export const uploadScreenshot = async (file: File, platform: SocialMediaPlatform) => {
  const fileName = `${platform}/${crypto.randomUUID()}.${file.name.split('.').pop()}`;
  
  const { error: uploadError } = await supabase.storage
    .from('social-media-screenshots')
    .upload(fileName, file);

  if (uploadError) throw uploadError;

  return fileName;
};
