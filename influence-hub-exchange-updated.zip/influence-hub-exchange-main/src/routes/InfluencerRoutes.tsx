import { Routes, Route, Navigate } from 'react-router-dom';
import InfluencerDashboard from '../pages/influencer/Dashboard';
import Tasks from '../pages/influencer/Tasks';
import Collaborations from '../pages/influencer/Collaborations';
import Earnings from '../pages/influencer/Earnings';
import Profile from '../pages/influencer/Profile';
import EditProfile from '../pages/influencer/EditProfile';
import CreatorRegistration from '../pages/influencer/CreatorRegistration';
import Portfolio from '../pages/influencer/Portfolio';
import SocialMediaProfiles from '../pages/influencer/SocialMediaProfiles';
import SuccessRegistration from '../pages/influencer/SuccessRegistration';
import PrivateRoute from './PrivateRoute';

const InfluencerRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<PrivateRoute roleRequired="influencer" />}>
        <Route index element={<Tasks />} />
        <Route path="collaborations" element={<Collaborations />} />
        <Route path="earnings" element={<Earnings />} />
        <Route path="profile" element={<Profile />} />
        <Route path="profile/edit" element={<EditProfile />} />
        <Route path="register" element={<CreatorRegistration />} />
        <Route path="portfolio" element={<Portfolio />} />
        <Route path="social-media" element={<SocialMediaProfiles />} />
        <Route path="registration-success" element={<SuccessRegistration />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

export default InfluencerRoutes;
