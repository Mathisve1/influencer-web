import { Routes, Route, Navigate } from 'react-router-dom';
import BusinessDashboard from '../pages/business/Dashboard';
import Campaigns from '../pages/business/Campaigns';
import Analytics from '../pages/business/Analytics';
import Profile from '../pages/business/Profile';
import BusinessEditProfile from '../pages/business/BusinessEditProfile';
import BusinessCompanyInfo from '../pages/business/BusinessCompanyInfo';
import BusinessSocialMediaProfiles from '../pages/business/BusinessSocialMediaProfiles';
import BusinessContact from '../pages/business/BusinessContact';
import BusinessMessages from '../pages/business/BusinessMessages';
import BusinessDetails from '../pages/business/BusinessDetails';
import PrivateRoute from './PrivateRoute';

const BusinessRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<PrivateRoute roleRequired="business" />}>
        <Route index element={<BusinessDashboard />} />
        <Route path="campaigns" element={<Campaigns />} />
        <Route path="analytics" element={<Analytics />} />
        <Route path="profile" element={<Profile />} />
        <Route path="profile/edit" element={<BusinessEditProfile />} />
        <Route path="company-info" element={<BusinessCompanyInfo />} />
        <Route path="social-media" element={<BusinessSocialMediaProfiles />} />
        <Route path="contact" element={<BusinessContact />} />
        <Route path="messages" element={<BusinessMessages />} />
        <Route path="details" element={<BusinessDetails />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
};

export default BusinessRoutes;
