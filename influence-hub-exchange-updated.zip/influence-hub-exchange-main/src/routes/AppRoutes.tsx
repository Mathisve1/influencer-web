import { Routes, Route, Navigate } from 'react-router-dom';
import Login from '../pages/auth/Login';
import RegisterInfluencer from '../pages/auth/RegisterInfluencer';
import RegisterBusiness from '../pages/auth/RegisterBusiness';
import Messages from '../pages/Messages';
import Notifications from '../pages/Notifications';
import NotFound from '../pages/NotFound';
import { useAuth } from '../context/AuthContext';
import BusinessRoutes from './BusinessRoutes';
import InfluencerRoutes from './InfluencerRoutes';
import MainLayout from '../layouts/MainLayout';

const AppRoutes = () => {
  const { user } = useAuth();

  return (
    <Routes>
      {!user ? (
        <>
          <Route path="/login" element={<Login />} />
          <Route path="/register-influencer" element={<RegisterInfluencer />} />
          <Route path="/register-business" element={<RegisterBusiness />} />
          <Route path="*" element={<Navigate to="/login" />} />
        </>
      ) : (
        <Route element={<MainLayout />}>
          <Route path="/messages" element={<Messages />} />
          <Route path="/notifications" element={<Notifications />} />
          {user.role === 'business' ? (
            <Route path="/*" element={<BusinessRoutes />} />
          ) : (
            <Route path="/*" element={<InfluencerRoutes />} />
          )}
        </Route>
      )}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default AppRoutes;
