
export type SocialMediaPlatform = "instagram" | "tiktok" | "youtube";

export interface SocialMediaFormData {
  username: string;
  followerCount: string;
  engagementRate: string;
  screenshotPath?: string;
  screenshotUrl?: string;
}

export type SocialMediaFormState = Record<SocialMediaPlatform, SocialMediaFormData>;
