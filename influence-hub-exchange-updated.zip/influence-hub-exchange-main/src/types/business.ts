
export interface BusinessProfile {
  id: string;
  company_name: string | null;
  description: string | null;
  industry: string | null;
  logo_url: string | null;
  banner_url: string | null;
  is_verified: boolean;
}

export interface SavedTalent {
  id: string;
  business_id: string;
  talent_id: string;
  notes: string | null;
  list_category: string | null;
  created_at: string;
  profiles: {
    first_name: string | null;
    last_name: string | null;
  } | null;
}

export interface CollaborationHistory {
  id: string;
  business_id: string;
  talent_id: string;
  campaign_name: string;
  start_date: string;
  end_date: string | null;
  performance_rating: number | null;
  notes: string | null;
}
