
export interface Earning {
  id: string;
  amount: number;
  status: 'completed' | 'ongoing' | 'pending';
  job_title: string;
  company: string;
  date: string;
}

export interface Totals {
  total: number;
  ongoing: number;
  pending: number;
}

export interface ChartData {
  date: string;
  amount: number;
}
