
import React from "react";

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
  title: string;
}

const StepIndicator = ({ currentStep, totalSteps, title }: StepIndicatorProps) => {
  const steps = Array.from({ length: totalSteps }, (_, i) => i + 1);

  return (
    <div className="bg-neutral-900 border-b border-neutral-800">
      <div className="container max-w-md mx-auto px-4 py-3">
        <div className="flex gap-2 mb-2">
          {steps.map((step) => (
            <div 
              key={step} 
              className="h-1 flex-1 rounded-full overflow-hidden bg-neutral-800"
            >
              <div 
                className={`h-full ${step <= currentStep ? 'bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end' : ''} 
                  transition-all duration-300 ease-in-out`}
              />
            </div>
          ))}
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-neutral-400">
            Step {currentStep} of {totalSteps}
          </span>
          <span className="text-sm text-neutral-400">{title}</span>
        </div>
      </div>
    </div>
  );
};

export default StepIndicator;
