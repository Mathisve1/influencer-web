
import { Star } from "lucide-react";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { Talent } from "@/pages/FindTalents";
import { Button } from "@/components/ui/button";

interface TalentCardProps {
  talent: Talent;
  onConnect: () => void;
}

export const TalentCard = ({ talent, onConnect }: TalentCardProps) => {
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveTalent = async () => {
    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('saved_talents')
        .insert({
          talent_id: talent.id,
          business_id: (await supabase.auth.getUser()).data.user?.id,
        });

      if (error) throw error;
      toast.success('Talent saved successfully');
    } catch (error) {
      console.error('Error saving talent:', error);
      toast.error('Could not save talent');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="bg-neutral-800 rounded-xl p-4 border border-neutral-700">
      <div className="flex gap-4">
        <img 
          src={talent.avatar} 
          alt={talent.name}
          className="w-16 h-16 rounded-full border-2 border-purple-500"
        />
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium">{talent.name}</h3>
              <p className="text-sm text-neutral-400 flex items-center gap-1">
                <i className="fa-solid fa-location-dot text-xs"></i>
                {talent.location}
              </p>
            </div>
            <div className="flex items-center gap-1 text-yellow-400">
              <Star className="w-4 h-4 fill-current" />
              <span className="text-sm">{talent.rating}</span>
            </div>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {talent.specialties.map(specialty => (
              <span 
                key={specialty}
                className="px-2 py-1 bg-neutral-700 rounded-full text-xs"
              >
                {specialty}
              </span>
            ))}
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-neutral-400 mb-1">Rate</p>
              <p className="text-sm">${talent.rate}/project</p>
            </div>
            <div>
              <p className="text-xs text-neutral-400 mb-1">Completed Jobs</p>
              <p className="text-sm">{talent.completedJobs}</p>
            </div>
          </div>

          <div className="mt-4">
            <p className="text-xs text-neutral-400 mb-2">Social Media Presence</p>
            <div className="flex gap-4">
              {talent.platforms.map(platform => (
                <div key={platform.name} className="flex-1">
                  <p className="text-xs font-medium">{platform.name}</p>
                  <p className="text-xs text-neutral-400">
                    {platform.followers.toLocaleString()} followers
                  </p>
                  <p className="text-xs text-green-400">
                    {platform.engagement}% engagement
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-4 flex justify-end gap-2">
        <Button
          variant="outline"
          onClick={handleSaveTalent}
          disabled={isSaving}
          className="border-neutral-700 text-white hover:bg-neutral-700"
        >
          <i className="fa-regular fa-bookmark mr-2"></i>
          Save
        </Button>
        <Button
          onClick={onConnect}
          className="bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end hover:opacity-90 transition-opacity"
        >
          Connect
        </Button>
      </div>
    </div>
  );
};
