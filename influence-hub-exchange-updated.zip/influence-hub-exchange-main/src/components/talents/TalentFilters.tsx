import { DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";

interface TalentFiltersProps {
  specialties: string[];
  onSpecialtiesChange: (specialties: string[]) => void;
  platforms: string[];
  onPlatformsChange: (platforms: string[]) => void;
  languages: string[];
  onLanguagesChange: (languages: string[]) => void;
  rateRange: { min: number; max: number };
  onRateRangeChange: (range: { min: number; max: number }) => void;
  followersRange: { min: number; max: number };
  onFollowersRangeChange: (range: { min: number; max: number }) => void;
  engagementRange: { min: number; max: number };
  onEngagementRangeChange: (range: { min: number; max: number }) => void;
}

const SPECIALTIES = [
  "Fashion", "Beauty", "Lifestyle", "Tech", "Gaming", "Education",
  "Food", "Travel", "Fitness", "Business", "Entertainment", "Art"
];

const PLATFORMS = [
  "Instagram", "TikTok", "YouTube", "Twitter", "LinkedIn", "Facebook"
];

const LANGUAGES = [
  "English", "Spanish", "Mandarin", "Hindi", "Arabic", "French",
  "Portuguese", "Japanese", "Korean", "German"
];

export const TalentFilters = ({
  specialties,
  onSpecialtiesChange,
  platforms,
  onPlatformsChange,
  languages,
  onLanguagesChange,
  rateRange,
  onRateRangeChange,
  followersRange,
  onFollowersRangeChange,
  engagementRange,
  onEngagementRangeChange,
}: TalentFiltersProps) => {
  const toggleSpecialty = (specialty: string) => {
    if (specialties.includes(specialty)) {
      onSpecialtiesChange(specialties.filter(s => s !== specialty));
    } else {
      onSpecialtiesChange([...specialties, specialty]);
    }
  };

  const togglePlatform = (platform: string) => {
    if (platforms.includes(platform)) {
      onPlatformsChange(platforms.filter(p => p !== platform));
    } else {
      onPlatformsChange([...platforms, platform]);
    }
  };

  const toggleLanguage = (language: string) => {
    if (languages.includes(language)) {
      onLanguagesChange(languages.filter(l => l !== language));
    } else {
      onLanguagesChange([...languages, language]);
    }
  };

  const handleRateInputChange = (value: string, type: 'min' | 'max') => {
    const numValue = parseInt(value) || 0;
    if (type === 'min') {
      onRateRangeChange({ min: numValue, max: rateRange.max });
    } else {
      onRateRangeChange({ min: rateRange.min, max: numValue });
    }
  };

  const handleFollowersInputChange = (value: string, type: 'min' | 'max') => {
    const numValue = parseInt(value) || 0;
    if (type === 'min') {
      onFollowersRangeChange({ min: numValue, max: followersRange.max });
    } else {
      onFollowersRangeChange({ min: followersRange.min, max: numValue });
    }
  };

  const handleEngagementInputChange = (value: string, type: 'min' | 'max') => {
    const numValue = parseFloat(value) || 0;
    if (type === 'min') {
      onEngagementRangeChange({ min: numValue, max: engagementRange.max });
    } else {
      onEngagementRangeChange({ min: engagementRange.min, max: numValue });
    }
  };

  return (
    <DialogContent className="bg-neutral-800 border-neutral-700 text-white max-w-2xl max-h-[90vh] p-0">
      <DialogHeader className="p-6 pb-0">
        <DialogTitle>Advanced Filters</DialogTitle>
      </DialogHeader>
      
      <ScrollArea className="h-[calc(90vh-8rem)]">
        <div className="space-y-6 p-6">
          <div>
            <Label className="text-sm font-medium mb-3">Specialties</Label>
            <div className="flex flex-wrap gap-2">
              {SPECIALTIES.map(specialty => (
                <button
                  key={specialty}
                  onClick={() => toggleSpecialty(specialty)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                    specialties.includes(specialty)
                      ? "bg-brand-gradient-start text-white"
                      : "bg-neutral-700 hover:bg-neutral-600"
                  }`}
                >
                  {specialty}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3">Platforms</Label>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map(platform => (
                <button
                  key={platform}
                  onClick={() => togglePlatform(platform)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                    platforms.includes(platform)
                      ? "bg-brand-gradient-start text-white"
                      : "bg-neutral-700 hover:bg-neutral-600"
                  }`}
                >
                  {platform}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3">Languages</Label>
            <div className="flex flex-wrap gap-2">
              {LANGUAGES.map(language => (
                <button
                  key={language}
                  onClick={() => toggleLanguage(language)}
                  className={`px-3 py-1.5 rounded-full text-sm transition-colors ${
                    languages.includes(language)
                      ? "bg-brand-gradient-start text-white"
                      : "bg-neutral-700 hover:bg-neutral-600"
                  }`}
                >
                  {language}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-3">Rate Range</Label>
            <div className="flex items-center gap-2 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-sm">$</span>
                <Input
                  type="number"
                  value={rateRange.min}
                  onChange={(e) => handleRateInputChange(e.target.value, 'min')}
                  className="w-24 bg-neutral-700 border-neutral-600"
                />
              </div>
              <span className="text-sm">to</span>
              <div className="flex items-center gap-2">
                <span className="text-sm">$</span>
                <Input
                  type="number"
                  value={rateRange.max}
                  onChange={(e) => handleRateInputChange(e.target.value, 'max')}
                  className="w-24 bg-neutral-700 border-neutral-600"
                />
              </div>
            </div>
            <Slider
              value={[rateRange.min, rateRange.max]}
              max={10000}
              step={100}
              onValueChange={([min, max]) => onRateRangeChange({ min, max })}
              className="mt-2"
            />
          </div>

          <div>
            <Label className="text-sm font-medium mb-3">Followers Range</Label>
            <div className="flex items-center gap-2 mb-2">
              <Input
                type="number"
                value={followersRange.min}
                onChange={(e) => handleFollowersInputChange(e.target.value, 'min')}
                className="w-32 bg-neutral-700 border-neutral-600"
              />
              <span className="text-sm">to</span>
              <Input
                type="number"
                value={followersRange.max}
                onChange={(e) => handleFollowersInputChange(e.target.value, 'max')}
                className="w-32 bg-neutral-700 border-neutral-600"
              />
            </div>
            <Slider
              value={[followersRange.min, followersRange.max]}
              max={1000000}
              step={1000}
              onValueChange={([min, max]) => onFollowersRangeChange({ min, max })}
              className="mt-2"
            />
          </div>

          <div>
            <Label className="text-sm font-medium mb-3">Engagement Rate</Label>
            <div className="flex items-center gap-2 mb-2">
              <Input
                type="number"
                value={engagementRange.min}
                onChange={(e) => handleEngagementInputChange(e.target.value, 'min')}
                className="w-24 bg-neutral-700 border-neutral-600"
                step="0.1"
              />
              <span className="text-sm">% to</span>
              <Input
                type="number"
                value={engagementRange.max}
                onChange={(e) => handleEngagementInputChange(e.target.value, 'max')}
                className="w-24 bg-neutral-700 border-neutral-600"
                step="0.1"
              />
              <span className="text-sm">%</span>
            </div>
            <Slider
              value={[engagementRange.min, engagementRange.max]}
              max={100}
              step={0.1}
              onValueChange={([min, max]) => onEngagementRangeChange({ min, max })}
              className="mt-2"
            />
          </div>
        </div>
      </ScrollArea>

      <div className="p-6 pt-0 border-t border-neutral-700">
        <Button
          className="w-full bg-brand-gradient-start hover:opacity-90 transition-opacity"
          variant="default"
        >
          Apply Filters
        </Button>
      </div>
    </DialogContent>
  );
};
