
import { useState, useRef } from "react";
import { Upload } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { SocialMediaPlatform, SocialMediaFormData } from "@/types/socialMedia";
import { updateSocialMediaAccount, uploadScreenshot, getScreenshotUrl } from "@/utils/socialMediaUtils";

interface PlatformCardProps {
  platform: SocialMediaPlatform;
  expanded: boolean;
  formData: SocialMediaFormData;
  onClick: () => void;
  onUpdate: (platform: SocialMediaPlatform, data: SocialMediaFormData) => void;
}

const PlatformCard = ({ platform, expanded, formData, onClick, onUpdate }: PlatformCardProps) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = async (field: keyof SocialMediaFormData, value: string) => {
    const newData = {
      ...formData,
      [field]: value,
    };
    onUpdate(platform, newData);

    try {
      await updateSocialMediaAccount(platform, newData);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error saving data",
        description: "Please try again.",
      });
    }
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const fileName = await uploadScreenshot(file, platform);
      const signedUrl = await getScreenshotUrl(fileName);

      const newData = {
        ...formData,
        screenshotPath: fileName,
        screenshotUrl: signedUrl || undefined,
      };

      onUpdate(platform, newData);
      await updateSocialMediaAccount(platform, newData);

      toast({
        title: "Screenshot uploaded",
        description: "Your screenshot has been saved successfully.",
      });
    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error.message,
      });
    }

    event.target.value = '';
  };

  const getPlatformIcon = () => {
    switch (platform) {
      case "instagram":
        return "fa-brands fa-instagram";
      case "tiktok":
        return "fa-brands fa-tiktok";
      case "youtube":
        return "fa-brands fa-youtube";
    }
  };

  const renderContent = () => {
    if (!expanded) return null;

    return (
      <div className="space-y-4">
        <div>
          <label className="text-sm text-neutral-400 block mb-2">
            Username
          </label>
          <input
            type="text"
            className="w-full bg-neutral-700 rounded-lg p-3"
            placeholder="@username"
            value={formData.username}
            onChange={(e) => handleInputChange("username", e.target.value)}
          />
        </div>
        <div>
          <label className="text-sm text-neutral-400 block mb-2">
            Follower Count
          </label>
          <input
            type="number"
            className="w-full bg-neutral-700 rounded-lg p-3"
            placeholder="0"
            value={formData.followerCount}
            onChange={(e) => handleInputChange("followerCount", e.target.value)}
          />
        </div>
        <div>
          <label className="text-sm text-neutral-400 block mb-2">
            Engagement Rate (%)
          </label>
          <input
            type="number"
            className="w-full bg-neutral-700 rounded-lg p-3"
            placeholder="0.00"
            value={formData.engagementRate}
            onChange={(e) => handleInputChange("engagementRate", e.target.value)}
          />
        </div>
        <button 
          onClick={handleFileSelect}
          className="w-full border border-neutral-600 rounded-lg p-3 flex items-center justify-center gap-2 hover:border-brand-gradient-end/50 transition-colors"
        >
          <Upload className="h-4 w-4" />
          <span>Upload Screenshot</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        {formData.screenshotUrl && (
          <div className="mt-4">
            <img
              src={formData.screenshotUrl}
              alt={`${platform} screenshot`}
              className="max-h-48 mx-auto rounded-lg border border-neutral-700"
            />
          </div>
        )}
      </div>
    );
  };

  return (
    <div 
      className={`bg-neutral-800 rounded-xl p-4 cursor-pointer transition-colors ${
        expanded ? "border border-brand-gradient-end/50" : ""
      }`}
      onClick={onClick}
    >
      <div className="flex items-center gap-3 mb-4">
        <i className={`${getPlatformIcon()} text-xl`}></i>
        <span>{platform.charAt(0).toUpperCase() + platform.slice(1)}</span>
        <span className="ml-auto px-2 py-1 bg-neutral-700 rounded-full text-xs">
          {formData.username ? 'Connected' : 'Connect'}
        </span>
      </div>
      {renderContent()}
    </div>
  );
};

export default PlatformCard;
