
import { FC } from 'react';
import { useNavigate } from 'react-router-dom';
import { JobCard } from '@/components/jobs/JobCard';

interface Job {
  id: number;
  title: string;
  company: string;
  image: string;
  tags: string[];
  price: string;
  deadline: string;
}

interface JobSectionProps {
  title: string;
  jobs: Job[];
  seeAllLink: string;
}

export const JobSection: FC<JobSectionProps> = ({ title, jobs, seeAllLink }) => {
  const navigate = useNavigate();
  
  return (
    <section>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg">{title}</h2>
        <button 
          className="text-sm text-neutral-400"
          onClick={() => navigate(seeAllLink)}
        >
          See all
        </button>
      </div>
      <div className="space-y-4">
        {jobs.map(job => (
          <JobCard key={job.id} {...job} />
        ))}
      </div>
    </section>
  );
};
