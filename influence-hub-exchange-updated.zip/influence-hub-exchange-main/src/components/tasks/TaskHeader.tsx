
import { FC } from 'react';

export const TaskHeader: FC = () => {
  return (
    <header className="fixed top-0 left-0 right-0 bg-neutral-900 border-b border-neutral-800 z-50">
      <div className="px-4 py-3 flex items-center justify-between">
        <div className="text-xl tracking-wide">TRACE</div>
        <div className="flex items-center gap-3">
          <button className="p-2">
            <i className="fa-regular fa-bell"></i>
          </button>
          <img
            src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123"
            alt="avatar"
            className="w-8 h-8 rounded-full"
          />
        </div>
      </div>
    </header>
  );
};
