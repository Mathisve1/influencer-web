
import { FC } from 'react';
import { AdvancedFilters } from '@/components/jobs/AdvancedFilters';

interface TaskSearchProps {
  showFilters: boolean;
  setShowFilters: (show: boolean) => void;
}

export const TaskSearch: FC<TaskSearchProps> = ({ showFilters, setShowFilters }) => {
  return (
    <div className="relative">
      <i className="fa-solid fa-search absolute left-3 top-3 text-neutral-400"></i>
      <input
        type="search"
        placeholder="Search tasks..."
        className="w-full bg-neutral-800 border border-neutral-700 rounded-lg pl-10 pr-4 py-2 text-sm"
        onClick={() => setShowFilters(true)}
      />
      {showFilters && (
        <div className="absolute left-0 right-0 top-full mt-2 z-10">
          <AdvancedFilters />
        </div>
      )}
    </div>
  );
};
