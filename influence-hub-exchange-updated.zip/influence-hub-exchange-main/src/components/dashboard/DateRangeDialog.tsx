
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

interface DateRangeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  startDate?: Date;
  endDate?: Date;
  onStartDateSelect: (date: Date | undefined) => void;
  onEndDateSelect: (date: Date | undefined) => void;
  onDownload: () => void;
}

export const DateRangeDialog = ({
  open,
  onOpenChange,
  startDate,
  endDate,
  onStartDateSelect,
  onEndDateSelect,
  onDownload,
}: DateRangeDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-neutral-900 border border-neutral-800 text-white p-6 max-w-[90%] w-[400px]">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium mb-4">
            {!startDate ? 'Select Start Date' : 'Select End Date'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {(startDate || endDate) && (
            <div className="bg-neutral-800 p-3 rounded-lg text-sm">
              <p className="text-neutral-400 mb-1">Selected Range:</p>
              <div className="flex items-center gap-2">
                <span>{startDate ? format(startDate, 'MMM dd, yyyy') : 'Select start date'}</span>
                <span>→</span>
                <span>{endDate ? format(endDate, 'MMM dd, yyyy') : 'Select end date'}</span>
              </div>
            </div>
          )}
          
          {!startDate ? (
            <div>
              <label className="block text-sm text-neutral-400 mb-2">Start Date</label>
              <Calendar
                mode="single"
                selected={startDate}
                onSelect={onStartDateSelect}
                className="rounded-md border border-neutral-800 scale-90 origin-top-left"
                classNames={{
                  day_selected: "bg-brand-gradient-start text-white hover:bg-brand-gradient-start",
                  day_today: "bg-neutral-800 text-white",
                  day: "text-sm h-8 w-8 p-0 font-normal aria-selected:opacity-100",
                  table: "w-full border-collapse space-y-1",
                  head_cell: "text-neutral-400 font-normal text-[0.8rem] w-8 p-0",
                  cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                }}
              />
            </div>
          ) : (
            <div>
              <label className="block text-sm text-neutral-400 mb-2">End Date</label>
              <Calendar
                mode="single"
                selected={endDate}
                onSelect={onEndDateSelect}
                fromDate={startDate}
                className="rounded-md border border-neutral-800 scale-90 origin-top-left"
                classNames={{
                  day_selected: "bg-brand-gradient-start text-white hover:bg-brand-gradient-start",
                  day_today: "bg-neutral-800 text-white",
                  day: "text-sm h-8 w-8 p-0 font-normal aria-selected:opacity-100",
                  table: "w-full border-collapse space-y-1",
                  head_cell: "text-neutral-400 font-normal text-[0.8rem] w-8 p-0",
                  cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-accent first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20",
                }}
              />
            </div>
          )}
          <div className="flex gap-3 pt-4">
            <button
              onClick={() => {
                if (startDate && !endDate) {
                  onStartDateSelect(undefined);
                } else {
                  onOpenChange(false);
                  onStartDateSelect(undefined);
                  onEndDateSelect(undefined);
                }
              }}
              className="flex-1 py-3 bg-neutral-800 rounded-lg hover:bg-neutral-700 transition-colors"
            >
              {startDate && !endDate ? 'Back' : 'Cancel'}
            </button>
            {startDate && endDate && (
              <button
                onClick={onDownload}
                className="flex-1 py-3 bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-download"></i>
                Download Report
              </button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
