
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { Circle } from "lucide-react";

interface Project {
  id: string;
  title: string;
  description: string;
  start_date: string;
  end_date: string | null;
  status: string;
}

export const ProjectTimeline = () => {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    const fetchProjects = async () => {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('start_date', { ascending: true });

      if (error) {
        console.error('Error fetching projects:', error);
        return;
      }

      setProjects(data || []);
    };

    fetchProjects();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-green-500';
      case 'ongoing':
        return 'text-blue-500';
      default:
        return 'text-yellow-500';
    }
  };

  return (
    <div className="bg-neutral-800 rounded-xl p-4">
      <h2 className="text-lg font-medium mb-4">Project Timeline</h2>
      <div className="space-y-4">
        {projects.map((project) => (
          <div key={project.id} className="flex gap-4">
            <Circle className={`w-2 h-2 mt-2 fill-current ${getStatusColor(project.status)}`} />
            <div className="flex-1">
              <h3 className="font-medium">{project.title}</h3>
              <p className="text-sm text-neutral-400 mt-1">{project.description}</p>
              <div className="flex gap-2 mt-2 text-xs text-neutral-400">
                <span>{format(new Date(project.start_date), 'MMM d, yyyy')}</span>
                {project.end_date && (
                  <>
                    <span>→</span>
                    <span>{format(new Date(project.end_date), 'MMM d, yyyy')}</span>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
