
import { useNavigate } from "react-router-dom";
import { Earning } from "@/types/dashboard";

interface CompletedTasksProps {
  tasks: Earning[];
}

export const CompletedTasks = ({ tasks }: CompletedTasksProps) => {
  const navigate = useNavigate();

  return (
    <div className="bg-neutral-800 rounded-xl p-4">
      <h2 className="text-lg mb-4">Completed Tasks</h2>
      <div className="space-y-3">
        {tasks.map(task => (
          <div 
            key={task.id} 
            className="bg-neutral-700/50 p-4 rounded-xl cursor-pointer hover:bg-neutral-700/70 transition-colors"
            onClick={() => navigate(`/tasks/${task.id}`)}
          >
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-medium">{task.job_title}</h3>
                <p className="text-sm text-neutral-400">{task.company}</p>
              </div>
              <span className="bg-green-500/20 text-green-400 text-xs px-2 py-1 rounded-full">
                Completed
              </span>
            </div>
            <div className="flex justify-between items-center">
              <p className="text-sm text-neutral-400">
                {new Date(task.date).toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric'
                })}
              </p>
              <p className="text-lg">${Number(task.amount).toLocaleString()}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
