
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Circle, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

interface Goal {
  id: string;
  title: string;
  target_amount: number;
  current_amount: number;
  deadline: string;
  status: string;
  category: string;
}

export const GoalsWidget = () => {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [isAddingGoal, setIsAddingGoal] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: "",
    target_amount: "",
    deadline: ""
  });

  useEffect(() => {
    fetchGoals();
  }, []);

  const fetchGoals = async () => {
    // Get the current session to get the user ID
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError) {
      console.error('Error getting session:', sessionError);
      toast.error("Authentication error");
      return;
    }

    if (!session?.user?.id) {
      toast.error("Please login to view goals");
      return;
    }

    const { data, error } = await supabase
      .from('goals')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching goals:', error);
      toast.error("Failed to load goals");
      return;
    }

    setGoals(data || []);
  };

  const handleAddGoal = async () => {
    if (!newGoal.title || !newGoal.target_amount || !newGoal.deadline) {
      toast.error("Please fill in all fields");
      return;
    }

    // Get the current session to get the user ID
    const { data: { session }, error: sessionError } = await supabase.auth.getSession();
    
    if (sessionError || !session?.user?.id) {
      toast.error("Please login to add goals");
      return;
    }

    const { error } = await supabase
      .from('goals')
      .insert({
        title: newGoal.title,
        target_amount: Number(newGoal.target_amount),
        current_amount: 0,
        deadline: newGoal.deadline,
        status: 'ongoing',
        category: 'income',
        user_id: session.user.id
      });

    if (error) {
      console.error('Error adding goal:', error);
      toast.error("Failed to add goal");
      return;
    }

    setIsAddingGoal(false);
    setNewGoal({ title: "", target_amount: "", deadline: "" });
    fetchGoals();
    toast.success("Goal added successfully");
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return "bg-green-500";
    if (progress >= 50) return "bg-yellow-500";
    return "bg-blue-500";
  };

  return (
    <div className="bg-neutral-800 rounded-xl p-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-medium">Goals</h2>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={() => setIsAddingGoal(true)}>
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-4">
        {goals.map((goal) => {
          const progress = (goal.current_amount / goal.target_amount) * 100;
          return (
            <div key={goal.id} className="space-y-2">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Circle className="w-2 h-2 fill-current text-blue-500" />
                  <span className="text-sm">{goal.title}</span>
                </div>
                <span className="text-sm text-neutral-400">
                  ${goal.current_amount.toLocaleString()} / ${goal.target_amount.toLocaleString()}
                </span>
              </div>
              <Progress value={progress} className={getProgressColor(progress)} />
              <p className="text-xs text-neutral-400">Due: {new Date(goal.deadline).toLocaleDateString()}</p>
            </div>
          );
        })}

        {goals.length === 0 && (
          <p className="text-sm text-neutral-400 text-center py-4">No goals set yet</p>
        )}
      </div>

      <Dialog open={isAddingGoal} onOpenChange={setIsAddingGoal}>
        <DialogContent className="bg-neutral-900 border border-neutral-800 text-white p-6">
          <DialogHeader>
            <DialogTitle className="text-lg font-medium mb-4">Add New Goal</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-400 mb-1 block">Goal Title</label>
              <Input
                value={newGoal.title}
                onChange={(e) => setNewGoal(prev => ({ ...prev, title: e.target.value }))}
                className="bg-neutral-800 border-neutral-700"
                placeholder="e.g., Earn $10,000 from freelancing"
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 mb-1 block">Target Amount ($)</label>
              <Input
                type="number"
                value={newGoal.target_amount}
                onChange={(e) => setNewGoal(prev => ({ ...prev, target_amount: e.target.value }))}
                className="bg-neutral-800 border-neutral-700"
                placeholder="10000"
              />
            </div>
            <div>
              <label className="text-sm text-neutral-400 mb-1 block">Deadline</label>
              <Input
                type="date"
                value={newGoal.deadline}
                onChange={(e) => setNewGoal(prev => ({ ...prev, deadline: e.target.value }))}
                className="bg-neutral-800 border-neutral-700"
              />
            </div>
            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setIsAddingGoal(false)}
              >
                Cancel
              </Button>
              <Button
                className="flex-1"
                onClick={handleAddGoal}
              >
                Add Goal
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
