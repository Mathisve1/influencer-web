
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ChartData } from "@/types/dashboard";

interface IncomeChartProps {
  data: ChartData[];
  timeframe: 'Weekly' | 'Monthly' | 'Yearly';
  onTimeframeChange: (timeframe: 'Weekly' | 'Monthly' | 'Yearly') => void;
}

export const IncomeChart = ({ data, timeframe, onTimeframeChange }: IncomeChartProps) => {
  return (
    <div className="bg-neutral-800 p-4 rounded-xl">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg">Income Overview</h2>
        <select 
          className="bg-neutral-800 border border-neutral-700 rounded-lg px-3 py-1 text-sm"
          value={timeframe}
          onChange={(e) => onTimeframeChange(e.target.value as 'Weekly' | 'Monthly' | 'Yearly')}
        >
          <option>Weekly</option>
          <option>Monthly</option>
          <option>Yearly</option>
        </select>
      </div>
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#404040" />
            <XAxis dataKey="date" stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#262626', 
                border: 'none',
                borderRadius: '0.5rem',
                color: '#fff'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="amount" 
              stroke="#8b5cf6" 
              strokeWidth={2}
              dot={{ fill: '#8b5cf6' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
