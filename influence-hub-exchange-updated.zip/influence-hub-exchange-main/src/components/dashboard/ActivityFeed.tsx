
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";

interface Activity {
  id: string;
  activity_type: string;
  description: string;
  created_at: string;
  metadata: any;
}

export const ActivityFeed = () => {
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    const fetchActivities = async () => {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) {
        console.error('Error fetching activities:', error);
        return;
      }

      setActivities(data || []);
    };

    fetchActivities();
  }, []);

  return (
    <div className="bg-neutral-800 rounded-xl p-4">
      <h2 className="text-lg font-medium mb-4">Recent Activity</h2>
      <div className="space-y-4">
        {activities.map((activity) => (
          <div key={activity.id} className="flex items-start gap-3">
            <div className="w-2 h-2 mt-2 rounded-full bg-blue-500" />
            <div className="flex-1">
              <p className="text-sm">{activity.description}</p>
              <p className="text-xs text-neutral-400 mt-1">
                {format(new Date(activity.created_at), 'MMM d, yyyy • h:mm a')}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
