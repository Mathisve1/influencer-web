
import { Totals } from "@/types/dashboard";

interface EarningsOverviewProps {
  totals: Totals;
}

export const EarningsOverview = ({ totals }: EarningsOverviewProps) => {
  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="bg-neutral-800 p-4 rounded-xl">
        <p className="text-neutral-400 text-sm mb-1">Total</p>
        <p className="text-xl">${totals.total.toLocaleString()}</p>
      </div>
      <div className="bg-neutral-800 p-4 rounded-xl">
        <p className="text-neutral-400 text-sm mb-1">Ongoing</p>
        <p className="text-xl">${totals.ongoing.toLocaleString()}</p>
      </div>
      <div className="bg-neutral-800 p-4 rounded-xl">
        <p className="text-neutral-400 text-sm mb-1">Pending</p>
        <p className="text-xl">${totals.pending.toLocaleString()}</p>
      </div>
    </div>
  );
};
