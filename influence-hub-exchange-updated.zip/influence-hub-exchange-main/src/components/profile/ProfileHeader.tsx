
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

export const ProfileHeader = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();

  return (
    <header className="fixed top-0 left-0 right-0 p-4 border-b border-neutral-800 bg-neutral-900 z-50">
      <div className="flex items-center justify-between">
        <button className="p-2">
          <i className="fa-solid fa-arrow-left"></i>
        </button>
        <div className="text-xl tracking-wide">{t('profile')}</div>
        <button className="p-2">
          <i className="fa-solid fa-gear"></i>
        </button>
      </div>
    </header>
  );
};
