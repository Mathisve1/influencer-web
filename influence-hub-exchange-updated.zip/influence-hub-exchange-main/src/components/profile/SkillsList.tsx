
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Skill {
  id: string;
  name: string;
  endorsement_count: number;
}

export const SkillsList = ({ skills, onSkillAdded }: { 
  skills: Skill[];
  onSkillAdded: () => void;
}) => {
  const [newSkill, setNewSkill] = useState("");
  const [isAdding, setIsAdding] = useState(false);

  const handleAddSkill = async () => {
    if (!newSkill.trim()) return;

    try {
      const { error } = await supabase
        .from('skills')
        .insert([{ name: newSkill.trim() }]);

      if (error) throw error;

      toast.success('Skill added successfully');
      setNewSkill("");
      setIsAdding(false);
      onSkillAdded();
    } catch (error) {
      toast.error('Error adding skill');
      console.error('Error:', error);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">
        {skills.map((skill) => (
          <Badge 
            key={skill.id} 
            variant="secondary"
            className="py-2 px-3"
          >
            {skill.name}
            <span className="ml-2 text-xs text-neutral-400">
              {skill.endorsement_count}
            </span>
          </Badge>
        ))}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsAdding(true)}
          className="gap-1"
        >
          <Plus className="w-4 h-4" />
          Add Skill
        </Button>
      </div>

      {isAdding && (
        <div className="flex gap-2">
          <Input
            value={newSkill}
            onChange={(e) => setNewSkill(e.target.value)}
            placeholder="Enter skill name"
            className="max-w-xs"
          />
          <Button onClick={handleAddSkill}>Add</Button>
          <Button variant="ghost" onClick={() => setIsAdding(false)}>
            Cancel
          </Button>
        </div>
      )}
    </div>
  );
};
