
import { useState } from "react";
import { Upload, Image as ImageIcon, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface PortfolioItem {
  id: string;
  title: string;
  description?: string;
  image_url?: string;
  project_url?: string;
}

export const PortfolioGrid = ({ items, onItemAdded }: {
  items: PortfolioItem[];
  onItemAdded: () => void;
}) => {
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload only image files');
      return;
    }

    // Check file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size should be less than 5MB');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const filePath = `${crypto.randomUUID()}.${fileExt}`;

      const { error: uploadError, data } = await supabase.storage
        .from('portfolios')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      if (data) {
        const { data: urlData } = await supabase.storage
          .from('portfolios')
          .getPublicUrl(filePath);

        const { error: dbError } = await supabase
          .from('portfolio_items')
          .insert([{
            title: file.name.split('.')[0],
            image_url: urlData.publicUrl
          }]);

        if (dbError) throw dbError;

        toast.success('Portfolio item added successfully');
        onItemAdded();
      }
    } catch (error) {
      console.error('Error uploading file:', error);
      toast.error('Error uploading file');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      {items.map((item) => (
        <div key={item.id} className="relative aspect-square">
          <img
            src={item.image_url || '/placeholder.svg'}
            alt={item.title}
            className="w-full h-full object-cover rounded-lg"
          />
          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/80 to-transparent rounded-b-lg">
            <h3 className="text-white text-sm font-medium">{item.title}</h3>
          </div>
        </div>
      ))}
      
      <label className="aspect-square bg-neutral-800 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-neutral-700/80 transition-colors text-neutral-400">
        <input
          type="file"
          className="hidden"
          accept="image/*"
          onChange={handleFileUpload}
          disabled={uploading}
        />
        {uploading ? (
          <Loader2 className="w-8 h-8 animate-spin" />
        ) : (
          <>
            <ImageIcon className="w-8 h-8 mb-2" />
            <span className="text-sm">Add Project</span>
          </>
        )}
      </label>
    </div>
  );
};
