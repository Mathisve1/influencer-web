
import { useLanguage } from "@/contexts/LanguageContext";

export const ProfileAvatar = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col items-center mb-8">
      <div className="relative mb-4">
        <img 
          src="https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123" 
          className="w-24 h-24 rounded-full border-2 border-neutral-700" 
          alt="Profile" 
        />
        <button className="absolute bottom-0 right-0 p-2 bg-neutral-800 rounded-full border border-neutral-700">
          <i className="fa-solid fa-camera"></i>
        </button>
      </div>
      <h1 className="text-xl mb-1">John Anderson</h1>
      <p className="text-neutral-400 text-sm">{t('contentCreator')}</p>
    </div>
  );
};
