
import React from "react";

interface CampaignDetailsFormProps {
  campaignDetails: {
    name: string;
    objective: string;
    ageRange: string;
    location: string;
    interests: string;
    platforms: string[];
  };
  selectedObjective: string;
  selectedPlatforms: string[];
  onDetailsChange: (details: any) => void;
  onObjectiveSelect: (objective: string) => void;
  onPlatformToggle: (platform: string) => void;
  campaignType: "influencer" | "content" | "";
}

interface Platform {
  id: string;
  name: string;
  icon: string;
}

interface CampaignObjective {
  id: string;
  name: string;
  icon: string;
}

export const CampaignDetailsForm: React.FC<CampaignDetailsFormProps> = ({
  campaignDetails,
  selectedObjective,
  selectedPlatforms,
  onDetailsChange,
  onObjectiveSelect,
  onPlatformToggle,
  campaignType
}) => {
  const objectives: CampaignObjective[] = [
    { id: "awareness", name: "Brand Awareness", icon: "fa-regular fa-lightbulb" },
    { id: "leads", name: "Lead Generation", icon: "fa-solid fa-bullseye" },
    { id: "sales", name: "Sales", icon: "fa-solid fa-cart-shopping" },
  ];

  const platforms: Platform[] = [
    { id: "instagram", name: "Instagram", icon: "fa-brands fa-instagram" },
    { id: "tiktok", name: "TikTok", icon: "fa-brands fa-tiktok" },
    { id: "youtube", name: "YouTube", icon: "fa-brands fa-youtube" },
  ];

  return (
    <form className="p-4 space-y-6">
      <div className="space-y-2">
        <label className="text-sm text-neutral-400">Campaign Name</label>
        <input 
          type="text" 
          placeholder="Enter campaign name" 
          value={campaignDetails.name}
          onChange={(e) => onDetailsChange({...campaignDetails, name: e.target.value})}
          className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 text-white placeholder:text-neutral-500 focus:outline-none focus:border-[#9b87f5]"
        />
      </div>

      <div className="space-y-2">
        <label className="text-sm text-neutral-400">Campaign Objective</label>
        <div className="grid grid-cols-1 gap-3">
          {objectives.map(objective => (
            <button
              key={objective.id}
              type="button"
              className={`p-4 rounded-lg border text-left transition-colors ${
                selectedObjective === objective.id
                  ? "bg-neutral-700 border-[#9b87f5]"
                  : "bg-neutral-800 border-neutral-700 hover:bg-neutral-700"
              }`}
              onClick={() => {
                onObjectiveSelect(objective.id);
                onDetailsChange({...campaignDetails, objective: objective.id});
              }}
            >
              <div className="flex items-center">
                <i className={`${objective.icon} w-6`}></i>
                <span>{objective.name}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm text-neutral-400">Target Audience</label>
        <div className="space-y-3">
          <input 
            type="text" 
            placeholder="Age range (e.g., 18-34)" 
            value={campaignDetails.ageRange}
            onChange={(e) => onDetailsChange({...campaignDetails, ageRange: e.target.value})}
            className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 placeholder:text-neutral-500 focus:outline-none focus:border-[#9b87f5]"
          />
          <input 
            type="text" 
            placeholder="Location" 
            value={campaignDetails.location}
            onChange={(e) => onDetailsChange({...campaignDetails, location: e.target.value})}
            className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 placeholder:text-neutral-500 focus:outline-none focus:border-[#9b87f5]"
          />
          <input 
            type="text" 
            placeholder="Interests" 
            value={campaignDetails.interests}
            onChange={(e) => onDetailsChange({...campaignDetails, interests: e.target.value})}
            className="w-full p-3 bg-neutral-800 rounded-lg border border-neutral-700 placeholder:text-neutral-500 focus:outline-none focus:border-[#9b87f5]"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm text-neutral-400">Platforms</label>
        <div className="flex flex-wrap gap-2">
          {platforms.map(platform => (
            <button
              key={platform.id}
              type="button"
              onClick={() => onPlatformToggle(platform.id)}
              className={`px-4 py-2 rounded-lg border transition-colors ${
                selectedPlatforms.includes(platform.id)
                  ? "bg-neutral-700 border-[#9b87f5]"
                  : "bg-neutral-800 border-neutral-700 hover:bg-neutral-700"
              }`}
            >
              <i className={`${platform.icon} mr-2`}></i>
              {platform.name}
            </button>
          ))}
        </div>
      </div>
    </form>
  );
};
