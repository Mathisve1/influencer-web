
import { useNavigate } from "react-router-dom";

interface CampaignHeaderProps {
  activeCampaigns: number;
  activeTab: string;
}

export const CampaignHeader = ({ activeCampaigns, activeTab }: CampaignHeaderProps) => {
  const navigate = useNavigate();

  const tabs = [
    { id: 'running', label: 'Running Campaigns', path: '/business/campaigns' },
    { id: 'draft', label: 'Draft Campaigns', path: '/business/campaigns/draft' },
    { id: 'expired', label: 'Expired Campaigns', path: '/business/campaigns/expired' },
  ];

  return (
    <div className="mb-6">
      <h1 className="text-2xl tracking-wide mb-2">Campaign Dashboard</h1>
      <div className="flex items-center justify-between mb-4">
        <p className="text-neutral-400">{activeCampaigns} Active Campaigns</p>
        <button 
          className="px-4 py-2 bg-neutral-800 rounded-lg border border-neutral-700 hover:bg-neutral-700 transition-colors"
          onClick={() => navigate("/business/campaigns/new")}
        >
          <i className="fa-solid fa-plus mr-2"></i>New Campaign
        </button>
      </div>
      
      <div className="flex space-x-2 overflow-x-auto border-b border-neutral-800">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => navigate(tab.path)}
            className={`px-4 py-2 text-sm whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? "text-white border-b-2 border-[#9b87f5]"
                : "text-neutral-400 hover:text-white"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
};
