
import React from "react";

interface Platform {
  id: string;
  name: string;
  icon: string;
}

interface CampaignObjective {
  id: string;
  name: string;
  icon: string;
}

interface CampaignSummaryProps {
  campaignDetails: {
    name: string;
    objective: string;
    ageRange: string;
    location: string;
    interests: string;
    platforms: string[];
  };
  budgetDetails: {
    minBudget: string;
    maxBudget: string;
    duration: string;
  };
  selectedPlatforms: string[];
}

export const CampaignSummary: React.FC<CampaignSummaryProps> = ({
  campaignDetails,
  budgetDetails,
  selectedPlatforms,
}) => {
  const objectives: CampaignObjective[] = [
    { id: "awareness", name: "Brand Awareness", icon: "fa-regular fa-lightbulb" },
    { id: "leads", name: "Lead Generation", icon: "fa-solid fa-bullseye" },
    { id: "sales", name: "Sales", icon: "fa-solid fa-cart-shopping" },
  ];

  const platforms: Platform[] = [
    { id: "instagram", name: "Instagram", icon: "fa-brands fa-instagram" },
    { id: "tiktok", name: "TikTok", icon: "fa-brands fa-tiktok" },
    { id: "youtube", name: "YouTube", icon: "fa-brands fa-youtube" },
  ];

  return (
    <form className="p-4 space-y-6">
      <div className="bg-neutral-800 rounded-lg border border-neutral-700 p-4">
        <h3 className="text-lg mb-4">Campaign Summary</h3>
        
        <div className="space-y-4">
          <div>
            <p className="text-sm text-neutral-400">Campaign Name</p>
            <p className="text-base">{campaignDetails.name}</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-400">Objective</p>
            <p className="text-base">{objectives.find(o => o.id === campaignDetails.objective)?.name}</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-400">Target Audience</p>
            <p className="text-base">Age: {campaignDetails.ageRange}</p>
            <p className="text-base">Location: {campaignDetails.location}</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-400">Budget Range</p>
            <p className="text-base">${budgetDetails.minBudget} - ${budgetDetails.maxBudget}</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-400">Duration</p>
            <p className="text-base">{budgetDetails.duration} days</p>
          </div>
          
          <div>
            <p className="text-sm text-neutral-400">Platforms</p>
            <div className="flex gap-2 mt-1">
              {selectedPlatforms.map(platformId => {
                const platform = platforms.find(p => p.id === platformId);
                return platform ? (
                  <div key={platform.id} className="px-3 py-1 bg-neutral-700 rounded-full text-sm">
                    <i className={`${platform.icon} mr-2`}></i>
                    {platform.name}
                  </div>
                ) : null;
              })}
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};
