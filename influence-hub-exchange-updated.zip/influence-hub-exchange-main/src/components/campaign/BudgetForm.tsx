
import React from "react";

interface BudgetFormProps {
  budgetDetails: {
    minBudget: string;
    maxBudget: string;
    duration: string;
  };
  onBudgetChange: (budget: any) => void;
  campaignType: "influencer" | "content" | "";
}

export const BudgetForm: React.FC<BudgetFormProps> = ({
  budgetDetails,
  onBudgetChange,
  campaignType
}) => {
  return (
    <form className="p-4 space-y-6">
      <div className="space-y-2">
        <label className="text-sm text-[#8E9196]">Budget Range</label>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs text-[#8E9196] mb-1 block">Minimum</label>
            <div className="relative">
              <span className="absolute left-3 top-3 text-[#8E9196]">$</span>
              <input 
                type="number"
                placeholder="0"
                value={budgetDetails.minBudget}
                onChange={(e) => onBudgetChange({...budgetDetails, minBudget: e.target.value})}
                className="w-full p-3 pl-8 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 placeholder:text-[#8E9196] focus:outline-none focus:border-[#9b87f5] text-white"
              />
            </div>
          </div>
          <div>
            <label className="text-xs text-[#8E9196] mb-1 block">Maximum</label>
            <div className="relative">
              <span className="absolute left-3 top-3 text-[#8E9196]">$</span>
              <input 
                type="number"
                placeholder="0"
                value={budgetDetails.maxBudget}
                onChange={(e) => onBudgetChange({...budgetDetails, maxBudget: e.target.value})}
                className="w-full p-3 pl-8 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 placeholder:text-[#8E9196] focus:outline-none focus:border-[#9b87f5] text-white"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm text-[#8E9196]">Campaign Duration</label>
        <div className="space-y-3">
          <select
            value={budgetDetails.duration}
            onChange={(e) => onBudgetChange({...budgetDetails, duration: e.target.value})}
            className="w-full p-3 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 text-white focus:outline-none focus:border-[#9b87f5]"
          >
            <option value="custom">Custom Duration</option>
            <option value="7">7 days</option>
            <option value="14">14 days</option>
            <option value="30">30 days</option>
            <option value="60">60 days</option>
            <option value="90">90 days</option>
          </select>
          
          {budgetDetails.duration === "custom" && (
            <div className="relative">
              <input 
                type="number"
                placeholder="Enter number of days"
                min="1"
                value={budgetDetails.duration === "custom" ? "" : budgetDetails.duration}
                className="w-full p-3 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 placeholder:text-[#8E9196] focus:outline-none focus:border-[#9b87f5] text-white"
                onChange={(e) => {
                  if (e.target.value) {
                    onBudgetChange({...budgetDetails, duration: e.target.value});
                  }
                }}
              />
              <span className="absolute right-3 top-3 text-[#8E9196] text-sm">Days</span>
            </div>
          )}
        </div>
      </div>

      {campaignType === "influencer" && (
        <div className="p-4 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20">
          <h3 className="text-lg mb-4 text-white">Required Follower Range</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-[#8E9196] mb-1 block">Minimum Followers</label>
              <div className="relative">
                <input 
                  type="number"
                  placeholder="e.g., 10000"
                  className="w-full p-3 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 placeholder:text-[#8E9196] focus:outline-none focus:border-[#9b87f5] text-white"
                />
                <span className="absolute right-3 top-3 text-[#8E9196] text-sm">K</span>
              </div>
            </div>
            <div>
              <label className="text-xs text-[#8E9196] mb-1 block">Maximum Followers</label>
              <div className="relative">
                <input 
                  type="number"
                  placeholder="e.g., 50000"
                  className="w-full p-3 bg-[#1A1F2C] rounded-lg border border-[#D6BCFA]/20 placeholder:text-[#8E9196] focus:outline-none focus:border-[#9b87f5] text-white"
                />
                <span className="absolute right-3 top-3 text-[#8E9196] text-sm">K</span>
              </div>
            </div>
          </div>
          <p className="text-xs text-[#8E9196] mt-3">
            Enter the desired follower range for potential influencers
          </p>
        </div>
      )}
    </form>
  );
};
