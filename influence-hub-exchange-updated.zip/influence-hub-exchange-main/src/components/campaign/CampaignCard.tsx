
import { useNavigate } from "react-router-dom";

interface CampaignCardProps {
  id: string;
  title: string;
  budget: {
    used: number;
    total: number;
  };
  creators: Array<{
    id: string;
    avatar: string;
  }>;
}

export const CampaignCard = ({
  id,
  title,
  budget,
  creators,
}: CampaignCardProps) => {
  const navigate = useNavigate();

  return (
    <div className="bg-neutral-800 rounded-xl p-4 border border-neutral-700">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg">{title}</h3>
        <span className="px-2 py-1 bg-green-900/50 text-green-400 rounded-full text-xs">Active</span>
      </div>
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="text-neutral-400">
          <p className="text-xs mb-1">Budget Usage</p>
          <p className="text-sm">${budget.used.toLocaleString()} / ${budget.total.toLocaleString()}</p>
        </div>
        <div className="text-neutral-400">
          <p className="text-xs mb-1">Influencers</p>
          <div className="flex -space-x-2">
            {creators.map((creator, index) => (
              <button 
                key={creator.id}
                onClick={() => navigate(`/business/messages/${creator.id}`)}
                className="relative transform transition-transform hover:scale-110 hover:z-10"
              >
                <img 
                  src={creator.avatar} 
                  className="w-6 h-6 rounded-full border border-neutral-700 cursor-pointer" 
                  alt={`Creator ${index + 1}`}
                />
                <div className="absolute inset-0 rounded-full ring-2 ring-purple-500 opacity-0 hover:opacity-100 transition-opacity" />
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="flex gap-2">
        <button 
          className="flex-1 px-3 py-2 bg-neutral-700 rounded-lg text-sm hover:bg-neutral-600 transition-colors"
          onClick={() => navigate(`/business/campaigns/${id}`)}
        >
          View Details
        </button>
        <button className="w-10 h-10 flex items-center justify-center bg-neutral-700 rounded-lg hover:bg-neutral-600 transition-colors">
          <i className="fa-solid fa-pause"></i>
        </button>
      </div>
    </div>
  );
};
