
import { useNavigate, useLocation } from "react-router-dom";
import { UserSearch } from "lucide-react";

export const BusinessNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#1A1F2C] border-t border-[#D6BCFA]/20 backdrop-blur-sm">
      <div className="flex justify-around py-3">
        <button 
          className={`flex flex-col items-center ${location.pathname === '/business/dashboard' ? 'font-medium' : 'text-[#8E9196]'}`}
          onClick={() => navigate('/business/dashboard')}
        >
          <div className={`${location.pathname === '/business/dashboard' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r' : ''}`}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-1">
              <path d="M3 3V21H21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M18 9L13 14L9.5 10.5L6 14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M18 9H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M18 9V13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className={`text-xs ${location.pathname === '/business/dashboard' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r text-transparent' : ''}`}>Dashboard</span>
        </button>
        
        <button 
          className={`flex flex-col items-center ${location.pathname === '/business/talents' ? 'font-medium' : 'text-[#8E9196]'}`}
          onClick={() => navigate('/business/talents')}
        >
          <div className={`${location.pathname === '/business/talents' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r' : ''}`}>
            <UserSearch className="mb-1 w-6 h-6" />
          </div>
          <span className={`text-xs ${location.pathname === '/business/talents' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r text-transparent' : ''}`}>Find Talents</span>
        </button>

        <button 
          className={`flex flex-col items-center ${location.pathname === '/business/campaigns' ? 'font-medium' : 'text-[#8E9196]'}`}
          onClick={() => navigate('/business/campaigns')}
        >
          <div className={`${location.pathname === '/business/campaigns' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r' : ''}`}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-1">
              <path d="M16 8V16M12 11V16M8 14V16M6 20H18C19.1046 20 20 19.1046 20 18V6C20 4.89543 19.1046 4 18 4H6C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className={`text-xs ${location.pathname === '/business/campaigns' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r text-transparent' : ''}`}>Campaigns</span>
        </button>

        <button 
          className={`flex flex-col items-center ${location.pathname === '/business/messages' ? 'font-medium' : 'text-[#8E9196]'}`}
          onClick={() => navigate('/business/messages')}
        >
          <div className={`${location.pathname === '/business/messages' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r' : ''}`}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-1">
              <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className={`text-xs ${location.pathname === '/business/messages' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r text-transparent' : ''}`}>Messages</span>
        </button>

        <button 
          className={`flex flex-col items-center ${location.pathname === '/business/profile' ? 'font-medium' : 'text-[#8E9196]'}`}
          onClick={() => navigate('/business/profile')}
        >
          <div className={`${location.pathname === '/business/profile' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r' : ''}`}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="mb-1">
              <path d="M12 11C14.2091 11 16 9.20914 16 7C16 4.79086 14.2091 3 12 3C9.79086 3 8 4.79086 8 7C8 9.20914 9.79086 11 12 11Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M6 21V19C6 17.9391 6.42143 16.9217 7.17157 16.1716C7.92172 15.4214 8.93913 15 10 15H14C15.0609 15 16.0783 15.4214 16.8284 16.1716C17.5786 16.9217 18 17.9391 18 19V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className={`text-xs ${location.pathname === '/business/profile' ? 'bg-clip-text from-[#B388EB] to-[#FC6ACF] bg-gradient-to-r text-transparent' : ''}`}>Profile</span>
        </button>
      </div>
    </nav>
  );
};
