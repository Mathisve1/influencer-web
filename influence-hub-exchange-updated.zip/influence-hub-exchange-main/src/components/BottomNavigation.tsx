import { useAuth } from '../context/AuthContext';
import { NavLink } from 'react-router-dom';

const BottomNavigation = () => {
  const { user } = useAuth();

  if (!user) return null; // Als de gebruiker niet is ingelogd, geen navbar tonen

  const influencerLinks = [
    { path: "/tasks", label: "Tasks" },
    { path: "/collaborations", label: "Collaborations" },
    { path: "/earnings", label: "Earnings" },
    { path: "/profile", label: "Profile" }
  ];

  const businessLinks = [
    { path: "/", label: "Dashboard" },
    { path: "/campaigns", label: "Campaigns" },
    { path: "/analytics", label: "Analytics" },
    { path: "/profile", label: "Profile" },
    { path: "/messages", label: "Messages" }
  ];

  const links = user.role === 'business' ? businessLinks : influencerLinks;

  return (
    <nav className="fixed bottom-0 w-full bg-white shadow-md p-2 flex justify-around">
      {links.map((link) => (
        <NavLink
          key={link.path}
          to={link.path}
          className={({ isActive }) =>
            `p-2 text-center ${isActive ? 'text-blue-500 font-bold' : 'text-gray-600'}`
          }
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  );
};

export default BottomNavigation;
