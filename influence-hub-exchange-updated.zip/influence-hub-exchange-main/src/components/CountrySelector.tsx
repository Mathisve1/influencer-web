
import * as React from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { countries } from "@/data/countries";
import { cn } from "@/lib/utils";

interface CountrySelectorProps {
  value: string;
  onChange: (value: string) => void;
}

const CountrySelector = ({ value, onChange }: CountrySelectorProps) => {
  const [open, setOpen] = React.useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between bg-neutral-800 border-neutral-700 text-white hover:bg-neutral-700 hover:text-white"
        >
          {value || "Select country..."}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent 
        className="w-[300px] p-0 bg-neutral-800 border-neutral-700" 
        align="start"
      >
        <Command className="bg-neutral-800">
          <CommandInput 
            placeholder="Search countries..." 
            className="h-9 text-white bg-neutral-800 border-b border-neutral-700"
          />
          <CommandEmpty className="py-2 text-sm text-neutral-400 text-center">
            No country found.
          </CommandEmpty>
          <CommandGroup className="max-h-[200px] overflow-y-auto">
            {countries.map((country) => (
              <CommandItem
                key={country}
                value={country}
                onSelect={(currentValue) => {
                  onChange(currentValue === value ? "" : currentValue);
                  setOpen(false);
                }}
                className="text-white hover:bg-neutral-700 cursor-pointer py-2"
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    value === country ? "opacity-100" : "opacity-0"
                  )}
                />
                {country}
              </CommandItem>
            ))}
          </CommandGroup>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default CountrySelector;
