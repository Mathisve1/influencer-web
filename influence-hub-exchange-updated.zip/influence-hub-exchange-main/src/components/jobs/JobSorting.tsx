
type SortOption = {
  field: "price" | "deadline";
  direction: "asc" | "desc";
};

interface JobSortingProps {
  sortOption: SortOption | null;
  onSortChange: (option: SortOption) => void;
  resultsCount: number;
}

export const JobSorting = ({ sortOption, onSortChange, resultsCount }: JobSortingProps) => {
  const getSortLabel = () => {
    if (!sortOption) return "Sort by";
    const field = sortOption.field === "price" ? "Price" : "Deadline";
    const direction = sortOption.direction === "asc" ? "Low to High" : "High to Low";
    return `${field}: ${direction}`;
  };

  return (
    <div className="p-4 flex justify-between items-center">
      <div className="text-sm text-neutral-400">
        {resultsCount} results found
      </div>
      <div className="relative group">
        <button className="flex items-center text-sm hover:text-neutral-300 transition-colors">
          <span>{getSortLabel()}</span>
          <i className="fa-solid fa-chevron-down ml-2"></i>
        </button>
        <div className="absolute right-0 mt-2 py-2 w-56 bg-neutral-800 rounded-lg shadow-lg border border-neutral-700 hidden group-hover:block z-50">
          <div className="px-3 py-1.5 text-xs text-neutral-400 uppercase tracking-wider font-medium">
            Price
          </div>
          <button
            onClick={() => onSortChange({ field: "price", direction: "desc" })}
            className={`w-full px-4 py-2 text-left text-sm hover:bg-neutral-700 transition-colors flex items-center justify-between ${
              sortOption?.field === "price" && sortOption.direction === "desc"
                ? "bg-neutral-700"
                : ""
            }`}
          >
            <span>High to Low</span>
            {sortOption?.field === "price" && sortOption.direction === "desc" && (
              <i className="fa-solid fa-check text-xs"></i>
            )}
          </button>
          <button
            onClick={() => onSortChange({ field: "price", direction: "asc" })}
            className={`w-full px-4 py-2 text-left text-sm hover:bg-neutral-700 transition-colors flex items-center justify-between ${
              sortOption?.field === "price" && sortOption.direction === "asc"
                ? "bg-neutral-700"
                : ""
            }`}
          >
            <span>Low to High</span>
            {sortOption?.field === "price" && sortOption.direction === "asc" && (
              <i className="fa-solid fa-check text-xs"></i>
            )}
          </button>

          <div className="px-3 py-1.5 mt-2 text-xs text-neutral-400 uppercase tracking-wider font-medium">
            Deadline
          </div>
          <button
            onClick={() => onSortChange({ field: "deadline", direction: "desc" })}
            className={`w-full px-4 py-2 text-left text-sm hover:bg-neutral-700 transition-colors flex items-center justify-between ${
              sortOption?.field === "deadline" && sortOption.direction === "desc"
                ? "bg-neutral-700"
                : ""
            }`}
          >
            <span>Most Days</span>
            {sortOption?.field === "deadline" && sortOption.direction === "desc" && (
              <i className="fa-solid fa-check text-xs"></i>
            )}
          </button>
          <button
            onClick={() => onSortChange({ field: "deadline", direction: "asc" })}
            className={`w-full px-4 py-2 text-left text-sm hover:bg-neutral-700 transition-colors flex items-center justify-between ${
              sortOption?.field === "deadline" && sortOption.direction === "asc"
                ? "bg-neutral-700"
                : ""
            }`}
          >
            <span>Least Days</span>
            {sortOption?.field === "deadline" && sortOption.direction === "asc" && (
              <i className="fa-solid fa-check text-xs"></i>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
