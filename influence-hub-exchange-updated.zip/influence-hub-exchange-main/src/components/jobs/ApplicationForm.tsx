
import { useState, useEffect } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface ApplicationFormProps {
  onClose: () => void;
  job: {
    title: string;
    company: string;
    price: string;
  };
}

export const ApplicationForm = ({ onClose, job }: ApplicationFormProps) => {
  const [formData, setFormData] = useState({
    coverLetter: "",
    proposedPrice: "",
    deliveryTime: "",
    portfolioLink: "",
    agreement: false
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.agreement) {
      toast.error("Please review and accept the terms before submitting");
      return;
    }

    try {
      // Get the current user
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast.error("Please login to submit an application");
        return;
      }

      const { error } = await supabase
        .from('job_applications')
        .insert({
          user_id: user.id,
          job_title: job.title,
          company: job.company,
          price: job.price,
          cover_letter: formData.coverLetter,
          proposed_price: formData.proposedPrice,
          delivery_time: formData.deliveryTime,
          portfolio_link: formData.portfolioLink
        });

      if (error) throw error;
      
      toast.success("Application submitted successfully!");
      onClose();
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error("Failed to submit application. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-neutral-900 z-50 overflow-y-auto">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <button className="p-2" onClick={onClose}>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="text-xl tracking-wide">Apply Now</div>
          <div className="w-10" />
        </div>
      </header>

      <main className="p-4 pb-24 max-w-2xl mx-auto">
        <div className="mb-6 p-4 bg-neutral-800 rounded-xl">
          <h2 className="text-lg font-medium mb-1">{job.title}</h2>
          <p className="text-neutral-400">{job.company}</p>
          <p className="text-purple-400 mt-2">{job.price}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">
              Why are you a good fit for this job?
            </label>
            <textarea
              required
              className="w-full h-32 bg-neutral-800 border border-neutral-700 rounded-lg p-3 text-white placeholder-neutral-500 focus:border-purple-500 transition-colors"
              placeholder="Write a compelling cover letter..."
              value={formData.coverLetter}
              onChange={(e) => setFormData({ ...formData, coverLetter: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Your Price Proposal
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-neutral-400">$</span>
              <input
                type="number"
                required
                className="w-full pl-7 bg-neutral-800 border border-neutral-700 rounded-lg p-2 text-white placeholder-neutral-500 focus:border-purple-500 transition-colors"
                placeholder="Enter your price"
                value={formData.proposedPrice}
                onChange={(e) => setFormData({ ...formData, proposedPrice: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Estimated Delivery Time
            </label>
            <input
              type="text"
              required
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-2 text-white placeholder-neutral-500 focus:border-purple-500 transition-colors"
              placeholder="e.g., 5 days"
              value={formData.deliveryTime}
              onChange={(e) => setFormData({ ...formData, deliveryTime: e.target.value })}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Portfolio/Previous Work
            </label>
            <input
              type="url"
              required
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg p-2 text-white placeholder-neutral-500 focus:border-purple-500 transition-colors"
              placeholder="Link to your portfolio or previous work"
              value={formData.portfolioLink}
              onChange={(e) => setFormData({ ...formData, portfolioLink: e.target.value })}
            />
          </div>

          <div className="flex items-start gap-2">
            <input
              type="checkbox"
              id="agreement"
              required
              className="mt-1"
              checked={formData.agreement}
              onChange={(e) => setFormData({ ...formData, agreement: e.target.checked })}
            />
            <label htmlFor="agreement" className="text-sm text-neutral-300">
              I confirm that I have reviewed and understood all provided documents 
              and agree to comply with the terms. I agree to complete the work within the specified delivery time 
              and for the price quoted above. I understand that my application will be reviewed based on these details 
              and that providing false information may result in my application being rejected.
            </label>
          </div>
        </form>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 p-4">
        <Button
          onClick={handleSubmit}
          disabled={!formData.agreement}
          className={`w-full py-6 bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end 
            ${!formData.agreement ? 'opacity-50 cursor-not-allowed' : 'hover:opacity-90 transition-opacity'}`}
        >
          Submit Application
        </Button>
      </footer>
    </div>
  );
};
