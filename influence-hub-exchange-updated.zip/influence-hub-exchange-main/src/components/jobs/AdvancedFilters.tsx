
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const AdvancedFilters = () => {
  return (
    <Card className="bg-neutral-800 border-neutral-700 p-4">
      <h3 className="text-lg mb-4">Advanced Filters</h3>
      <div className="space-y-4">
        <div>
          <Label>Content Type</Label>
          <RadioGroup defaultValue="all" className="mt-1.5">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="all" id="all" />
              <Label htmlFor="all">All</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="content_creation" id="content_creation" />
              <Label htmlFor="content_creation">Content Creation</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="influencer_marketing" id="influencer_marketing" />
              <Label htmlFor="influencer_marketing">Influencer Marketing</Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label>Price Range</Label>
          <div className="flex gap-2 mt-1.5">
            <Input
              type="number"
              placeholder="Min"
              className="bg-neutral-700"
            />
            <Input
              type="number"
              placeholder="Max"
              className="bg-neutral-700"
            />
          </div>
        </div>

        <div>
          <Label>Deadline</Label>
          <Select>
            <SelectTrigger className="bg-neutral-700 border-neutral-600 mt-1.5">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Button className="w-full">Apply Filters</Button>
      </div>
    </Card>
  );
};
