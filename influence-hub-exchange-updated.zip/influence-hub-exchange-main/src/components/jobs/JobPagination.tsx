
interface JobPaginationProps {
  currentPage: number;
  totalPages: number;
  onPreviousPage: () => void;
  onNextPage: () => void;
}

export const JobPagination = ({ currentPage, totalPages, onPreviousPage, onNextPage }: JobPaginationProps) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 p-4">
      <div className="flex justify-between items-center">
        <button 
          className={`px-4 py-2 bg-neutral-800 rounded-lg transition-all ${
            currentPage === 1 
              ? 'opacity-50 cursor-not-allowed' 
              : 'hover:bg-neutral-700'
          }`}
          onClick={onPreviousPage}
          disabled={currentPage === 1}
        >
          <i className="fa-solid fa-chevron-left mr-2"></i>
          Previous
        </button>
        <span className="text-sm">Page {currentPage} of {totalPages}</span>
        <button 
          className={`px-4 py-2 bg-neutral-800 rounded-lg transition-all ${
            currentPage === totalPages 
              ? 'opacity-50 cursor-not-allowed' 
              : 'hover:bg-neutral-700'
          }`}
          onClick={onNextPage}
          disabled={currentPage === totalPages}
        >
          Next
          <i className="fa-solid fa-chevron-right ml-2"></i>
        </button>
      </div>
    </div>
  );
};
