import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { ApplicationForm } from "./ApplicationForm";

interface JobDetailProps {
  onClose: () => void;
  job: {
    title: string;
    company: string;
    price: string;
    tags: string[];
  };
}

export const JobDetail = ({ onClose, job }: JobDetailProps) => {
  const [showApplicationForm, setShowApplicationForm] = useState(false);

  if (showApplicationForm) {
    return <ApplicationForm onClose={() => setShowApplicationForm(false)} job={job} />;
  }

  return (
    <div className="fixed inset-0 bg-neutral-900 z-50 overflow-y-auto">
      <header className="sticky top-0 z-50 bg-neutral-900 p-4 border-b border-neutral-800">
        <div className="flex items-center justify-between">
          <button className="p-2" onClick={onClose}>
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div className="text-xl tracking-wide">Job Details</div>
          <button className="p-2">
            <i className="fa-solid fa-share-nodes"></i>
          </button>
        </div>
      </header>
      <main className="pb-24">
        <div className="relative h-[200px]">
          <div className="w-full h-full bg-neutral-800 flex items-center justify-center">
            <span className="text-neutral-400">Company Banner</span>
          </div>
          <div className="absolute -bottom-10 left-4 w-20 h-20 bg-neutral-700 rounded-xl border-4 border-neutral-900 flex items-center justify-center">
            <i className="fa-solid fa-building text-2xl"></i>
          </div>
        </div>
        <div className="mt-14 px-4">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-xl mb-1">{job.title}</h1>
              <p className="text-neutral-400">{job.company}</p>
            </div>
            <div className="text-right">
              <p className="text-lg">{job.price}</p>
              <p className="text-sm text-neutral-400">+ products</p>
            </div>
          </div>
          <div className="mb-6">
            <h2 className="text-lg mb-3">Requirements</h2>
            <div className="space-y-2">
              {job.tags.map((tag, index) => (
                <div key={index} className="flex items-center gap-2 text-neutral-300">
                  <i className={`fa-brands fa-${tag.toLowerCase()} w-6`}></i>
                  <span>{tag}</span>
                </div>
              ))}
              <div className="flex items-center gap-2 text-neutral-300">
                <i className="fa-solid fa-users w-6"></i>
                <span>Min. 50k followers</span>
              </div>
            </div>
          </div>
          <div className="mb-6">
            <h2 className="text-lg mb-3">Description</h2>
            <p className="text-neutral-300 leading-relaxed">
              We're looking for content creators to promote our new product. The post should highlight key features and your authentic experience with the product.
            </p>
          </div>
          <div className="mb-6">
            <h2 className="text-lg mb-3">Required Documents</h2>
            <div className="space-y-2">
              <button className="w-full p-3 bg-neutral-800 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <i className="fa-regular fa-file-lines"></i>
                  <span>NDA Agreement</span>
                </div>
                <i className="fa-solid fa-download"></i>
              </button>
              <button className="w-full p-3 bg-neutral-800 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <i className="fa-regular fa-file-lines"></i>
                  <span>Campaign Brief</span>
                </div>
                <i className="fa-solid fa-download"></i>
              </button>
            </div>
          </div>
        </div>
      </main>
      <footer className="fixed bottom-0 left-0 right-0 bg-neutral-900 border-t border-neutral-800 p-4">
        <div className="flex gap-3">
          <button className="flex-1 py-3 bg-neutral-800 rounded-lg text-center">
            Message
          </button>
          <button 
            className="flex-1 py-3 bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end rounded-lg text-center hover:opacity-90 transition-opacity"
            onClick={() => setShowApplicationForm(true)}
          >
            Apply Now
          </button>
        </div>
        <button className="w-full mt-2 py-2 text-neutral-400 text-sm flex items-center justify-center gap-2">
          <i className="fa-solid fa-flag"></i>
          Report this job
        </button>
      </footer>
    </div>
  );
};
