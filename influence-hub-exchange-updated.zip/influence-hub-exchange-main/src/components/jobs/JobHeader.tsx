
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

export const JobHeader = () => {
  const navigate = useNavigate();

  const handleBackClick = () => {
    navigate("/tasks");
  };

  return (
    <header className="sticky top-0 z-50 bg-neutral-900 border-b border-neutral-800">
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-4">
            <button 
              onClick={handleBackClick}
              className="p-2 hover:bg-neutral-800 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="text-xl tracking-wide">TRACE</div>
          </div>
          <button className="p-2">
            <i className="fa-solid fa-bell"></i>
          </button>
        </div>
        <div className="relative">
          <input type="search" placeholder="Search opportunities..." className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-4 py-2 pl-10" />
          <i className="fa-solid fa-search absolute left-3 top-3 text-neutral-400"></i>
        </div>
      </div>
    </header>
  );
};
