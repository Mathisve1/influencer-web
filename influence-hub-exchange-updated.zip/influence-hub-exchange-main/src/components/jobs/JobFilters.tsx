
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CountrySelector from "@/components/CountrySelector";

interface JobFiltersProps {
  activeFilter: string;
  onFilterClick: (filter: string) => void;
  getFilterLabel: (filter: string) => string;
}

export const JobFilters = ({ activeFilter, onFilterClick, getFilterLabel }: JobFiltersProps) => {
  return (
    <div className="p-4 border-b border-neutral-800">
      <div className="flex space-x-2 overflow-x-auto pb-2">
        <button 
          onClick={() => onFilterClick("all")}
          className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
            activeFilter === "all" 
              ? "bg-brand-gradient-start text-white" 
              : "bg-neutral-800 hover:bg-neutral-700"
          }`}
        >
          All Filters
        </button>
        <button 
          onClick={() => onFilterClick("price")}
          className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
            activeFilter === "price" 
              ? "bg-brand-gradient-start text-white" 
              : "bg-neutral-800 hover:bg-neutral-700"
          }`}
        >
          {getFilterLabel("price")}
        </button>
        <button 
          onClick={() => onFilterClick("deadline")}
          className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
            activeFilter === "deadline" 
              ? "bg-brand-gradient-start text-white" 
              : "bg-neutral-800 hover:bg-neutral-700"
          }`}
        >
          {getFilterLabel("deadline")}
        </button>
        <button 
          onClick={() => onFilterClick("location")}
          className={`px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
            activeFilter === "location" 
              ? "bg-brand-gradient-start text-white" 
              : "bg-neutral-800 hover:bg-neutral-700"
          }`}
        >
          {getFilterLabel("location")}
        </button>
      </div>
    </div>
  );
};
