
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface Template {
  id: string;
  name: string;
  description: string;
  type: string;
}

const templates: Template[] = [
  {
    id: "1",
    name: "Instagram Story",
    description: "Template for Instagram story creation tasks",
    type: "Social Media"
  },
  {
    id: "2",
    name: "TikTok Video",
    description: "Template for TikTok video creation",
    type: "Social Media"
  },
  {
    id: "3",
    name: "Product Review",
    description: "Template for product review content",
    type: "Content"
  }
];

export const TaskTemplates = () => {
  return (
    <Card className="bg-neutral-800 border-neutral-700 p-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg">Templates</h3>
        <Button size="sm" variant="outline" className="h-8 w-8 p-0">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="space-y-3">
        {templates.map((template) => (
          <div
            key={template.id}
            className="p-3 bg-neutral-700/50 rounded-lg hover:bg-neutral-700 transition-colors cursor-pointer"
          >
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium">{template.name}</h4>
                <p className="text-sm text-neutral-400">{template.description}</p>
              </div>
              <span className="text-xs bg-neutral-600 px-2 py-1 rounded">
                {template.type}
              </span>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};
