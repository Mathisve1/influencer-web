
import { Card } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AnalyticsData {
  date: string;
  completed: number;
  pending: number;
}

const data: AnalyticsData[] = [
  { date: 'Mon', completed: 4, pending: 2 },
  { date: 'Tue', completed: 3, pending: 3 },
  { date: 'Wed', completed: 5, pending: 1 },
  { date: 'Thu', completed: 2, pending: 4 },
  { date: 'Fri', completed: 6, pending: 2 },
];

export const TaskAnalytics = () => {
  return (
    <Card className="bg-neutral-800 border-neutral-700 p-4">
      <h3 className="text-lg mb-4">Task Analytics</h3>
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#666" />
            <YAxis stroke="#666" />
            <Tooltip
              contentStyle={{
                backgroundColor: '#262626',
                border: '1px solid #404040',
                borderRadius: '8px',
              }}
            />
            <Line type="monotone" dataKey="completed" stroke="#22c55e" />
            <Line type="monotone" dataKey="pending" stroke="#3b82f6" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};
