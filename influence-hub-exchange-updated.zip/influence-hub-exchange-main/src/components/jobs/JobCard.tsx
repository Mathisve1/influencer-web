
import { useState } from "react";
import { JobDetail } from "./JobDetail";

interface JobCardProps {
  id: number;
  title: string;
  company: string;
  image: string;
  tags: string[];
  price: string;
  deadline: string;
}

export const JobCard = ({ id, title, company, image, tags, price, deadline }: JobCardProps) => {
  const [showDetail, setShowDetail] = useState(false);

  return (
    <>
      <div 
        onClick={() => setShowDetail(true)}
        className="bg-neutral-800 p-4 rounded-xl border border-neutral-700 hover:border-neutral-600 transition-colors cursor-pointer"
      >
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center">
            <img src={image} className="w-12 h-12 rounded-full" alt={`${company} Logo`} />
            <div className="ml-3">
              <h3 className="font-medium text-lg">{title}</h3>
              <p className="text-sm text-neutral-400">{company}</p>
            </div>
          </div>
          <button className="text-neutral-400 hover:text-neutral-300 transition-colors">
            <i className="fa-regular fa-bookmark"></i>
          </button>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {tags.map((tag, index) => (
            <span 
              key={index} 
              className="px-3 py-1 bg-neutral-700 rounded-full text-xs font-medium tracking-wide"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <div className="flex justify-between items-center pt-2 border-t border-neutral-700">
          <div className="flex items-center text-sm text-neutral-400">
            <i className="fa-regular fa-clock mr-2"></i>
            <span>Deadline: {deadline}</span>
          </div>
          <div className="text-xl font-semibold bg-clip-text text-transparent bg-gradient-to-r from-brand-gradient-start to-brand-gradient-end">
            {price}
          </div>
        </div>
      </div>

      {showDetail && (
        <JobDetail 
          job={{ title, company, price, tags }}
          onClose={() => setShowDetail(false)}
        />
      )}
    </>
  );
};
