
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

export const BusinessProfileMenuItems = () => {
  const navigate = useNavigate();
  const { t } = useLanguage();

  const menuItems = [
    { route: "/business/language-settings", icon: "fa-solid fa-globe", label: 'language' },
    { route: "/business/security", icon: "fa-solid fa-shield-halved", label: 'security' },
    { route: "/business/payment-settings", icon: "fa-solid fa-credit-card", label: 'paymentSettings' },
    { route: "/business/notifications", icon: "fa-solid fa-bell", label: 'notifications' },
  ];

  return (
    <div className="space-y-4">
      {menuItems.map((item) => (
        <div key={item.route} className="bg-neutral-800 rounded-xl p-4">
          <button 
            className="w-full flex items-center justify-between"
            onClick={() => navigate(item.route)}
          >
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-neutral-700 rounded-full flex items-center justify-center">
                <i className={item.icon}></i>
              </div>
              <span>{t(item.label)}</span>
            </div>
            <i className="fa-solid fa-chevron-right text-neutral-500"></i>
          </button>
        </div>
      ))}
    </div>
  );
};
