
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export const BusinessProfileAvatar = () => {
  const { t } = useLanguage();
  const [uploading, setUploading] = useState(false);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);

  const handleLogoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setUploading(true);
      
      if (!event.target.files || event.target.files.length === 0) {
        throw new Error("You must select an image to upload.");
      }

      const file = event.target.files[0];
      const fileExt = file.name.split('.').pop();
      const filePath = `${crypto.randomUUID()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('business-assets')
        .upload(filePath, file);

      if (uploadError) {
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('business-assets')
        .getPublicUrl(filePath);

      const { error: updateError } = await supabase
        .from('business_profiles')
        .update({ logo_url: publicUrl })
        .eq('id', (await supabase.auth.getUser()).data.user?.id);

      if (updateError) {
        throw updateError;
      }

      setLogoUrl(publicUrl);
      toast.success("Logo uploaded successfully");
    } catch (error) {
      toast.error("Error uploading logo");
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-center mb-8">
      <div className="relative mb-4">
        <img 
          src={logoUrl || "https://api.dicebear.com/7.x/notionists/svg?scale=200&seed=123"} 
          className="w-24 h-24 rounded-full border-2 border-neutral-700 object-cover" 
          alt="Business Profile" 
        />
        <div className="absolute bottom-0 right-0">
          <Button
            variant="secondary"
            size="icon"
            className="h-8 w-8 rounded-full bg-neutral-800 border border-neutral-700"
            disabled={uploading}
            onClick={() => document.getElementById('logo-upload')?.click()}
          >
            {uploading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <i className="fa-solid fa-camera"></i>
            )}
          </Button>
          <input
            type="file"
            id="logo-upload"
            accept="image/*"
            onChange={handleLogoUpload}
            className="hidden"
          />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <h1 className="text-xl mb-1">Acme Corporation</h1>
        {true && (
          <i className="fa-solid fa-badge-check text-blue-500" title="Verified Business"></i>
        )}
      </div>
      <p className="text-neutral-400 text-sm">{t('business')}</p>
    </div>
  );
};
