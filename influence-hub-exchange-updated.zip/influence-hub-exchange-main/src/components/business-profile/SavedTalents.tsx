
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { SavedTalent } from "@/types/business";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export const SavedTalents = () => {
  const [savedTalents, setSavedTalents] = useState<SavedTalent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSavedTalents();
  }, []);

  const fetchSavedTalents = async () => {
    try {
      const { data, error } = await supabase
        .from('saved_talents')
        .select(`
          *,
          profiles:talent_id (
            first_name,
            last_name
          )
        `);

      if (error) throw error;
      setSavedTalents(data || []);
    } catch (error) {
      console.error('Error fetching saved talents:', error);
      toast.error('Could not load saved talents');
    } finally {
      setLoading(false);
    }
  };

  const updateNotes = async (talentId: string, notes: string) => {
    try {
      const { error } = await supabase
        .from('saved_talents')
        .update({ notes })
        .eq('id', talentId);

      if (error) throw error;
      toast.success('Notes updated successfully');
    } catch (error) {
      console.error('Error updating notes:', error);
      toast.error('Could not update notes');
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold mb-4">Saved Talents</h2>
      {loading ? (
        <div className="text-center py-4">Loading...</div>
      ) : savedTalents.length === 0 ? (
        <div className="text-center py-4 text-neutral-400">
          No saved talents yet
        </div>
      ) : (
        <div className="grid gap-4">
          {savedTalents.map((talent) => (
            <Card key={talent.id} className="bg-neutral-800 border-neutral-700">
              <CardHeader>
                <CardTitle className="text-lg">
                  {talent.profiles?.first_name} {talent.profiles?.last_name}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm text-neutral-400 mb-1 block">
                      Notes
                    </label>
                    <Input
                      value={talent.notes || ''}
                      onChange={(e) => updateNotes(talent.id, e.target.value)}
                      className="bg-neutral-700 border-neutral-600"
                      placeholder="Add notes about this talent..."
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {/* Add remove functionality */}}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
